function [idxFeaturesAll_folds, idxFeaturesOrg_folds] =  ...
    featureSelectionAlgorithm(evalMatrix, myClassesCin, varnames, cvp, MySettings,saveLoc)
% select and save most informative features
%
% INPUT: 
%   evalMatrix: double matrix of training data (columns: features, rows: observations)
%   myClassesCin: categorial including class labels of evalMatrix
%   varnames: cell array with feature names
%   cvp: cvpartition object for data splitting 
%   MySettings: struct with settings for analysis
%   saveLoc: string containing save data location
%
% OUTPUT
%   idxFeaturesAll_folds: selected feature indices per fold
%   idxFeaturesOrg_folds: selected feature indices per fold (original
%       numbering)
% 
% Authors: Aline Knab, Shannon Handley
% Date: 25.03.2024
%
% Last modified: 
%   10.05.2025 (Aline Knab): converted to separate function and feature
%       computation per fold, rank amongst multiple algorithms

normVal_folds = cell(cvp.NumTestSets,1);
idxFeaturesAll_folds = cell(cvp.NumTestSets,1);
idxFeaturesOrg_folds = cell(cvp.NumTestSets,1);

if MySettings.numChSelect > size(evalMatrix,2) 
    MySettings.numChSelect = size(evalMatrix,2);
end
numFeaturesSelect = MySettings.numChSelect;

% Fixed settings (shared across workers)  
featureMethods = MySettings.featureSelect;
if strcmp(featureMethods,'multi')
    % MySettings.featureSelect = {'mrmr', 'chi'}; % test
    featureMethods = {'mrmr', 'chi', 'laplacian', 'relieff', ...
        'significance', 'gini'};
    if size(categories(myClassesCin),1) == 2
        featureMethods = [MySettings.featureSelect, ...
            {'bhattacharyya', 'entropy','ttest', 'roc', 'wilcoxon'}];
    end
    MySettings.numChSelect = size(evalMatrix,2);
else %if ~iscell(featureMethods)
   featureMethods = {MySettings.featureSelect};
    if cvp.NumTestSets == 1
        MySettings.numChSelect = numFeaturesSelect;
    end 
end

if ismember("significance",featureMethods) && strcmpi(MySettings.signMethod,"automatic") % ALINE: check if normality type required elsewhere in this function!!!
    notNormal = compDistribution(evalMatrix, myClassesCin, varnames, [], [], []);
    if notNormal; MySettings.signMethod = "Non-Parametric";
    else; MySettings.signMethod = "Parametric"; end
end


parfor iFold = 1:cvp.NumTestSets % PARFOR, disable for testing only
    % Preallocate
    localSettings = MySettings;

    % Assessing data partitioning
    IdxPartition = struct('training', cell(1, 1), 'test', cell(1, 1));
    if localSettings.supervised && isa(cvp, 'cvpartition')
        IdxPartition.training = training(cvp,iFold);
        IdxPartition.test = test(cvp,iFold);
    else
        IdxPartition.training = true(size(evalMatrix,1),1);
        IdxPartition.test = [];
    end
    myClassesC = struct;
    myClassesC.training = myClassesCin(IdxPartition.training,:); 
            
    % Normalization
    [evalMatrix_n, normVal_folds{iFold}] = compNormalize(evalMatrix(IdxPartition.training,:),localSettings.normalizeType);
            
    % idxFeaturesAll = zeros(1,localSettings.numChSelect);
    idxFeaturesAll = zeros(1,size(evalMatrix_n,2));
    for iFeatSelect = 1:size(featureMethods,2)
        myMethodSelect = featureMethods{iFeatSelect};
        % rankToAdd = zeros(1,localSettings.numChSelect);
        rankToAdd = zeros(1,size(evalMatrix_n,2));
        
        switch myMethodSelect
            case 'fs' % Forward feature selection
                [idxFeatures, ~,localSettings.kTraining] = forwardFeatureSelection(evalMatrix_n, varnames, myClassesC.training, MySettings);
            case 'particle_swarm' % Particle swarm 
                [idxFeatures, ~] = psFeatureSelection(evalMatrix_n, myClassesC.training, localSettings); 
            case 'pearson_anova' % Combination of Anova & Pearson
                [idxFeatures] = anovaPearsonFeatureSelection(evalMatrix_n, myClassesC.training, localSettings); 
            case 'mrmr' % minimum redundancy maximum relevance (MRMR) algorithm
                Tbl = array2table(evalMatrix_n);
                Tbl.Properties.VariableNames = matlab.lang.makeUniqueStrings(matlab.lang.makeValidName(varnames));
                [idxFeatures] = fscmrmr(Tbl,myClassesC.training);
                idxFeatures = idxFeatures(1:localSettings.numChSelect);
            case 'manual'
                idxFeatures = MySettings.featureManual;
            case 'groupedKmeans'
                [idxFeatures,~] = groupedKMeans(evalMatrix_n,...
                    myClassesC.training,localSettings.numClusters);
            case 'chi'
                idxFeatures = fscchi2(evalMatrix_n, myClassesC.training);
                idxFeatures = idxFeatures(1:localSettings.numChSelect);
            case 'laplacian'
                idxFeatures = fsulaplacian(evalMatrix_n);
                idxFeatures = idxFeatures(1:localSettings.numChSelect);
            case 'relieff'
                idxFeatures = relieff(evalMatrix_n,myClassesC.training,localSettings.kRelieff);
                idxFeatures = idxFeatures(1:localSettings.numChSelect);
            case 'significance'
                [idxFeatures,~] = statsFeatSelect(evalMatrix_n, myClassesC.training, varnames, MySettings);
            case 'bhattacharyya'
                idxFeatures = rankfeatures(evalMatrix_n',cellstr(myClassesC.training),...
                    'Criterion',"bhattacharyya",'NumberOfIndices',localSettings.numChSelect);
            case 'entropy'
                idxFeatures = rankfeatures(evalMatrix_n',cellstr(myClassesC.training),...
                    'Criterion',"entropy",'NumberOfIndices',localSettings.numChSelect);
            case 'ttest'
                idxFeatures = rankfeatures(evalMatrix_n',cellstr(myClassesC.training),...
                    'Criterion',"ttest",'NumberOfIndices',localSettings.numChSelect);
            case 'roc'
                idxFeatures = rankfeatures(evalMatrix_n',cellstr(myClassesC.training),...
                    'Criterion',"roc",'NumberOfIndices',localSettings.numChSelect);
            case 'wilcoxon'
                idxFeatures = rankfeatures(evalMatrix_n',cellstr(myClassesC.training),...
                    'Criterion',"wilcoxon",'NumberOfIndices',localSettings.numChSelect);
            case 'gini'
                idxFeatures = fsGini(evalMatrix_n,grp2idx(myClassesC.training));
                % idxFeatures = idxFeatures.fList(end-MySettings.numChSelect:end); % according to implemented base code
                idxFeatures = idxFeatures.fList(1:localSettings.numChSelect); % better, https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10773927/pdf/peerj-cs-09-1711.pdf
            otherwise
                idxFeatures = 1:size(evalMatrix_n,2);
        end
    
        idxFeatures = reshape(idxFeatures, 1, []);
    
        if size(MySettings.featureSelect,2) > 1
            if numel(idxFeatures) < MySettings.numChSelect
                rankToAdd(idxFeatures) = (numel(idxFeatures):-1:1);
            else
                rankToAdd(idxFeatures) = (MySettings.numChSelect:-1:1);
            end
            idxFeaturesAll = idxFeaturesAll + rankToAdd; 
        end
    end

    % Best selection over selected methods
    [~,idxFeatures] = sort(idxFeaturesAll,'descend');
    idxFeatures = idxFeatures(1:numFeaturesSelect);
    idxFeaturesAll_folds{iFold} = idxFeatures;
    idxFeaturesOrg_folds{iFold} = MySettings.idxFeatAvailable(idxFeatures); % convert to original feature index

end

if ~isempty(saveLoc)
    myTable_folds = cell(numFeaturesSelect,cvp.NumTestSets*2);
    myVarnames = cell(1,cvp.NumTestSets*2);
    count = 1;
    for iFold = 1:cvp.NumTestSets
        myTable_folds(:,count:count+1) = cellstr([idxFeaturesOrg_folds{iFold}.',...
            reshape(string(varnames(idxFeaturesAll_folds{iFold})),[],1)]);
        if cvp.NumTestSets > 1
            myVarnames(count:count+1) = cellstr(append({'Index','Feature Name'}, " (fold " + string(iFold) + ")"));
        else
            myVarnames = {'Index','Feature Name'};
        end
        count = count+2;
    end
    
    myTable_folds = array2table(myTable_folds, 'VariableNames',myVarnames);
    writetable(myTable_folds, fullfile(saveLoc,"Selected_Features_"+...
        string(datetime('now','Format','yyyy-MM-dd_HH-mm-ss'))+".xlsx"), ...
        'WriteMode','overwritesheet')
end

end


