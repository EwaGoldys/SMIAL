function [idxFeatures, valEval, kOut] = forwardFeatureSelection(evalMatrix, varnames, myClassesC, MySettings)
% performs forward feature selection
% 
% INPUT: 
%   evalMatrix: double matrix (columns: features, rows: observations)
%   varnames: cell arrays containing feature names
%   myClassesC: categorial array with class labels for each observation
%   MySettings: struct containing settings
%       * numChSelect: number of channels to be selected
%       * groups: string array with each row having one available group name
%       * kTraining: k-fold for crossvalidating selection (e.g., 10)
%       * cutOffPCA: double defining information content to keep, e.g. 0.95
%       * myClassifier: selected classifier method, e.g. 'svm'
% 
% OUTPUT:
%   idxFeatures: indices of selected features
%   valEval: performance value
%
% Author: Aline Knab, Shannon Handley
% Date: 03.03.2024
%
% Last modified: 
%   13.05.2025 (Aline Knab): efficiency improvement

idxFeatures = nan(1,MySettings.numChSelect);
valEval = nan(1,MySettings.numChSelect-1);

forwardSelection = true;

MySettings.kCross = min(MySettings.kTraining,min(countcats(myClassesC))); % change in variable required bc of compAnalysis
kOut = MySettings.kCross;
MySettings.percTraining = 100-100/MySettings.kCross;

MySettings.featureSelect = 'none';
MySettings.validation = "crossval";

if strcmp(MySettings.performanceTraining,"Mean Performance")
    myOptionsComp = {'AUC','F1 Score','Correctly Labelled [%]','Sensitivity','Specificity'}; % changes in order will affect tab_avg
else 
    myOptionsComp = {MySettings.performanceTraining};
end
myOptionsData = {'test'};  

nFeatures = size(evalMatrix, 2);

%% Feature forward selection
for iSelect = 1:MySettings.numChSelect-1
    if forwardSelection
        % disp("iSelect: "+ iSelect); % Correction mode
        timerVal = tic;

        valEval(iSelect) = 0;
        idxFSet = idxFeatures(~isnan(idxFeatures));
        
        % Create testing list
        if isempty(idxFSet) % select 2 base features
            [i1, i2] = find(triu(true(nFeatures), 1));
            listSelect = [i1, i2];

        else % Add one feature at a time not in idxFSet
            remaining = setdiff(1:nFeatures, idxFSet);
            listSelect = remaining(:);
        end
        
        numComb = size(listSelect, 1);
        myEvals = nan(numComb,1);
        myStds = nan(numComb,1);
        myFeatures = nan(numComb,size(listSelect, 2));

        % Compute all features from list
        parfor iList = 1:numComb %PARFOR!!! -> use for to debug ;)
            % disp("iList: "+ iList); % Correction mode

            if isempty(idxFSet)
                idxAnalyze = listSelect(iList,:);
            else
                idxAnalyze = [idxFSet, listSelect(iList)];
            end

            % idxAnalyze = [idxFSet, listSelect(iList,:)];
            [myMdl,myData] = compAnalysis(evalMatrix(:,idxAnalyze), myClassesC, varnames, MySettings, [],[], false);

            IdxPartition = struct('training', cell(1, 10), 'test', cell(1, 10));
            for iFold = 1:myData.cvp.NumTestSets
                IdxPartition(iFold).training = training(myData.cvp,iFold);
                IdxPartition(iFold).test = test(myData.cvp,iFold);
            end

            [tab_c] = compAccuracy(myData.yci,myData.ypred,myData.myClassesC,IdxPartition,myMdl.idxMdl,...
                MySettings.groups,myOptionsComp,myOptionsData,[],4,[],[]);

            tab_avg = extractMeansFromCellTable(tab_c);
            
            myEvals(iList,1) = mean(tab_avg(:,1),'omitnan');
            myStds(iList,1) = mean(tab_avg(:,2),'omitnan');
            myFeatures(iList,:) = idxAnalyze(end - size(listSelect, 2) + 1:end);      
        end

        timerVal = toc(timerVal);
        % disp("Elapsed time for feature selection round " + iSelect + " of...
        % " + (MySettings.numChSelect-1) + " is " + timerVal + " seconds."); % Correction mode
       
        %% Select best features for current round of evaluation 
        if isempty(myFeatures)
            forwardSelection = false;
        else
            [~,iBest] = max(abs(myEvals-myStds));
            nanIndices = find(isnan(idxFeatures));

            if size(myFeatures, 2) == 2 % first feature combination
                idxFeatures(1:2) = myFeatures(iBest, :);
            elseif size(myFeatures, 2) == 1
                idxFeatures(nanIndices(1)) = myFeatures(iBest);
            end

            valEval(iSelect) = myEvals(iBest);
        end
    
    end
    
end

% Remove any potential nan values
idxFeatures = idxFeatures(~isnan(idxFeatures));
valEval = valEval(~isnan(valEval));

% disp("Selected features: "+varnames(idxFeatures)+" (Measure: "+num2str(valEval)+")");

end

function valMatrix = extractMeansFromCellTable(tab_c)
% Convert ± strings to numeric mean and std

tab_array = string(table2array(tab_c));
tab_vals = zeros(size(tab_array,1), 2);

for i = 1:size(tab_array,1)
    parts = split(tab_array(i), '±');
    if numel(parts) == 2
        tab_vals(i,1) = str2double(parts(1));
        tab_vals(i,2) = str2double(parts(2));
    end
end

valMatrix = tab_vals;
end