function [evalMatrix_test_t] = applyPCA(evalMatrix_test,coeffTraining,numPCs)
% applies PCA on test data
%
% INPUT: 
%   evalMatrix_test: (optional) double matrix of test data, must be zscored (columns: features, rows: observations)
%   coeffTraining: transformation matrix
%   numPCs: number of relevant PCs
%
% OUTPUT:
%   evalMatrix_test_t: transformed test dataset limited to relevant PCs (if evalMatrix_test provided)
%
% Authors: Aline Knab
% Date: 12.11.2023

%% Transfer PCA to test data
if ~isempty(evalMatrix_test)
    evalMatrix_test_t = evalMatrix_test*coeffTraining;
    evalMatrix_test_t = evalMatrix_test_t(:,1:numPCs);
else
    evalMatrix_test_t = [];
end

end