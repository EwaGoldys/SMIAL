function saveHyperparameters(myMdl,myFile)
% Adds optimized hyperparameters to text file
%
% INPUT: 
%   myMdl: struct containing MyMdl data
%   myFile: string with filename 
%
% Author: Aline Knab
% Date: 07.07.2025 

if ~isstruct(myMdl)
    return;
end

if isfield(myMdl,'Mdl_classifier') && ...
    isfield(myMdl.Mdl_classifier,'HyperparameterOptimizationResults')

    myResults = myMdl.Mdl_classifier.HyperparameterOptimizationResults;
    if ~isempty(myResults)
        extractAndSaveHyperparameters(myResults,myFile,"validation")
    end
end

if isfield(myMdl,'Mdl_classifier_final') && ...
    isfield(myMdl.Mdl_classifier_final,'HyperparameterOptimizationResults')

    myResults = myMdl.Mdl_classifier_final.HyperparameterOptimizationResults;
    if ~isempty(myResults)
        extractAndSaveHyperparameters(myResults,myFile,"final")
    end
end

end

function extractAndSaveHyperparameters(myResults,myFile,specifierMdl)

if nargin < 3
    specifierMdl = "";
else
    specifierMdl = append(" (",specifierMdl," model)");
end

%% Heading
writelines(append("→ Hyperparameters",specifierMdl,": "),myFile,WriteMode="append");

%% Best Hyperparameters (XAtMinObjective)
writelines("- Best Hyperparameters: ",myFile,WriteMode="append");
bestHyper = myResults.XAtMinObjective;
for iEntry = 1:numel(bestHyper)
    writelines(append("* ",bestHyper.Properties.VariableNames{iEntry},": ",string(bestHyper{1,iEntry})),myFile,WriteMode="append");
end

%% Best Objective (Loss) (MinObjective)
writelines(append("- Best Objective (Loss): ",string(myResults.MinObjective)),myFile,WriteMode="append");

% statVisible = "on"; % use on for testing
% f = figure('visible',statVisible);
% plot(hypRes_Hyper.ObjectiveTrace,'b','LineWidth',1.5);
% xlabel("Iteration",'FontSize',12);
% ylabel("Loss",'FontSize',12)
% title("Loss over iteration")
% saveas(f,fullfile(saveLoc,"Loss over Iteration.png"));
end
