function myStruct = combineAsStruct(varargin)
% combines input variables in struct
% 
% INPUT: 
%   optional first input: struct array to attach to;
%   afterwards
%       uneven variables: field names to be assigned
%       even variables: values to be assigned
% 
% OUTPUT:
%   myStruct: structure
%
% Authors: Aline Knab
% Date: 02.10.2023

if rem(nargin,2)~=0
    if isstruct(varargin{1})
        myStruct = varargin{1};
        myStart = 2;
    else
        error("Attempt to create struct with uneven number of input arguments (function combineAsStruct")
    end
else
    myStruct = struct;
    myStart = 1;
end


for i = myStart:2:nargin
    myStruct.(genvarname(varargin{i})) = varargin{i+1};
end

end