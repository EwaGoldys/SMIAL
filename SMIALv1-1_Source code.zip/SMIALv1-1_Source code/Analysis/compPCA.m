function [scoreTraining,coeffTraining, explained, numPCs] = compPCA(evalMatrix_training,mySettings)
% applies PCA transformation to training and testing dataset with PCs ...
% limited to cutOff explanation value or number of classes
%
% INPUT: 
%   evalMatrix_training: double matrix of training data, must be zscored 
%       (columns: features, rows: observations)
%   mySettings: structure containing settings
%       * cutOffPCA: double defining information content to keep, e.g. 0.95
%       * groups: string array with class names
%
% OUTPUT
%   scoreTraining: transformed training dataset limited to relevant PCs
%   coeffTraining: transformation matrix
%   explained: information content per PC
%   numPCs: number of relevant PCs
% 
% Authors: Aline Knab
% Date: 12.11.2023

%% PCA on trainig data
[coeffTraining, scoreTraining, ~,~,explained,~] = pca(evalMatrix_training);

%% Choose number of PCs
numPCs = find(cumsum(explained/100) >= mySettings.cutOff_PCA,1,'first');
numPCs = max(2,numPCs);
% if numPCs < max(2,size(mySettings.groups,1))
%     numPCs = max(2,size(mySettings.groups,1));
% end   

%% Limit to relevant PCs
scoreTraining = scoreTraining(:,1:numPCs);

end