function [y_pred] = predictDistance(evalMatrix_test,C)
% predicts distance of observations to centroids
%
% INPUT: 
%   evalMatrix_t: data (rows: observations, columns: (transformed)
%       features)
%   C: double array with centroids
%
%   y_pred: predicted data
% 
% Authors: Aline Knab
% Date: 12.07.2023

[~,y_pred] = pdist2(C,evalMatrix_test,'euclidean','Smallest',1);

end