function [idxFeatures] = anovaPearsonFeatureSelection(evalMatrix, myClassesC, MySettings)
% feature selection based on Anova and Pearson correlation
% 
% INPUT: 
%   evalMatrix: double matrix (columns: features, rows: observations)
%   myClasses: categorial with class labels
%   MySettings: struct including settings
%       * numChSelect: number of channels to select
% 
% OUTPUT:
%   idxFeatures: int array of selected features
% 
% Author: Aline Knab
% Date:20.06.2023

%% Correlation < Threshold, lowest p-Value Anoa
% Pearson correlation 
rho = abs(corr(evalMatrix));
if all(rho>=MySettings.cutOff_r)
    msgbox("R threshold too low for Anova-Peason","Error");
    error("AnovaPearson_Settings");
end

% ANOVA
myPAnova = nan(size(evalMatrix,2),2);

% Minimum p(Anova), rho < .1 (negligible)
for i = 1:size(evalMatrix,2)
    myTrainingMatrix = nan(size(evalMatrix,1),size(MySettings.groups,1));
    for j = 1:size(MySettings.groups,1)
        myTrainingMatrix(myClassesC==MySettings.groups(j),j) = evalMatrix(myClassesC==MySettings.groups(j),i);
    end
    myPAnova(i,2) = anova1(myTrainingMatrix,[],'off');
    myPAnova(i,1) = i;
end


myFeatures = nan(50,MySettings.numChSelect);
sumPAnova = 100;
sumR = 100;


myComb = seq_nchoosek(size(myPAnova,1),MySettings.numChSelect);
while true
    myComb = seq_nchoosek();
    if size(myComb,1)==0
      break
    end

    sumPAnova_new = sum(myPAnova(myComb,2));
    rhoComb = nchoosek(myComb,2);
    sumR_new = sum(rho(rhoComb(1,1),rhoComb(1,2)));

    if all(rho(rhoComb(1,1),rhoComb(1,2))<MySettings.cutOff_r) && sumPAnova_new<=sumPAnova
        if sumPAnova_new<sumPAnova || sumPAnova_new==sumPAnova && sumR_new<sumR
            myFeatures(2:end,:) = myFeatures(1:end-1,:);
            myFeatures(1,:) = myPAnova(myComb,1);
            sumPAnova = sumPAnova_new;
            sumR = sumR_new;
        end
    end
end

myFeatures(any(isnan(myFeatures), 2),:) = [];

if isempty(myFeatures)
    msgbox("No feature combination displaying the desired properties was found.")
    error("Error in anovaPearsonFeatureSelection, no selection available")
else
    idxFeatures = myFeatures(1,:);
end

end

