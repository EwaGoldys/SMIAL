function [IdxPartition] = mixData(myClassesN,percTraining)
% Mix dataset & assign indices for test and training data 
%
% INPUT: 
%   myClassesN: double array with class number for each observation
%   percTrain: percentage of data assigned to training set 
%
% OUTPUT: 
%   IdxPartition: Struct
%       train: indices of training partition
%       test: indices of test partition
% 
% Authors: Aline Knab
% Date: 06.07.2023

if percTraining>1
    percTraining = percTraining/100;
end

idxTraining = []; idxTest = [];

for iClass = 1:size(unique(myClassesN),1) 
    myIdx = find(myClassesN==iClass);
    rng('default'); % Testing
    mySplit = cvpartition(size(myIdx,1),'Holdout',(1-percTraining));
    idxTraining = [idxTraining;myIdx(training(mySplit))];
    idxTest = [idxTest;myIdx(test(mySplit))];
end

IdxPartition.training = idxTraining;
IdxPartition.test = idxTest;

end