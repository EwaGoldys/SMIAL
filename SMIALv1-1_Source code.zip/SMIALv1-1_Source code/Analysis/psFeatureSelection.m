function [idxFeatures, fval] = psFeatureSelection(evalMatrix, myClassesC, MySettings)
% feature selection based on fisher distance
% 
% INPUT: 
%   evalMatrix: double matrix (columns: features, rows: observations)
%   myClasses: categorial with class labels
%   MySettings: struct including settings
%       * numChSelect: number of channels to select
% 
% OUTPUT:
%   idxFeatures: int array of selected features
%   fval: quality measure
% 
% Author: Aline Knab
% Date: 06.08.2023

myClassesN = grp2idx(myClassesC);

% Feature selection
fun = @(x)qcMeas(round(x),evalMatrix,myClassesN);

% for set amount of features
options = optimoptions('particleswarm','UseParallel',true,'SwarmSize',...
    max(round(size(evalMatrix,2)),10*MySettings.numChSelect),'FunctionTolerance',0);
lb = ones(1,MySettings.numChSelect)*.5;
ub = ones(1,MySettings.numChSelect)*size(evalMatrix,2)+.499999999999;
[x,fval,~,~] = particleswarm(fun,MySettings.numChSelect,lb,ub,options);

idxFeatures = round(x);

end

function qc = qcMeas(x,myData,myClassesN)
    % quality metric (between class variance vs within class variance)
    if size(x,2)==size(unique(x),2)
        qc = 0;
        for iFeature = 1:size(x,2)
            numerator = 0;
            denominator = eps(0);
            for j = 1:size(unique(myClassesN),1)
                numerator = numerator+sum(myClassesN==j)*(mean(myData(myClassesN==j,x(iFeature))))^2; % between classes
                denominator = denominator+sum(myClassesN==j)*std(myData(myClassesN==j,x(iFeature)))^2; % within class
            end
            numerator = numerator/size(myData,1);
            denominator = denominator*size(unique(myClassesN),1)/((size(myData,1))*(size(unique(myClassesN),1)-1));
            qc = qc + numerator/denominator;
        end
        qc = 1/qc;
    else
        qc = Inf;
    end
end
