function [best_pred, accuracy, perm_idx] = align_clusters(predicted, groundtruth, myGroups)
% Aligns cluster labels with ground truth group order (categorical)
%
% INPUT:
%   predicted: categorical cluster assignments (e.g., from kmeans)
%   groundtruth: categorical true class labels
%   myGroups: desired ground truth order (categorical array)
%
% OUTPUT:
%   best_pred: relabeled predicted clusters matching myGroups
%   accuracy: accuracy after relabeling
%   perm_idx: permutation to reorder centroids C
%
% Author: Aline Knab
% Date:11.04.2025

% Compute confusion matrix using desired row/col order
conf_mat = confusionmat(groundtruth, predicted, 'Order', myGroups);

% Partial Matching
perm_idx = nan(numel(myGroups),1);
used_preds = false(numel(myGroups),1);
best_pred = predicted;

for i = 1:numel(myGroups)
    [~, best_match] = max(conf_mat(i, :) .* ~used_preds');
    perm_idx(i) = best_match;
    used_preds(best_match) = true;
    best_pred(predicted == myGroups(best_match)) = myGroups(i);
end

% Compute accuracy
accuracy = mean(best_pred == groundtruth);

end
