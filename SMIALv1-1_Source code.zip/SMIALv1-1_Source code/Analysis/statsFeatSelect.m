function [idxFeatures, MySettings] = statsFeatSelect(evalMatrix, myClassesC, varnames, MySettings)
% feature selection based on significance
% 
% INPUT: 
%   evalMatrix: double matrix (columns: features, rows: observations)
%   myClasses: categorial with class labels
%   varnames: cell array containing all channel names
%   MySettings: struct including settings
%       * numChSelect: number of channels to select
% 
% OUTPUT:
%   idxFeatures: int array of selected features
%   fval: quality measure
% 
% Author: Aline Knab
% Date: 06.08.2023

if strcmpi(MySettings.signMethod,"automatic")
    notNormal = compDistribution(evalMatrix, myClassesC, varnames, [], [], []);
    if notNormal; MySettings.signMethod = "Non-Parametric";
    else; MySettings.signMethod = "Parametric"; end
elseif strcmpi(MySettings.signMethod,"parametric")
    notNormal = false;
else
    notNormal = true;
end

[~,~,~,p_Significance] = compSign(evalMatrix, myClassesC, ...
    varnames, [], .05, notNormal, false, [], [], []);
idxFeatures = cell2mat(p_Significance(1:MySettings.numChSelect,1));

end