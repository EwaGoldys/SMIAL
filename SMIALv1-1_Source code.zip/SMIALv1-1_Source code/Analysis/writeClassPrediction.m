function writeClassPrediction(ypred,fileInfos,saveLoc)
% writes class predictions into excel sheet
%
% INPUT: 
%   ypred: predicted class labels
%   fileInfos: information on files (index, filename, id)
%   saveLoc: string of location to save data 
% 
% Authors: Aline Knab
% Date: 12.11.2023
%
% Last modified: 
%   23.02.2025 (Aline Knab) updated structures to general variables

saveLoc = createSaveLoc({saveLoc});

if size(ypred,1)<size(ypred,2)
    ypred = ypred.';
end

t = cell(size(ypred,1),size(fileInfos,2)+1);
if ~iscell(fileInfos)
    fileInfos = cellstr(fileInfos);
end
t(:,1:end-1) = fileInfos;
t(:,end) = cellstr(ypred);
t = cell2table(t);
if size(fileInfos,2) == 2; varNames = ["Filename";"ID";"Predicted Class"]; 
else; varNames = ["Filename";"ID";"Partition";"Predicted Class"]; end
t.Properties.VariableNames = varNames;

writetable(t,fullfile(saveLoc,append("PredictedClass_", ...
    string(datetime('now','Format','yyyy-MM-dd_HH-mm-ss'))+".xlsx")), ...
    'WriteMode','overwritesheet');

end
