function [newFeatures,idx] = upsample(dataset, myGroup,num2Add,numNeighbors,myAlgorithm)
% redirects to selected upsampling algorithm
%
% INPUT:
%   dataset: table data with features and labels
%   myGroups: Label to oversample
%   num2Add: Number of data to generate
%   numNeighbors: number of neighbors to consider
%   myAlgorithm: String specifying upsampling algorithm
%
% OUTPUT:
%   newFeatures: generated dataset
%   idx: base observation which is upsampled
% 
% Authors: Aline Knab
% Date: 22.11.2024

switch myAlgorithm
                    
    case "SMOTE"
        [newFeatures,~,idx] = mySMOTE(dataset,myGroup,num2Add,...
            "NumNeighbors",numNeighbors);
    case "ADASYN"
        [newFeatures,~,idx]  = myADASYN(dataset,myGroup,num2Add,...
            "NumNeighbors",numNeighbors);
    case "Borderline SMOTE"
        [newFeatures,~,idx] = myBorderlineSMOTE(dataset,myGroup,num2Add,...
            "NumNeighbors",numNeighbors);
    case "Safe-level SMOTE"
        [newFeatures,~,idx] = mySafeLevelSMOTE(dataset,myGroup,num2Add,...
            "NumNeighbors",numNeighbors);
end

end