function [myMdl,myData] = compAnalysis(evalMatrix, myClassesCin, varnames, MySettings, saveLoc, fileInfos, flagTime)
% computes feature analysis encompassing feature selection, transformation,
% and classification
%
% INPUT: 
%   evalMatrix: double matrix of training data (columns: features, rows: observations)
%   myClassesCin: categorial including class labels of evalMatrix
%   varnames: cell array containing all channel names
%   MySettings: struct with settings for analysis
%   saveLoc: string containing save data location
%   fileInfos: cell array to be added when printing prediction in file
%
% OUTPUT:
%   myMdl: struct filled with classification model
%   myData: struct filled with data model
% 
% Authors: Aline Knab, Shannon Handley
% Date: 25.03.2024
%
% Last modified: 
%   13.03.2025 (Aline Knab): Feature selection per fold, validation model &
%       introducing final model using entire dataset; efficiency
%       improvement (folds in parallel to efficiently compute with large
%       data)

if nargin < 7 
    flagTime = true;
end
tStart_total = tic;

%% Update save location
if ~isempty(saveLoc)
    saveLoc = createSaveLoc({saveLoc,'Classification'});
end

%% Evaluations MySettings
if all(strcmpi('pca_lda',MySettings.transformations))
    MySettings.transformations = [{'pca'},{'lda'}];
elseif ~iscell(MySettings.transformations)
    MySettings.transformations = {MySettings.transformations};
end
MySettings.applyModel = false;

if strcmp(MySettings.myClassifier,'multi')
    myClassifier_opt = {'svm_lin', 'svm_poly', 'knn', 'naivebayes','lda', 'qda', 'logreg','tree'};
else
    myClassifier_opt = {MySettings.myClassifier};
end

%% Mixing data 
if MySettings.supervised 
    if any(contains(["crossval","leave1out"],MySettings.validation)) 
        rng('default'); % Testing
        if isempty(MySettings.myCvp)
            cvp = cvpartition(myClassesCin,'KFold',MySettings.kCross,'Stratify',true);
        else
            cvp = cvpartition("CustomPartition",MySettings.myCvp);
        end
    else
        cvp = cvpartition(myClassesCin,'HoldOut',(100-MySettings.percTraining)/100,'Stratify',true);
    end
else
    IdxPartition.training = true(size(evalMatrix,1),1);
    IdxPartition.test = [];
    cvp.NumTestSets = 1;
end

% Save model data
myData = combineAsStruct('evalMatrix', evalMatrix,'varnames',varnames,...
    'myClassesC', myClassesCin, ...
    'MySettings',MySettings,...
    'fileInfos',fileInfos); 
myMdl = struct;

%% Feature selection
tStart = tic;
[idxFeatures, idxFeaturesOrg] =  ...
    featureSelectionAlgorithm(evalMatrix, myClassesCin, varnames, cvp, MySettings,saveLoc);

tEnd = toc(tStart);
if flagTime, disp("Run time feature selection: "+string(tEnd)); end

%% kFold model
tStart = tic;

% Settings for hyperparameter tuning
if MySettings.Finetune
    if cvp.NumTestSets == 1
        cvpHyper = cvpartition(myClassesCin,'KFold',MySettings.kCross_hyper,'Stratify',true);
    else
        cvpHyper = cvp;
    end

    % Preallocate folds
    foldIdx_Hyper = zeros(size(myClassesCin));  
    for i = 1:cvpHyper.NumTestSets
        foldIdx_Hyper(test(cvp, i)) = i;
    end   
else
    cvpHyper = [];
    foldIdx_Hyper = [];
end

% Preallocate variables
myMdl_c_all = cell(1, numel(myClassifier_opt));
myData_c_all = cell(1, numel(myClassifier_opt));
ypred_all = cell(1, numel(myClassifier_opt));
yci_all = cell(1, numel(myClassifier_opt));
mislabeled_all = cell(1, numel(myClassifier_opt));
score_all = zeros(1, numel(myClassifier_opt));
idxMdl_all = zeros(1, numel(myClassifier_opt));

% Model generation
parfor iMethod = 1:size(myClassifier_opt,2) % parfor: only faster for small data

    myData_c = cell(1, cvp.NumTestSets);
    myMdl_c = cell(1, cvp.NumTestSets);
    ypred = cell(1, cvp.NumTestSets);
    yci = cell(1, cvp.NumTestSets);
    mislabeled = cell(1, cvp.NumTestSets);

    
    myClassesC = struct('total', cell(cvp.NumTestSets, 1),'training', cell(cvp.NumTestSets, 1),'test', cell(cvp.NumTestSets, 1));
    % parfor iFold = 1:cvp.NumTestSets  % PARFOR (testing: switch to for) -> for loop here more efficient for large data
    %     % Prepare settings
    %     localSettings = MySettings;
    %     localSettings.myClassifier = myClassifier_opt{iMethod};
    % 
    %     % Perpare variables
    %     evalMatrix_ch = evalMatrix(:,idxFeatures{iFold});
    %     % varnamesCh_lim = varnames(idxFeatures{iFold});
    % 
    %     % Partitioning
    %     myClassesC(iFold).total = myClassesCin;
    %     IdxPartition = struct('training', cell(1, 1), 'test', cell(1, 1));
    %     if localSettings.supervised 
    %         IdxPartition.training = training(cvp,iFold);
    %         IdxPartition.test = test(cvp,iFold);
    %         myClassesC(iFold).training = myClassesCin(IdxPartition.training);
    %         myClassesC(iFold).test = myClassesCin(IdxPartition.test);
    %     else
    %         IdxPartition.training = true(size(evalMatrix,1),1);
    %         IdxPartition.test = [];
    %         myClassesC(iFold).training = myClassesCin(IdxPartition.training);
    %     end
    % 
    %     % Transformations (PCA/LDA/...)
    %     [evalMatrix_t, myMdl_c_fold, myData_c_fold] = ...
    %         compTransformation(evalMatrix_ch, myClassesCin, IdxPartition, localSettings); 
    % 
    %     % Classification
    %     if localSettings.Finetune
    %         foldIdx_c = foldIdx_Hyper;
    %         % Remove and relable
    %         kept = foldIdx_c ~= iFold;
    %         foldIdx_c = foldIdx_c(kept);
    %         [~, ~, foldIdx_c] = unique(foldIdx_c, 'stable');
    %         cvpHyper_c = cvpartition("CustomPartition",foldIdx_c);
    %     else
    %         cvpHyper_c = [];
    %     end
    % 
    %     [myMdl_c{iFold}, myData_c{iFold}, ypred{iFold}, yci{iFold}, mislabeled{iFold}] = ...
    %         compClassification(evalMatrix_t,myClassesCin,localSettings,...
    %         IdxPartition, myMdl_c_fold, myData_c_fold, cvpHyper_c); 
    %     % myMdl_c(iFold).myClassesC = myClassesC; %results in error!
    % 
    %     % clear myMdl_c_fold myData_c_fold;
    % end
    if strcmp(myClassifier_opt{iMethod},"tree")
        for iFold = 1:cvp.NumTestSets
            [myMdl_c{iFold}, myData_c{iFold}, ypred{iFold}, yci{iFold}, mislabeled{iFold},myClassesC(iFold)] = ...
                runClassification(evalMatrix, myClassesCin, idxFeatures, iFold, foldIdx_Hyper,...
                MySettings, myClassifier_opt{iMethod}, cvp);
        end

    else
        
        for iFold = 1:cvp.NumTestSets
            [myMdl_c{iFold}, myData_c{iFold}, ypred{iFold}, yci{iFold}, mislabeled{iFold},myClassesC(iFold)] = ...
                runClassification(evalMatrix, myClassesCin, idxFeatures, iFold, foldIdx_Hyper,...
                MySettings, myClassifier_opt{iMethod}, cvp);
        end
    end
    
    myMdl_c = cell2mat(myMdl_c);            myMdl_c_all{iMethod} = myMdl_c;
    myData_c = cell2mat(myData_c);          myData_c_all{iMethod} = myData_c;
    ypred = cell2mat(ypred);                ypred_all{iMethod} = ypred;
    yci = cell2mat(yci);                    yci_all{iMethod} = yci;
    mislabeled = cell2mat(mislabeled);      mislabeled_all{iMethod} = mislabeled;

    if MySettings.supervised  && cvp.NumTestSets > 1 
        [idxMdl,myScore] = evalMdl(myClassesC,MySettings.groups,ypred,yci,cvp,MySettings.perfMetric_final); % output measure!!!
        score_all(iMethod) = myScore;
        idxMdl_all(iMethod) = idxMdl;
    else
        idxMdl_all(iMethod) = 1;
    end

end 

if MySettings.supervised  && cvp.NumTestSets > 1 
    [~, bestIdx] = max(score_all);
else
    bestIdx = 1;
end
myMdl_c = myMdl_c_all{bestIdx};
myData_c = myData_c_all{bestIdx};
ypred = ypred_all{bestIdx};
yci = yci_all{bestIdx};
mislabeled = mislabeled_all{bestIdx}; 
MySettings.myClassifier_org = MySettings.myClassifier;
MySettings.myClassifier = myClassifier_opt{bestIdx};
idxMdl = idxMdl_all(bestIdx);

[myMdl_c.idxFeatures] = idxFeatures{:};     
[myData_c.idxFeatures] = idxFeatures{:};
[myMdl_c.idxFeaturesOrg] = idxFeaturesOrg{:};
[myData_c.idxFeaturesOrg] = idxFeaturesOrg{:};
featureNamesCell = cellfun(@(idx) varnames(idx), idxFeatures, 'UniformOutput', false);
[myMdl_c.varnamesCh_lim] = featureNamesCell{:};
[myData_c.varnamesCh_lim] = featureNamesCell{:};

% select best method and model
myMdl = combineAsStruct(myMdl,'Mdls_classifier',myMdl_c);

% Merge myMdl and myData
myMdl = combineAsStruct(myMdl, 'Mdl_classifier',myMdl_c(idxMdl),...
    'idxMdl',idxMdl,'MySettings',MySettings);
fieldnames_data = fieldnames(myData_c(idxMdl));
for iField = 1:numel(fieldnames_data)
    myData.(fieldnames_data{iField}) = myData_c(idxMdl).(fieldnames_data{iField});
end
myData = combineAsStruct(myData,'ypred',ypred,'yci',yci,...
    'mislabeled',mislabeled,'cvp',cvp);
clear myMdl_c_fold  myMdl_c_fold;

tEnd = toc(tStart);
if flagTime, disp("Run time k-fold model: "+string(tEnd)); end

%% Final model
tStart = tic;
if MySettings.supervised  
    IdxPartition.training = true(size(evalMatrix,1),1);
    IdxPartition.test = [];

    % Adjust settings
    cvp = struct; cvp.NumTestSets = 1;
    
    % Feature selection
    [idxFeatures_final, idxFeaturesOrg_final] =  ...
        featureSelectionAlgorithm(evalMatrix, myClassesCin, varnames, cvp, MySettings,saveLoc);

    % Transformation (PCA/LDA/...)
    [evalMatrix_t, myMdl_final, myData_final] = ...
        compTransformation(evalMatrix(:,idxFeatures_final{1}), myClassesCin, ...
        IdxPartition, MySettings); 
    
    % Classification
    [myMdl_final, myData_final, ypred_final, yci_final, mislabeled_final] = ...
        compClassification(evalMatrix_t,myClassesCin,MySettings,...
        IdxPartition, myMdl_final, myData_final, cvpHyper);

    myMdl_final.idxFeatures = idxFeatures_final;
    myData_final.idxFeatures = idxFeatures_final;
    myMdl_final.idxFeaturesOrg = idxFeaturesOrg_final;
    myData_final.idxFeaturesOrg = idxFeaturesOrg_final;
    myMdl_final.varnamesCh_lim = varnames(idxFeatures_final{:});
    myData_final.varnamesCh_lim = varnames(idxFeatures_final{:});
    % myMdl_final.varnamesCh_lim = cellfun(@(idx) varnames(idx), idxFeatures_final, 'UniformOutput', false);
    % myData_final.varnamesCh_lim = cellfun(@(idx) varnames(idx), idxFeatures_final, 'UniformOutput', false);

    myMdl = combineAsStruct(myMdl, 'Mdl_classifier_final', myMdl_final);
    fieldnames_data = fieldnames(myData_final);
    for iField = 1:numel(fieldnames_data)
        myData.(append(fieldnames_data{iField},"_final")) = myData_final.(fieldnames_data{iField});
    end
    myData = combineAsStruct(myData,'ypred_final',ypred_final,'yci_final',yci_final,...
        'mislabeled_final',mislabeled_final);
else 
    myMdl = combineAsStruct(myMdl, 'Mdl_classifier_final', myMdl_c);
    fieldnames_data = fieldnames(myData_c(idxMdl));
    for iField = 1:numel(fieldnames_data)
        myData.(append(fieldnames_data{iField},"_final")) = myData_c(idxMdl).(fieldnames_data{iField});
    end
    myData = combineAsStruct(myData,'ypred_final',ypred,'yci_final',yci,...
        'mislabeled_final',mislabeled);
end

tEnd = toc(tStart);
if flagTime, disp("Run time final model: "+string(tEnd)); end

%% Save
if ~isempty(saveLoc)
    if ~isempty(fileInfos) %&& MySettings.supervised
        cellPartition = cell(size(ypred(idxMdl).total,1),1);
        cellPartition(myMdl.Mdl_classifier.IdxPartition.training) = {"training"};
        cellPartition(myMdl.Mdl_classifier.IdxPartition.test) = {"test"};
        fileInfos = [fileInfos, cellPartition];
        writeClassPrediction(ypred(idxMdl).total,fileInfos,saveLoc);
    end
    
    tEnd_total = toc(tStart_total);
    myTime = string(datetime('now','Format','yyyy-MM-dd_HH-mm-ss'));
    save(fullfile(saveLoc,"Mdl_"+myTime+".mat"), "myMdl");
    writeMyMdlInfo(myMdl,saveLoc,myTime,tEnd_total);
    save(fullfile(saveLoc,"Data_"+myTime+".mat"), "myData");
end


end


function [myMdl_c, myData_c, ypred, yci, mislabeled,myClassesC] = ...
    runClassification(evalMatrix, myClassesCin, idxFeatures, iFold, foldIdx_Hyper,...
    MySettings, myClassifier_opt, cvp)

        % Prepare settings
        localSettings = MySettings;
        localSettings.myClassifier = myClassifier_opt;

        % Perpare variables
        evalMatrix_ch = evalMatrix(:,idxFeatures{iFold});
        % varnamesCh_lim = varnames(idxFeatures{iFold});
        
        % Partitioning
        myClassesC.total = myClassesCin;
        IdxPartition = struct('training', cell(1, 1), 'test', cell(1, 1));
        if localSettings.supervised 
            IdxPartition.training = training(cvp,iFold);
            IdxPartition.test = test(cvp,iFold);
            myClassesC.training = myClassesCin(IdxPartition.training);
            myClassesC.test = myClassesCin(IdxPartition.test);
        else
            IdxPartition.training = true(size(evalMatrix,1),1);
            IdxPartition.test = [];
            myClassesC.training = myClassesCin(IdxPartition.training);
        end

        % Transformations (PCA/LDA/...)
        [evalMatrix_t, myMdl_c_fold, myData_c_fold] = ...
            compTransformation(evalMatrix_ch, myClassesCin, IdxPartition, localSettings); 
        
        % Classification
        if localSettings.Finetune
            foldIdx_c = foldIdx_Hyper;
            % Remove and relable
            kept = foldIdx_c ~= iFold;
            foldIdx_c = foldIdx_c(kept);
            [~, ~, foldIdx_c] = unique(foldIdx_c, 'stable');
            cvpHyper_c = cvpartition("CustomPartition",foldIdx_c);
        else
            cvpHyper_c = [];
        end

        [myMdl_c, myData_c, ypred, yci, mislabeled] = ...
            compClassification(evalMatrix_t,myClassesCin,localSettings,...
            IdxPartition, myMdl_c_fold, myData_c_fold, cvpHyper_c); 
    end