function myStructOut = reassignEvalMatrix(myStructOrg,myStructIn,myCategory)
% reassign structure data
%
% INPUT: 
%   myStructOrg: original structure (structure to assign to)
%   myStructIn: input structure (fields are copied from here
%   myCategory: subfields of evalMatrix to copy
%
% OUTPUT
%   myMdl: struct filled with classification model
%   myData: struct filled with data model
% 
% Authors: Aline Knab
% Date: 18.12.2023

myStructOut = myStructOrg;
myFields = fieldnames(myStructIn);
for iField = 1:size(myFields,1)
    field_c = myFields{iField};
    if contains(field_c,"evalMatrix") && isstruct(myStructOut.(field_c)) && ...
            isstruct(myStructIn.(field_c)) && ~isempty(myCategory) 
        subField = string(fieldnames(myStructIn.(field_c)));
        myStructOut.(field_c).(myCategory) = myStructIn.(field_c).(subField);
    end
end

end