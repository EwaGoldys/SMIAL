function v = seq_nchoosek(n,k)
% Sequential NCHOOSEK
% N and K non negative integers k <= n
% seq_nchoosek(n,k)     % reset the sequence of combination 
% v = seq_nchoosek()    % query the next combination
% 
% % Example of calling sequence:
%   seq_nchoosek(5,3)
%   while true
%       c = seq_nchoosek()
%       if size(c,1)==0
%           break
%       end
%       % ... do something with c
%   end
%
% See also: NCHOOSEK
% https://www.mathworks.com/matlabcentral/answers/480216-huge-matrix-with-nchoosek

persistent V S I K
if nargin >= 2
    % reset
    if ~(isscalar(n) && isscalar(k))
        error('seq_nchoosek: n and k must be scalars');
    end
    if k > n
        error('seq_nchoosek: k must be smaller or equal to n');
    end
    if n == 0
        V = [];
    else
        k = floor(k);
        n = floor(n);
        if n < 0 || k < 0
            error('seq_nchoosek: n and k must non negative integers');
        end
        V = 1:k; 
        I = k;
        K = k;
        S = V+(n-k);
    end
end
if nargout >= 1
    % query
    v = V;
    if size(V,1) > 0
        % move to next
        I = find(V-S,1,'last');
        if ~isempty(I)
            V(I) =  V(I)+1;
            V(I+1:K) =  V(I)+(1:K-I);
        else
            V = [];
        end
    end
end
end