function [myData] = applyModel(evalMatrix, myMdl,saveLoc)
% applies previously computed classification model 
%
% INPUT:
%   evalMatrix: double matrix of data (columns: features, rows: observations)
%   myMdl: classification model
%   saveLoc: path to save data
%
% OUTPUT:
%   myData: struct filled with data model
%
% Author: Aline Knab
% Date:11.09.2024

if nargin > 2
    saveLoc = createSaveLoc({saveLoc,'Classification'});
end

%% Model application 

% create storage options
myData = struct;
myData.MySettings = myMdl.MySettings;


% apply according to myMdl
[myData.evalMatrix_t, ~] = ...
    compNormalize(evalMatrix,myData.MySettings.normalizeType, myMdl.Mdl_classifier_final.normVal);

% data transformation 
for i = 1:size(myData.MySettings.transformations,2)
    myTransform = myData.MySettings.transformations{i};
    switch lower(myTransform)
        case{'pca'}
            myData.evalMatrix_t = applyPCA(myData.evalMatrix_t,...
                myMdl.Mdl_classifier_final.coeffTraining,myMdl.Mdl_classifier_final.numPCs);
            myData.evalMatrix_PCA = myData.evalMatrix_t;
        case{'lda'}
            myData.evalMatrix_t = applyLDA(myData.evalMatrix_t,...
                myMdl.Mdl_classifier_final.W);
            myData.evalMatrix_LDA = myData.evalMatrix_t;
        case{'tsne'}
            f = msgbox("t-SNE cannot classify new data points due to its nonlinear, data-dependent mapping.");
            return;
        case{'sparse'}
            myData.evalMatrix_t = transform(myMdl.Mdl_classifier_final.obj,...
                myData.evalMatrix_t);
            myData.evalMatrix_sparse = myData.evalMatrix_t;
        % otherwise
        %     myData.evalMatrix_t = myData.evalMatrix_t;
    end
end

% data classification
if contains(myData.MySettings.myClassifier,{'svm_lin';'svm_poly';'knn';'naivebayes';'lda';'qda';'logreg';'tree';'ensemble'})
    [myData.ypred,myData.yci,~] = ...
        predictMdl(myMdl.Mdl_classifier_final.Mdl_classifier,myData.evalMatrix_t,[]);
elseif contains(myData.MySettings.myClassifier,{'kmeans';'fuzzy'})
    [myData.ypred] = predictDistance(myData.evalMatrix_t.evalMatrix_t,myMdl.C);
    myData.yci.total = [];
end

if size(myData.ypred,1)<size(myData.ypred,2)
    myData.ypred = myData.ypred.';
end

if ~iscategorical(myData.ypred)
    myData.ypred = categorical(myData.ypred);
end

myData.varnamesCh_lim = myMdl.Mdl_classifier_final.varnamesCh_lim; 

if nargin > 2 && ~isempty(saveLoc)
    myData.MySettings.applyModel = true;
    save(fullfile(saveLoc,"Data_"+string(datetime('now','Format','yyyy-MM-dd_HH-mm-ss'))+".mat"), "myData");
end

% myData.evalMatrix_t =  myData.evalMatrix_t.total; 

end