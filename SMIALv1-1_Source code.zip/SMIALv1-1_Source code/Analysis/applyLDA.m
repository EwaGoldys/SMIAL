function [evalMatrix_test_t] = applyLDA(evalMatrix_test,W)
% applies LDA transformation to training and testing dataset 
%
% INPUT: 
%   evalMatrix_test: double matrix of test data (columns: features, rows: observations)
%   W: transformation matrix
%
% OUTPUT
%   evalMatrix_test_t: transformed test dataset limited to relevant PCs
% 
% Authors: Aline Knab
% Date: 12.11.2023
                
evalMatrix_test_t = evalMatrix_test*W;

end