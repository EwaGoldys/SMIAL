function [DOR] = diagnosticsOddsRatios(sensitivity,specificity)
% Function to calculate the Diagnostics Odds Ratios
%
% INPUT: 
%   sensitivity: double 
%   specificity: double
%
% OUTPUT
%   DOR: double, diagnostics odds ratios
% 
% Authors: Shannon Handley
% Date: 14.11.2023

DOR = (sensitivity.*specificity)./((1-sensitivity).*(1-specificity));

end
