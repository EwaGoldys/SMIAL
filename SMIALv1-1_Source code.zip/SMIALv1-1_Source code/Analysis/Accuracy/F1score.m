function [F1] = F1score(TP,FP,FN)
% Function to calculate F1 score
%
% INPUT: 
%   TP: double, number of true positives
%   FP: double, number of false positives
%   FN: double, number of false negatives
%
% OUTPUT
%   F1: double, F1 score
% 
% Authors: Shannon Handley
% Date: 14.11.2023

F1 = 2.*TP./(2.*TP + FP + FN);

end
