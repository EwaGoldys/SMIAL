function [fracCorrect] = labellingAccuracyPercentage(ypred,myClassesC,myGroups)
% Function to determine percentage of correct labels detected
%
% INPUT: 
%   ypred: categorical, predicted class labels
%   myClassesC: categorical, correct class labels
%   myGroups: categorical, group names
%
% OUTPUT
%   fracCorrect: double, fraction of correctly labeled observations [%]
% 
% Authors: Shannon Handley, Aline Knab
% Date: 14.11.2023

if nargin<3
    myGroups = unique(myClassesC);
end

numGroups = size(myGroups,1);
fracCorrect = zeros(1,numGroups);

for i = 1:numGroups
    % Should be current group
    myClassesC_g = myClassesC(myClassesC==myGroups(i));
    ypred_g = ypred(myClassesC==myGroups(i));
    
    % identify mislabelled thereof
    mislabeled = categorical(ypred_g)==myClassesC_g;
    mislabeled = find(mislabeled==0);
    
    % count mislabelled
    numMislabeled = size(mislabeled,1);
    numLabeled = size(myClassesC_g,1);
    
    % convert to percentage
    fracCorrect(i) = (numLabeled-numMislabeled)/numLabeled*100;
end

end


