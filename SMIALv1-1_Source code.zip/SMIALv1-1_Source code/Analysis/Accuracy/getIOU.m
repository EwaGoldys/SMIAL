function [IOU_percentage] = getIOU(pgon,IOU_2classidx,IOU_allclassidx)
% computes percentage of IoU
%
% INPUT:
%   pgon:  polyshape object
%   IOU_2classidx: array containing two vclass indexes for the IOU of the
%       std ellipse to be calculated 
%   IOU_allclassidx: array of all classes. 
%
% OUTPUT:
%   IOU_percentage: intersection over union (IoU) in percent
%
% Author: Shannon Handley
% Date: 24.03.2024

%% IoU for two classes
if ~isempty(IOU_2classidx)
    classidx = str2double(split(IOU_2classidx,","));

    G1 = pgon(1, classidx(1));
    G2 = pgon(1, classidx(2));

    Area_G1 = area(G1);
    Area_G2 = area(G2);

    C = intersect(G1,G2);
    % [Cx,Cy] = boundary(C);

    if C.NumRegions == 1
        Area_C = area(C);
    else
        Area_C = 0;
    end

    area_pgon_comb = Area_G1 + Area_G2;
    IOU_percentage = Area_C/area_pgon_comb*100;

%% Average IoU for all classes
elseif ~isempty(IOU_allclassidx)

    G1 = pgon(1, 1);
    G2 = pgon(1, 2);

    Area_G1 = area(G1);
    Area_G2 = area(G2);

    C = intersect(G1,G2);
    % [Cx,Cy] = boundary(C);

    if C.NumRegions == 1
        Area_C = area(C);
    else
        Area_C = 0;
    end

    area_pgon_comb = Area_G1 + Area_G2;

    D = union(G1,G2);   %combing two ellipses to then join with the remaining ellipses

    %for 3 or more classes
    if size(pgon,2) > 2
        for i = 3:size(pgon,2)
            C = intersect(D,pgon(1,i));

            %combined ellipse area
            D = union(D,pgon(1,i));
            area_pgon_comb = area(D);

            if C.NumRegions == 1
                Area_C = (Area_C + area(C));
            else
                Area_C = Area_C;
            end
        end
    end
    IOU_percentage = Area_C/area_pgon_comb*100;

    IOU_percentage = (IOU_percentage);

end

end