function myTransformedScores = rescaleMyScores(myScores)

% Transforming scores for multi-class classification.
if iscell(myScores)
    % Rescaling each fold of cross-validated data
    myTransformedScores = cellfun(@(s) rescaleMyScores(s), myScores, 'UniformOutput', false);
else
    if size(myScores, 2) <= 1
        myTransformedScores = myScores;
    else 
        myTransformedScores = myScores;
        idx = 1:size(myScores, 2);
        for i = idx % scale scores for each class relative to the others
            idx_c = idx == i;
            myTransformedScores(:,i) = myScores(:,idx_c) - max(myScores(:,~idx_c), [], 2);

            if i % handle ties
                myTies = find(myTransformedScores(:,i) == 0);
                prevFound = any(myScores(myTies,1:i-1) == myScores(myTies,i), 2);
                myTies = myTies(prevFound);
                myTransformedScores(myTies,i) = -realmin;
            end
        end        
    end
end
end