function [myAUC, rocObj] = compROC(yci,myClassesC,cvp,myGroups,idxMdl,dataComp,evalType)
% AUC and ROC computation
% 
% INPUT: 
%   yci: struct with double arrays of predicted class post. probabilities 
%   myClassesC: categorial class labels of data
%   cvp: data partition
%   myGroups: categorical array with group names
%   idxMdl: index of best model
%   dataComp: string specifying data computation option (test, training,
%       total)
%   evalType: evaluation type ('holdout'=bootstrapping, 'crossval')
% 
% OUTPUT:
%   myAUC: double array with 
%       row 1: AUC value
%       row 2: lower confidence interval
%       row 3: upper confidence interval
%   rocObj: roc Object
% 
% Authors: Aline Knab
% Date: 25.02.2024

if nargin < 4
    myGroups = unique(myClassesC);
end

myGroups = categorical(myGroups);

if strcmp(evalType,'false') || ...
        strcmp(evalType,'holdout') || ...
        any(ismember(dataComp,["training";"total"])) % hold-out or training/total dataset

    % get indices
    if strcmp(dataComp,"total")
        myIdx = (1:size(myClassesC,1)).';
    else
        if isstruct(cvp) 
            myIdx = cvp.(dataComp);
        else
            myIdx = cvp.(dataComp)(idxMdl);
        end
    end

    % get classes
    myClassesC_c = myClassesC(myIdx);

    % no confidence interval
    if strcmp(evalType,'false') 
        rocObj = rocmetrics(myClassesC_c,yci(idxMdl).(dataComp),myGroups);
    
    % hold-out or training/total dataset 
    elseif strcmp(evalType,'holdout') || ...
            any(ismember(dataComp,["training";"total"]))        
        % Bootstrapping
        numBoots = ceil(size(myClassesC_c,1)/10);
        rocObj = rocmetrics(myClassesC_c,yci(idxMdl).(dataComp),myGroups,NumBootstraps=numBoots);
    end
else % crossvalidation & test dataset
    if strcmp(dataComp,"test") && size(yci(1).(dataComp),1) == 1
        ttLabel = categorical(nan(size(yci,2),1));
        for i = 1:size(yci,2)
            ttLabel(i) = myClassesC(test(cvp,i));
        end
        ttYci = nan(size(yci,2),length(myGroups));
        for i = 1:size(yci,2)
            yci_c = yci(i).test;
            ttYci(i,:) = yci_c;
        end
        numBoots = ceil(sqrt(size(myClassesC,1)));
        rocObj = rocmetrics(ttLabel,ttYci,myGroups,NumBootstraps=numBoots);                   
    else
        % combine classes & yci
        cvpLabels = cell(cvp.NumTestSets,1);
        cvpYci = cell(cvp.NumTestSets,1);
        for k = 1:cvp.NumTestSets
            cvpLabels{k} = myClassesC(cvp.(dataComp)(k),:);
            cvpYci{k} = yci(k).(dataComp);
        end 
        % Cross-validation
        rocObj = rocmetrics(cvpLabels,cvpYci,myGroups);
    end
end

myAUC = rocObj.AUC;

end