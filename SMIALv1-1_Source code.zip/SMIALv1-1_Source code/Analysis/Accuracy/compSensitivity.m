function [sensitivity] = compSensitivity(TP,FN)
% Function to calculate sensitivity
%
% INPUT: 
%   TP: double, number of true positives
%   FN: double, number of false negatives
%
% OUTPUT
%   sensitivity: double
% 
% Authors: Shannon Handley
% Date: 14.11.2023

sensitivity = TP./(TP+FN);

end
