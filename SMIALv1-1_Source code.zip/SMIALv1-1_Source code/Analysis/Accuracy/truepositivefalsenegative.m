function [TP,FP,TN,FN] = truepositivefalsenegative(myClassesC,myClassesC_predicted,myGroups)
% Function to calculate TP, FP, TN and FN
%
% INPUT: 
%   myClassesC: categorical, correct class labels
%   myClassesC_predicted: categorical, predicted class labels
%   myGroups: categorical, group names
%
% OUTPUT
%   TP: double, number of true positives
%   FP: double, number of false positives
%   TN: double, number of true negatives
%   FN: double, number of false negatives
% 
% Authors: Shannon Handley
% Date: 14.11.2023

% index labels
numClasses = size(myGroups,1);
if numClasses == 2
    numClasses = 1;
end
TP=zeros(1,numClasses);
FP=TP; TN=TP; FN=TP;

for iClass = 1:numClasses
    myClassesC_classI = myClassesC==myGroups(iClass);
    myClassesC_predicted_classI = myClassesC_predicted==myGroups(iClass);
    TP(iClass) = sum(and(myClassesC_classI, myClassesC_predicted_classI));
    FN(iClass) = sum(and(myClassesC_classI, ~ myClassesC_predicted_classI));
    FP(iClass) = sum(and(~myClassesC_classI, myClassesC_predicted_classI));
    TN(iClass) = sum(and(~myClassesC_classI, ~myClassesC_predicted_classI));
end

end

