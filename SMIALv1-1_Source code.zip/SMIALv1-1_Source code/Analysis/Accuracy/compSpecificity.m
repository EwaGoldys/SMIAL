function [specificity] = compSpecificity(TN,FP)
% Function to calculate specificity
%
% INPUT: 
%   TN: double, number of true negatives
%   FP: double, number of false positives
%
% OUTPUT
%   specificity: double
% 
% Authors: Shannon Handley
% Date: 14.11.2023

specificity = TN./(TN+FP);

end
