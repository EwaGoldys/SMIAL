function [PPV] = positivePredictedValue(TP,FP)
% Function to calculate the positive predicted value
%
% INPUT: 
%   TP: double, number of true positives
%   FP: double, number of false positives
%
% OUTPUT
%   PPV: double, positive predicted value
% 
% Authors: Shannon Handley
% Date: 14.11.2023

PPV = TP./(TP+FP);

end
