function [FPR] = compFPR(FP,TN)
% Function to calculate false positive rate
%
% INPUT: 
%   FP: double, number of false positives
%   TN: double, number of true negatives
%
% OUTPUT
%   FPR: double, false positive rate
% 
% Authors: Shannon Handley
% Date: 14.11.2023

FPR = FP./(FP+TN);

end
