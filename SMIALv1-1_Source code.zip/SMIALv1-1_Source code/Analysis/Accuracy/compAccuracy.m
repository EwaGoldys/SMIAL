function [tab] = compAccuracy(yci,ypred,myClassesC_in,IdxPartition,idxMdl,...
    myGroups,myOptionsComp,myOptionsData,saveLoc,roundDec,saveFormat,myPanel)
% computes validation for classification
%
% INPUT: 
%   yci: struct with double array of predicted class post. probabilities
%   ypred: struct with categorial array of predicted class label 
%   myClassesC: class labels
%   IdxPartition: structure with logical (training/test/total) for
%       partitioning
%   idxMdl: integer indicating best model (1 if data not cross-validated)
%   myGroups: cell array with group names
%   myOptionsComp: computation options
%   myOptionsData: data options (training, test, total,mislabeled)
%   saveLoc: string with pathname of save location
%   roundDec: numerical for number of decimals (default: 4)
%   saveFormat: string with image save format, e.g. ".png"
%   myPanel: panel object to draw in
%
% OUTPUT:
%   tab: table including validation results
% 
% Authors: Aline Knab, Shannon Handley
% Date: 25.02.2024
%
% Last modified:
%   15.03.2025 (Aline Knab): converted structure variables to total only;
%       variable decimals

if nargin < 10
    roundDec = 4;
end

if nargin > 10 && ~isempty(saveLoc)
    saveLoc = createSaveLoc({saveLoc,'Classification'});
end

%% Verify options & set-up basics
myOptionsData = myOptionsData(ismember(cellstr(myOptionsData),cellstr(fieldnames(ypred(1)))));

numGroups = size(myGroups,1);
myStart = 1:numGroups:size(myOptionsData,2)*numGroups;

myRowNames = myOptionsComp;
myRowNames(:,contains(myOptionsComp,'Confusion Matrix')) = [];

% set up table for results
tab = table('Size',[size(myRowNames,2),size(myOptionsData,2)*numGroups],...
    'VariableTypes',repmat("double",1,size(myOptionsData,2)*numGroups));
myTab = struct;

if isstruct(yci)  && isfield(yci,'total') && ~isempty(yci(1).total) 
    kFold = size(yci,2);
    if any(ismember(cellstr(myOptionsData),'test')) && kFold>1
        myOptionsData = [myOptionsData,'test_total'];

        ypredTest = categorical(nan(size(ypred(1).total,1),1));
        yciTest = nan(size(yci(1).total,1),size(yci(1).total,2));
        myClassesCTest = categorical(nan(size(myClassesC_in,1),1));
        idxYpred_test = 1;

        ttYci = cell(size(yci,2),1);
        
        for i = 1:size(yci,2)
            ypredTest(idxYpred_test:idxYpred_test+size(ypred(i).test,1)-1) = ...
                ypred(i).test;
            yciTest(idxYpred_test:idxYpred_test+size(yci(i).test,1)-1,:) = ...
                yci(i).test;
            myClassesCTest(idxYpred_test:idxYpred_test+size(ypred(i).test,1)-1) = ...
                myClassesC_in(IdxPartition(i).test);
            idxYpred_test = idxYpred_test+size(yci(i).test,1);
            ttYci{i} = yci(i).test;
        end
        [ypred.test_total] = deal(nan); ypred(idxMdl).test_total = ypredTest;
        [yci.test_total] = deal(nan); yci(idxMdl).test_total = yciTest;
        % myClassesC.test_total = myClassesCTest;

        ttYci = rescaleMyScores(ttYci);
        for i = 1:size(yci,2)
            yci(i).test = ttYci{i};
        end

        tab_test = table('Size',[size(myRowNames,2),numGroups],...
            'VariableTypes',repmat("double",1,numGroups));
    end
else
    kFold = 1;
end

if any(ismember(cellstr(myOptionsComp),"AUC"))
    myAUC = nan([1,size(myOptionsData,2)*numGroups]);
end

for k = 1:kFold
    myTab(k).tab = tab;
    count = 1;

    myClassesC_c = struct;

    %% Compute basics
    TP = struct;
    FP=TP; TN=TP; FN=TP;
    for iData = 1:size(myOptionsData,2)
        if((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
            (~strcmp(myOptionsData{iData},'test_total')))

            if strcmp(myOptionsData{iData},'total')
                myClassesC_c.total = myClassesC_in;
            elseif strcmp(myOptionsData{iData},'training')
                myClassesC_c.training = myClassesC_in(IdxPartition(k).training);
            elseif strcmp(myOptionsData{iData},'test')
                myClassesC_c.test = myClassesC_in(IdxPartition(k).test);
            elseif strcmp(myOptionsData{iData},'test_total')
                myClassesC_c.test_total = myClassesCTest;
            end
            
            [TP.(myOptionsData{iData}),FP.(myOptionsData{iData}),TN.(myOptionsData{iData}),FN.(myOptionsData{iData})] = ...
                truepositivefalsenegative(myClassesC_c.(myOptionsData{iData}),ypred(k).(myOptionsData{iData}),myGroups);
            sensitivity.(myOptionsData{iData}) = compSensitivity(TP.(myOptionsData{iData}),FN.(myOptionsData{iData}));
            specificity.(myOptionsData{iData}) = compSpecificity(TN.(myOptionsData{iData}),FP.(myOptionsData{iData}));
        end
    end

    %% AUC 
    if ~isempty(find(ismember(cellstr(myOptionsComp),"AUC"), 1)) %&& isfield(yci,'total') && ~isempty(yci(1).total) 
        for iData = 1:size(myOptionsData,2)
            if strcmp(myOptionsData{iData},'test_total')
                break;
            end
            labelsAUC = myClassesC_c.(myOptionsData{iData});
            dataAUC = yci(k).(myOptionsData{iData});
            if ~strcmp(myOptionsData{iData},'test') || kFold == 1
                dataAUC = rescaleMyScores(dataAUC);
            end
            for iClass = 1:size(myGroups,1)
                if size(labelsAUC,1)>1 && length(unique(labelsAUC))>1
                    [~,~,~,AUC] = perfcurve(labelsAUC,dataAUC(:,iClass),myGroups(iClass));                        
                else
                    AUC = 0;
                end
                myTab(k).tab(count,myStart(iData)+iClass-1) = num2cell(AUC);
                if k == idxMdl % aligning with visualROC
                    if strcmp(myOptionsData{iData},'test') && kFold > 1
                        ttLabel = cell(size(yci,2),1);
                        for i = 1:size(yci,2)
                            ttLabel{i} = [myClassesC_in(IdxPartition(i).test)];
                        end
                        ttYci = cell(size(yci,2),1);
                        for i = 1:size(yci,2)
                            yci_c = yci(i).test;
                            ttYci{i} = yci_c(:,iClass);
                        end
                        [~,~,~,AUC] = perfcurve(ttLabel,ttYci,myGroups(iClass));
                    else
                        [~,~,~,AUC] = perfcurve(labelsAUC,dataAUC(:,iClass),myGroups(iClass));
                        % numBoots = ceil(size(labelsAUC,1)/10);
                        % [~,~,~,AUC] = perfcurve(cellstr(ttLabel),ttYci,myGroups(iClass),'NBoot',numBoots);
                    end
                    myAUC(myStart(iData)+iClass-1) = AUC(1);
                end
            end
        end
        count = count + 1;
    end

    %% Confusion matrix
    if k==idxMdl && ~isempty(find(ismember(cellstr(myOptionsComp),"Confusion Matrix"), 1)) 
        delete(myPanel.Children); 
        for iData = 1:size(myOptionsData,2)  
            if strcmp(myOptionsData{iData},'test_total')
                break
            end
            % confusion matrix
            myOptionsData_c = myOptionsData{iData};
            if isfield(ypred,'test_total') && strcmp(myOptionsData_c,'test')
                myOptionsData_c = 'test_total';
            end
            cm = confusionchart(myPanel,myClassesC_c.(myOptionsData_c),ypred(idxMdl).(myOptionsData_c));
            cm.Title = "Confusion matrix, "+myOptionsData{iData};
            cm.DiagonalColor = [0.00,0.74,0.67];
            cm.OffDiagonalColor = [0.95,0.09,0.25];
            fileName = fullfile(saveLoc,"ConfusionMatrix_"+myOptionsData{iData}+"."+ saveFormat);
            saveGuiFigure(myPanel,fileName);
        end
        myOptionsComp(strcmp(myOptionsComp, "Confusion Matrix")) = [];
    end

    %% Balanced Accuracy
    if find(ismember(cellstr(myOptionsComp),"Balanced Accuracy"))             
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myBalancedAccuracy = num2cell(...
                    balancedAccuracy(sensitivity.(myOptionsData{iData}),specificity.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myBalancedAccuracy;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myBalancedAccuracy;
                end
            end
        end
        count = count + 1;
    end

    %% F1 Score
    if find(ismember(cellstr(myOptionsComp),"F1 Score"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myF1Score = num2cell(...
                    F1score(TP.(myOptionsData{iData}),FP.(myOptionsData{iData}),FN.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myF1Score;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myF1Score;
                end
            end            
        end
        count = count + 1;
    end

    %% Diagnostics Odds Ratios
    if find(ismember(cellstr(myOptionsComp),"Diagnostic Odds Ratio"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myDiagnosticOddsRatio = num2cell(...
                    diagnosticsOddsRatios(sensitivity.(myOptionsData{iData}),specificity.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myDiagnosticOddsRatio;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myDiagnosticOddsRatio;
                end
            end
        end
        count = count + 1;
    end

    %% False Positive Rate
    if find(ismember(cellstr(myOptionsComp),"False Positive Rate"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myFalsePositiveRate = num2cell(...
                    compFPR(FP.(myOptionsData{iData}),TN.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myFalsePositiveRate;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myFalsePositiveRate;
                end
            end
        end
        count = count + 1;
    end

    %% True Positive Rate
    if find(ismember(cellstr(myOptionsComp),"True Positive Rate"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myTruePositiveRate= num2cell(...
                    sensitivity.(myOptionsData{iData}));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myTruePositiveRate;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myTruePositiveRate;
                end
            end
        end
        count = count + 1;
    end

    %% Negative Predicted Value
    if find(ismember(cellstr(myOptionsComp),"Negative Predicted Value"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myNegativePredictedValue = num2cell(...
                    negativePredictedValue(TN.(myOptionsData{iData}),FN.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myNegativePredictedValue;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myNegativePredictedValue;
                end
            end
        end
        count = count + 1;
    end

    %% Positive Predicted Value
    if find(ismember(cellstr(myOptionsComp),"Positive Predicted Value"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myPositivePredictedValue = num2cell(...
                    positivePredictedValue(TP.(myOptionsData{iData}),FP.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myPositivePredictedValue;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myPositivePredictedValue;
                end
            end
        end
        count = count + 1;
    end

    %% Correctly Labelled [%]
    if find(ismember(cellstr(myOptionsComp),"Correctly Labelled [%]"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myCorrectlyLabelled = num2cell(...
                    labellingAccuracyPercentage(ypred(k).(myOptionsData{iData}),myClassesC_c.(myOptionsData{iData}),myGroups));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myCorrectlyLabelled;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myCorrectlyLabelled;
                end
            end
        end
        count = count + 1;
    end

    %% Precision
    if find(ismember(cellstr(myOptionsComp),"Precision"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                myPrecision = num2cell(...
                    compPrecision(TP.(myOptionsData{iData}),FP.(myOptionsData{iData})));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = myPrecision;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = myPrecision;
                end
            end
        end
        count = count + 1;
    end

    %% Sensitivity
    if find(ismember(cellstr(myOptionsComp),"Sensitivity"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                mySensitiviy = num2cell(sensitivity.(myOptionsData{iData}));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = mySensitiviy;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = mySensitiviy;
                end
            end
        end
        count = count + 1;
    end

    %% Specificity
    if find(ismember(cellstr(myOptionsComp),"Specificity"))
        for iData = 1:size(myOptionsData,2)
            if ((k == idxMdl && strcmp(myOptionsData{iData},'test_total')) ||...
                (~strcmp(myOptionsData{iData},'test_total')))
                mySpecificity = num2cell(specificity.(myOptionsData{iData}));
                if strcmp(myOptionsData{iData},'test_total')
                    tab_test(count,:) = mySpecificity;
                else
                    myTab(k).tab(count,myStart(iData):myStart(iData)+numGroups-1) = mySpecificity;
                end
            end
        end
    %     count = count + 1;
    end
end

%% Mean & Std
if kFold == 1
    tab = myTab(1).tab;
else
    if any(ismember(cellstr(myOptionsData),'test_total'))
        myOptionsData(strcmp(myOptionsData, "test_total")) = [];
    end

    tab = table('Size',[size(myRowNames,2),size(myOptionsData,2)*numGroups],...
        'VariableTypes',repmat("string",1,size(myOptionsData,2)*numGroups));
    idxTest = find(ismember(myOptionsData,"test"));

    for r = 1:size(tab,1) % row
        for c = 1:size(tab,2) % column
            t = nan(kFold,1);
            for k = 1:kFold % field
                t(k) = myTab(k).tab{r,c};
            end
            myMean = mean(t,"omitnan");
            if strcmp(myRowNames(r),"AUC") % align w/ visualROC
                myMean = myAUC(c);
            elseif isfield(myClassesC_c,"test_total") && ...
                    c>numGroups*(idxTest-1) && c<=numGroups*idxTest
                myMean = table2array(tab_test(r,c-numGroups*(idxTest-1)));
            end
            myStd = std(t,"omitnan");
            if kFold ~= size(myClassesC_in,1)
                tab(r,c) = {append(num2str(round(myMean,roundDec)),'±',num2str(round(myStd,roundDec)))};
            else
                tab(r,c) = {num2str(round(myMean,roundDec))};
            end
        end
    end

end

%%  Label rows
varNames = strings(1,size(tab,2));
for iData = 1:size(myOptionsData,2)
    varNames(1,myStart(iData):myStart(iData)+numGroups-1) = strcat(cellstr(myGroups),"_",myOptionsData{iData});
end
tab.Properties.VariableNames = varNames;
tab.Properties.RowNames = myRowNames;

end  
