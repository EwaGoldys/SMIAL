function [balancedAccuracy] = balancedAccuracy(sensitivity,specificity)
% Function to calculate balanced accuracy
%
% INPUT: 
%   sensitivity: double 
%   specificity: double
%
% OUTPUT
%   balancedAccuracy: double
% 
% Authors: Shannon Handley
% Date: 14.11.2023

balancedAccuracy = (sensitivity+specificity)./2;

end
