function [precision] = compPrecision(TP,FP)
% Function to calculate precision
%
% INPUT: 
%   FP: double, number of false positives
%   TN: double, number of true negatives
%
% OUTPUT
%   precision: double
% 
% Authors: Shannon Handley
% Date: 14.11.2023 

precision = TP./(TP+FP);

end
