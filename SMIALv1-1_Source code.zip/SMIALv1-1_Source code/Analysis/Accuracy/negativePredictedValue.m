function [NPV] = negativePredictedValue(TN,FN)
% Function to calculate the negative predicted value
%
% INPUT: 
%   TN: double, number of true negatives
%   FN: double, number of negative negatives
%
% OUTPUT
%   NPV: double, negative predicted value
% 
% Authors: Shannon Handley
% Date: 14.11.2023

NPV = TN./(TN+FN);

end
