function [TPR] = compTPR(TP,FN) % equal sensitivity
%% Function to calculate true positive rate
%
% INPUT: 
%   TP: double, number of true positives
%   FN: double, number of false negatives
%
% OUTPUT
%   TPR: double, true positive rate
% 
% Authors: Shannon Handley
% Date: 14.11.2023

TPR = TP/(TP+FN);

end
