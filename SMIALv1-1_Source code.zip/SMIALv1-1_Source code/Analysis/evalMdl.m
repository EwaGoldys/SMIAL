function [idxMdl, myScore] = evalMdl(myClassesC,myGroups,ypred,yci,cvp,myMetric)
% selects average model out of multiple ones from cross-validation
%
% INPUT: 
%   myClassesC: categorical with correct class labels
%   myGroups: string array containing group names
%   ypred: predictions
%   yci: scores
%   cvp: cvpartition object for data splitting 
%   myMetric: cell with string specifying performance metric
%
% OUTPUT
%   idxMdl: index of selected median model
%   myScore: evaluation score
% 
% Authors: Aline Knab
% Date: 24.01.2024
%
% Last modified: 
%   10.05.2025 (Aline Knab): introduced user selection of performance
%       metric and performance score, altered computation mechanism

if nargin < 6
    if cvp.NumTestSets < size(myClassesC(1).total,1)
        myOptionsComp = {'AUC'};
    else
        myOptionsComp = {'Correctly Labelled [%]'};
    end
else
    myOptionsComp = myMetric;
end 

if ~iscell(myOptionsComp)
    myOptionsComp = cellstr(myOptionsComp);
end

myTest = nan(size(myOptionsComp,2),cvp.NumTestSets);

if ~isempty(yci(1).total)
    yci = rmfield(yci,{'total','training'});
end
ypred = rmfield(ypred,{'total','training'});

for k = 1:cvp.NumTestSets
        IdxPartition.test = cvp.test(k);
        table_c = compAccuracy(yci(k),ypred(k),myClassesC(k).total,IdxPartition,1,...
            myGroups,myOptionsComp,{'test'});
        myTest(:,k) = mean(table2array(table_c),2); % mean over all classes
   % end
end

myTest(ismember(myOptionsComp,'Correctly Labelled [%]'),:) = ...
    myTest(ismember(myOptionsComp,'Correctly Labelled [%]'),:)./100;

% Index of median model
medianTest = median(myTest,2);
[~, idxMdl] = min(sum(abs(myTest-medianTest),1));

% Overall performance
avg_performance = mean(myTest, 2);
std_performance = std(myTest, 0, 2);

myScore = mean(avg_performance - std_performance, 1);

end