function writeMyMdlInfo(myMdl,saveLoc,myTime,tTotal)
% writes myMdl information into txt-file 
%
% INPUT: 
%   MyMdl: struct containing MyMdl data
%   pathname: string pathname to save data
%   myTime: string containing time stamp
%   tTotal: time in seconds
% 
% Author: Aline Knab
% Date: 28.03.2024
%
% Last modified: 
%   14.05.2025 (Aline Knab): include hyperparameters and updated computation 
%       options such as running multiple algorithms at once
%   28.05.2025 (Aline Knab): added time logging
%   06.07.2025 (Aline Knab): added optimized hyperparameters

if nargin < 3
    myTime = string(datetime('now','Format','yyyy-MM-dd''_''HH-mm'));
end
myFile = fullfile(saveLoc,append("ModelInformation_",myTime,".txt")); 

myDivider = "------";

%% Heading
writelines(append("myMdl, ",myTime),myFile);

%% Information features (deleted, num available)
writelines(append("# Input features for classification: ", ...
    num2str(myMdl.MySettings.fTotal)),myFile,WriteMode="append");
writelines(append("(# Manually deleted features: ",...
    num2str(length(myMdl.MySettings.manualDelete)),")"),...
    myFile,WriteMode="append");
writelines(myDivider,myFile,WriteMode="append");

%% Validation method
if myMdl.MySettings.supervised
    if strcmp(myMdl.MySettings.validation,'holdout')
        valMethod = append("Hold-out validation (",...
            num2str(myMdl.MySettings.percTraining), "% Training, ",...
            num2str(100-myMdl.MySettings.percTraining), "% Test)");
    elseif strcmp(myMdl.MySettings.validation,'crossval')
        valMethod = append(num2str(myMdl.MySettings.kCross),"-fold cross-validation");
    else
        valMethod = "Leave-one-out validation";
    end
    writelines(append("Validation method: ",valMethod),myFile,WriteMode="append");
    writelines(myDivider,myFile,WriteMode="append");
end

%% Normalization method
normalizationMethod = myMdl.MySettings.normalizeType;
if strcmp(normalizationMethod,'zscore')
    normalizationMethod = 'Z-Score';
elseif strcmp(normalizationMethod, 'minmax')
    normalizationMethod = 'Min-Max normalisation';
elseif strcmp(normalizationMethod, 'robust')
    normalizationMethod = 'Robust scaling normalisation';
elseif strcmp(normalizationMethod, 'unitvector')
    normalizationMethod = 'Unit vector transformation normalisation';
elseif strcmp(normalizationMethod, 'logtrans')
    normalizationMethod = 'Log transformation normalisation';
elseif strcmp(normalizationMethod, 'none')
    normalizationMethod = 'None';
end

writelines(append("Normalisation method: ",normalizationMethod),myFile,WriteMode="append");
writelines(myDivider,myFile,WriteMode="append");

%% Up/Downsampling
if myMdl.MySettings.sampleSize ~= 0
    if myMdl.MySettings.sampleSize > 0
        mySampling = "Upsampling (" + myMdl.MySettings.sampling + ")";
    else
        mySampling = "Random undersampling";
    end
    writelines(append("Unbalanced Sample Size: ",mySampling),myFile,WriteMode="append");
    writelines(myDivider,myFile,WriteMode="append");
end

%% Feature selection
if myMdl.MySettings.supervised
    % Number features
    idxFeatures = myMdl.Mdl_classifier_final.idxFeatures;
    if iscell(idxFeatures), idxFeatures = cell2mat(idxFeatures); end
    writelines(append("Number of selected features: ",...
        num2str(length(idxFeatures))),myFile,WriteMode="append");
    
    % Selection method
    featureSelectionMethod = myMdl.MySettings.featureSelect;
    addInfo = [];
    if strcmp(featureSelectionMethod,'none')
        featureSelectionMethod = 'None';
    elseif strcmp(featureSelectionMethod,'fs')
        featureSelectionMethod = 'Forward selection';
        addInfo = append("(Performance metric: ", myMdl.MySettings.performanceTraining, ...
            "; Cross-validation: ",num2str(myMdl.MySettings.kTraining),"-fold)");
    elseif strcmp(featureSelectionMethod,'particle_swarm')
        featureSelectionMethod = 'Particle Swarm';
    elseif strcmp(featureSelectionMethod,'pearson_anova')
        featureSelectionMethod = 'Pearson Anova';
        addInfo = append("(threshold r: ",num2str(myMdl.MySettings.cutOff_r),")");
    elseif strcmp(featureSelectionMethod,'mrmr')
        featureSelectionMethod = "Minimum Redundancy Maximum Relevance (MRMR)";
    elseif strcmp(featureSelectionMethod,'manual')
        featureSelectionMethod = 'Manual';
    elseif strcmp(featureSelectionMethod,'groupedKmeans')
        featureSelectionMethod = 'Grouped kMeans';
    elseif strcmp(featureSelectionMethod, 'chi')
        featureSelectionMethod = 'Chi Squared';
    elseif strcmp(featureSelectionMethod, 'laplacian')
        featureSelectionMethod = 'Laplacian Score';
    elseif strcmp(featureSelectionMethod, 'relieff')
        featureSelectionMethod = 'ReliefF algorithm';
        addInfo = append("(Number of nearest neighbors: ", num2str(myMdl.MySettings.kRelieff),")");
    elseif strcmp(featureSelectionMethod,'significance')
        featureSelectionMethod = 'Statistical Significance';
        addInfo = append("(Significance method: ", num2str(myMdl.MySettings.signMethod),")");
    elseif strcmp(featureSelectionMethod,'bhattacharyya')
        featureSelectionMethod = 'Bhattacharyya';
    elseif strcmp(featureSelectionMethod,'entropy')
        featureSelectionMethod = 'Entropy';
      elseif strcmp(featureSelectionMethod,'ttest')
        featureSelectionMethod = 'Ttest';  
    elseif strcmp(featureSelectionMethod,'roc')
        featureSelectionMethod = 'Roc';
    elseif strcmp(featureSelectionMethod,'wilcoxon')
        featureSelectionMethod = 'Wilcoxon';
    elseif strcmp(featureSelectionMethod,'gini')
        featureSelectionMethod = 'Gini index';
    end
    
    writelines(append("Feature selection method: ",featureSelectionMethod),myFile,WriteMode="append");
    
    if ~isempty(addInfo)
        writelines(addInfo,myFile,WriteMode="append");
    end
    
    % Index (limited matrix) & feature name
    myIdxFeatures = myMdl.Mdl_classifier_final.idxFeaturesOrg;
    if size(myIdxFeatures,1)<size(myIdxFeatures,2)
        myIdxFeatures = myIdxFeatures.';
    end
    myFeaturesInfo = strcat("(",string(myIdxFeatures{1}),") ",string(myMdl.Mdl_classifier_final.varnamesCh_lim),"; ");
    writelines("Selected features: ",myFile,WriteMode="append");
    writelines(myFeaturesInfo,myFile,WriteMode="append");
    
    writelines(myDivider,myFile,WriteMode="append");
end

%% Feature transformation
writelines(append("Feature extraction: ",strjoin(myMdl.MySettings.transformations,', ')),myFile,WriteMode="append");
if any(contains(string(myMdl.MySettings.transformations),"pca"))
    writelines(append("→ Number of selected PCs: ",num2str(myMdl.Mdl_classifier.numPCs)),myFile,WriteMode="append");
    writelines(append("(PCA cut-off: ",num2str(myMdl.MySettings.cutOff_PCA),")"),myFile,WriteMode="append");
end
writelines(myDivider,myFile,WriteMode="append");

%% Classification
if myMdl.MySettings.supervised
    classMode = "Supervised";
else
    classMode = "Unsupervised";
end
writelines(append("Classification mode: ",classMode),myFile,WriteMode="append");

myClassifierS = myMdl.MySettings.myClassifier;
if strcmp(myClassifierS,'svm_lin'); myClassifierS = "Linear SVM"; 
elseif strcmp(myClassifierS,'svm_poly'); myClassifierS = "Polynomial SVM"; 
elseif strcmp(myClassifierS,'knn'); myClassifierS = "k Nearest Neighbors";
elseif strcmp(myClassifierS,'naivebayes'); myClassifierS = "Naive Bayes";
elseif strcmp(myClassifierS,'lda'); myClassifierS = "Linear Discriminant Analysis";
elseif strcmp(myClassifierS,'qda'); myClassifierS = "Quadratic Discriminant Analysis";  
elseif strcmp(myClassifierS,'logreg'); myClassifierS = "Logistic Regression";
elseif strcmp(myClassifierS,'tree'); myClassifierS = "Random Forest";   
end

hasAppendix = [];
if ~strcmp(myMdl.MySettings.myClassifier,myMdl.MySettings.myClassifier_org) 
    hasAppendix = {append("original classifier: ",myMdl.MySettings.myClassifier_org)};
end

if myMdl.MySettings.supervised && ~isempty(myMdl.MySettings.perfMetric_final)
    hasAppendix = [hasAppendix, {append("selected based on performance metric: ",...
        myMdl.MySettings.perfMetric_final)}];
end

if ~isempty(myMdl.MySettings.Finetune) && myMdl.MySettings.Finetune
    hasAppendix = [hasAppendix, {"hyperparameter tuning"}];
end

if ~isempty(hasAppendix)
    hasAppendix = string(append(" (",strjoin(string(hasAppendix),", "),")"));
end

writelines(append("Classifier: ",myClassifierS,hasAppendix),myFile,WriteMode="append");
if ~myMdl.MySettings.supervised
    writelines(append("# Clusters: ",num2str(myMdl.MySettings.numClusters)),myFile,WriteMode="append");
end
if ~isempty(myMdl.MySettings.Finetune) && myMdl.MySettings.Finetune
    saveHyperparameters(myMdl,myFile)
end
writelines(myDivider,myFile,WriteMode="append");

%% Time
if ~isempty(tTotal)
    writelines("Run time: ",myFile,WriteMode="append");
    writelines(append(string(duration(0, 0, tTotal, 'Format', 'hh:mm:ss')),' h:m:s'),myFile,WriteMode="append");
    writelines(myDivider,myFile,WriteMode="append");
end

end

