function [myMdl_c, myData_c, ypred_c, yci_c, mislabeled_c] = ...
    compClassification(evalMatrix_t,myClassesC,MySettings,IdxPartition, myMdl_c, myData_c, cvp_hyper)
% Computes classification (unsupervised? supervised?) and introduces
% up-/downsampling
%
% INPUT: 
%   evalMatrix: double matrix of training data (columns: features, rows: observations)
%   myClassesCin: categorial including class labels of evalMatrix
%   IdxPartition: struct with logicals for partitioning
%       (training/test/total)
%   myMdl_c: struct filled with classification model
%   myData_c: struct filled with data model
%   cvp_hyper: cvpartition object for data splitting for fine tuning
%       hyperparameters
%
% OUTPUT
%   myMdl_c: struct filled with classification model
%   myData_c: struct filled with data model
%   ypred_c: predictions
%   yci_c: predicted class post. probabilities
%   mislabeld_c: struct with logical (true when mislabeled)
% 
% Authors: Aline Knab, Shannon Handley
% Date: 25.03.2024
%
% Last modified: 
%   11.05.2025 (Aline Knab): converted to separate function, unsupervised 
%       counterchecked against true labels if provided
%   06.07.2025 (Aline Knab): changed mislabeled from index to logical

%% Potentially prepare hyperparameter cvp for up/downsampling
if MySettings.Finetune && MySettings.sampleSize ~= 0
    % Preallocate folds
    foldIdx_Hyper = zeros(size(myClassesC));  
    for i = 1:cvp_hyper.NumTestSets
        foldIdx_Hyper(test(cvp_hyper, i)) = i;
    end 
end

%% Assign variables 
switch lower(MySettings.myClassifier)
    case {'svm_lin', 'svm_poly', 'knn', 'naivebayes','lda', 'qda', 'logreg','tree'} % supervised
        
        evalMatrix_t_up = evalMatrix_t(IdxPartition.training,:);
        myClassesC_up = myClassesC(IdxPartition.training);

        if any(contains(["crossval","leave1out"],MySettings.validation)) %-> convert to IdxPartition (1 fold only)
            rng('default'); % Testing
            % cvp_up = cvp;
            labelCounts = countcats(myClassesC_up);

            %% Sample size -> upsampling/downsampling
            
            if MySettings.sampleSize ~= 0 &&...
                    length(unique(labelCounts))>1 && ...
                    ~strcmp(MySettings.validation,"leave1out")
                idxIn = (1:size(evalMatrix_t_up,1)).';
                idxUp = idxIn;
                
                % uspampling/downsampling
                if MySettings.sampleSize > 0 % upsample
                    dataset = array2table(evalMatrix_t_up); 
                    dataset = addvars(dataset, string(myClassesC_up),...
                        'NewVariableNames','label'); 
                    num2Add = max(labelCounts(:))-labelCounts;
                    numNeighbors = floor(max(min(sqrt(min(labelCounts(:))),10),2));

                    for iClass=1:size(MySettings.groups,1)
                        if num2Add(iClass) > 0
                            [newFeatures,newIdx] = upsample(dataset, MySettings.groups(iClass),...
                                num2Add(iClass),numNeighbors,MySettings.sampling);
                            idxUp = [idxUp;newIdx];
                            
                            newClasses = categorical(table2array(newFeatures(:,end)));
                            newFeatures = table2array(newFeatures(:,1:end-1));
                            if ~isnumeric(newFeatures)
                                newFeatures = double(newFeatures);
                            end

                            evalMatrix_t_up = [evalMatrix_t_up;newFeatures];
                            myClassesC_up = [myClassesC_up;newClasses];
                        end
                    end

                    if MySettings.Finetune
                        foldIdx_Hyper_new = [foldIdx_Hyper(idxUp)];
                        cvp_hyper = cvpartition("CustomPartition",foldIdx_Hyper_new);
                    end
                    % idxTest = nan([length(idxUp),1]);
                    % for k = 1:MySettings.kCross
                    %     idxTest(ismember(idxUp,idxIn(cvp.test(k)))) = k;
                    % end
                elseif MySettings.sampleSize < 0 % downsample

                    % idxTest = nan([size(evalMatrix_t.total,1),1]);
                    % idxDelete = [];
                    [idxKeep,idxRest] = downsample(myClassesC_up);
                    % for k = 1:MySettings.kCross
                    %     idxTest_c = idxIn(cvp.test(k));
                    %     myClassesC_c = myClassesC.total(cvp.test(k));
                    %     [idxKeep,idxRest] = downsample(myClassesC_c);
                    %     idxDelete = [idxDelete;idxTest_c(idxRest)];
                    %     % idxTest(idxTest_c(idxKeep)) = k;
                    % end
                    myClassesC_up(idxRest) = [];
                    % idxTest(idxDelete) = [];
                    evalMatrix_t_up(idxRest,:) = [];
                    if MySettings.Finetune
                        foldIdx_Hyper_new = foldIdx_Hyper(idxKeep);
                        cvp_hyper = cvpartition("CustomPartition",foldIdx_Hyper_new);
                    end
                end
                rng('default'); % Testing
            end

        else
            % cvp = [];
            % cvp_up = [];
        end

        [Mdl_classifier,HyperparameterOptimizationResults] = compClassificationModel(evalMatrix_t_up,...
            myClassesC_up,MySettings.myClassifier,MySettings.Finetune, cvp_hyper);
        
        if contains(MySettings.myClassifier,...
            {'svm_lin';'svm_poly';'knn';'naivebayes';'lda';'qda';'logreg';'tree'})
            [ypred_c.total,yci_c.total,mislabeled_c.total] = predictMdl(Mdl_classifier,evalMatrix_t,myClassesC);
        end

        myMdl_c = combineAsStruct(myMdl_c, 'Mdl_classifier', Mdl_classifier);
        if ~isempty(HyperparameterOptimizationResults)
            myMdl_c = combineAsStruct(myMdl_c, 'HyperparameterOptimizationResults', HyperparameterOptimizationResults);
        end

        myData_c = combineAsStruct(myData_c, 'evalMatrix_t_up', evalMatrix_t_up);%, ...
            %'cvp_up', cvp_up);

    case {'kmeans'}
        [ypred_c.total,C,numClusters] = compKMeans(evalMatrix_t, MySettings.numClusters);
        yci_c.total = [];
        MySettings.numClusters = numClusters;
        if MySettings.supervised
            if size(MySettings.groups,1) < size(unique(ypred_c.total))
                error("Number of available group labes less than number of " + ...
                    "class labels predictes. Please either correct class " + ...
                    "labels or untick 'Class labels provided' in Classification Settings.")
            end
            ypred_c.total = categorical(cellstr(MySettings.groups(ypred_c.total)));
            [ypred_c.total, ~, perm_idx] = align_clusters(ypred_c.total, myClassesC, MySettings.groups);
            C = C(perm_idx,:);
            mislabeled_c.total = find(~strcmp(string(cellstr(ypred_c.total)), string(cellstr(myClassesC))));
        else
            ypred_c.total = categorical(ypred_c.total);
        end
        myMdl_c = combineAsStruct(myMdl_c, 'C', C);
    case {'fuzzy'} % up to 11 clusters when automatically defined
        [ypred_c.total,C,numClusters] = ...
            compFuzzy(evalMatrix_t,MySettings.numClusters);
        yci_c.total = [];
        MySettings.numClusters = numClusters;
        if MySettings.supervised 
            ypred_c.total = categorical(cellstr(MySettings.groups(ypred_c.total)));
            [ypred_c.total, ~, perm_idx] = align_clusters(ypred_c.total, myClassesC, MySettings.groups);
            C = C(perm_idx,:);
            mislabeled_c.total = find(~strcmp(string(cellstr(ypred_c.total)), string(cellstr(myClassesC))));
        else
            ypred_c.total= categorical(ypred_c.total);
        end
        myMdl_c = combineAsStruct(myMdl_c, 'C', C);
end

%% assign training data
ypred_c.training = ypred_c.total(IdxPartition.training);
if ~exist("mislabeled_c","var")
    mislabeled_c.total = [];
end
if exist("yci_c","var") && ~isempty(yci_c.total)
    yci_c.training = yci_c.total(IdxPartition.training,:);
end

%% assign test data
if ~isempty(IdxPartition.test) 
    ypred_c.test = ypred_c.total(IdxPartition.test);
    if ~isempty(yci_c.total)
        yci_c.test = yci_c.total(IdxPartition.test,:);
    end
end

end