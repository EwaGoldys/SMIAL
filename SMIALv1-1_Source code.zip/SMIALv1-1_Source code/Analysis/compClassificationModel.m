function [Mdl_classifier, HyperparameterOptimizationResults] = ...
    compClassificationModel(evalMatrix,myClassesC,myClassifier,logical_hyper, cvp_hyper)
% applies multiclass classification 
% available options: 'svm_lin', 'svm_poly', 'knn', 'naivebayes', 'lda',
%   'qda', 'logreg', 'tree', 'ensemble'
%
% INPUT: 
%   evalMatrix: double matrix of training data (columns: features, rows: observations)
%   myClassesC: categorial including class labels of evalMatrix
%   myClassifier: string specifying classifier 
%       (options:'svm', 'knn', 'naivebayes','lda', 'logreg',tree')
%   logical_hyper: logical (finetuning hyperparameters yes/no)
%   cvp_hyper: cvpartition object for data splitting for fine tuning
%       hyperparameters
% 
% OUTPUT:
%   Mdl_classifier: Matlab classification model
%   HyperparameterOptimizationResults: selected hyperparameters
%   
% Authors: Aline Knab, Xiaohu Xu
% Date: 06.02.2024
%
% Last modified: 
%   07.03.2025 (Xiaohu Xu): introducing hyperparameters
%   06.05.2025 (Aline Knab): efficiency improvement and aligning with 
%       initial code, renamed function

if nargin < 6
    numEvaluations = 30;
end

if logical_hyper
    myHyperOptions = struct( 'MaxObjectiveEvaluations', numEvaluations, ...
        'CVPartition', cvp_hyper, ...
        'ShowPlots', false, ...  
        'Verbose', 0);
else
    HyperparameterOptimizationResults = [];
end

switch lower(myClassifier)
    case 'svm_lin'
        t = templateSVM("KernelFunction","linear");
        if logical_hyper
            [Mdl_classifier, HyperparameterOptimizationResults] = ...
                fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions, ...
                'FitPosterior',1);
            % Mdl_classifier = fitSVMPosterior(Mdl_classifier);
        else
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'FitPosterior',1);
        end
    case 'svm_poly'
        t = templateSVM("KernelFunction","polynomial");
        if logical_hyper
            [Mdl_classifier, HyperparameterOptimizationResults] = ...
            fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions,...
                'FitPosterior',1);
            % Mdl_classifier = fitSVMPosterior(Mdl_classifier);
        else
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'FitPosterior',1);
        end
    case 'knn'
        t = templateKNN();
        if logical_hyper
            [Mdl_classifier, HyperparameterOptimizationResults] = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions);
        else
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'FitPosterior',1);
        end
    case 'naivebayes' 
        if logical_hyper
            [Mdl_classifier] = fitcnb(evalMatrix,myClassesC, ...
                    'OptimizeHyperparameters','auto',...
                    'HyperparameterOptimizationOptions', myHyperOptions);
            HyperparameterOptimizationResults = Mdl_classifier.HyperparameterOptimizationResults;
        else
            Mdl_classifier = fitcnb(evalMatrix,myClassesC);
        end
        % Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners','naivebayes', ...
        %     'FitPosterior',1);
    case 'lda'
        if logical_hyper
            [Mdl_classifier] = fitcdiscr(evalMatrix,myClassesC, ...
                'DiscrimType','pseudolinear',...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions);
            HyperparameterOptimizationResults = Mdl_classifier.HyperparameterOptimizationResults;
        else
            Mdl_classifier = fitcdiscr(evalMatrix,myClassesC,'DiscrimType','pseudolinear');
        end
    case 'qda'
        if logical_hyper
            % t = templateDiscriminant("DiscrimType","pseudoquadratic");
            [Mdl_classifier] = fitcdiscr(evalMatrix,myClassesC, ...
                'DiscrimType','pseudoquadratic',...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions);
            HyperparameterOptimizationResults = Mdl_classifier.HyperparameterOptimizationResults;
        else
            % Mdl_classifier = fitcdiscr(evalMatrix,myClassesC,'DiscrimType','pseudoquadratic');
            t = templateDiscriminant("DiscrimType","pseudoquadratic");
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners',t);

        end
    case 'logreg'
        t = templateLinear('Learner','logistic');
        if logical_hyper
            [Mdl_classifier, HyperparameterOptimizationResults] = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions,...
                'FitPosterior',1);
        else
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners', t, ...
                'FitPosterior',1);
        end
    case 'tree-single' 
        t = templateTree();
        if logical_hyper
            [Mdl_classifier, HyperparameterOptimizationResults] = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions,...
                'FitPosterior',1');
        else
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
            'FitPosterior',1);
        end
    case 'tree_ensemble' % ensemble = random forest, auto only for binary classification
        t = templateEnsemble('Bag',100,templateTree(),'Type','classification');
        if logical_hyper
            [Mdl_classifier, HyperparameterOptimizationResults] = fitcecoc(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions,...
                'FitPosterior',1');
        else
            Mdl_classifier = fitcecoc(evalMatrix,myClassesC,'Learners',t,'FitPosterior',1');
        end
    case 'tree' % random forest via fitcensemble (cannot be used in parallel!!!)
        t = templateTree('Reproducible',true);
        if logical_hyper
            [Mdl_classifier] = fitcensemble(evalMatrix,myClassesC,'Learners',t, ...
                'OptimizeHyperparameters','auto',...
                'HyperparameterOptimizationOptions', myHyperOptions,...
                'Method','Bag');
            HyperparameterOptimizationResults = Mdl_classifier.HyperparameterOptimizationResults;
        else
            Mdl_classifier = fitcensemble(evalMatrix,myClassesC,'Learners',t,'Method','Bag');
        end
    otherwise
        error("Unknown classifier, please check")
end

end