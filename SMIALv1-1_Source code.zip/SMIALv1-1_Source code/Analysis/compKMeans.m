function [ypred,C,numClusters] = compKMeans(evalMatrix_training,numClusters)
% kmeans classification
%
% INPUT: 
%   evalMatrix_training: double matrix to evaluate 
%       (rows: observations, columns: features)
%   numClusters: integer of number of clusters (empty = automatic)
%
% OUTPUT:
%   ypred: double of predicted group 1-x
%   C: centroids
%   numClusters: integer of number of clusters
% 
% Authors: Aline Knab
% Date: 18.12.2023

if nargin < 2
    numClusters = [];
end

if isempty(numClusters) || numClusters<2
    mySilhouetteMean = nan(ceil(sqrt(size(evalMatrix_training,1))),1);
    for iSilhouette = 2:ceil(sqrt(size(evalMatrix_training,1)))
        [ypred,~] = kmeans(evalMatrix_training,iSilhouette);
        mySilhouette = silhouette(evalMatrix_training,ypred,'Euclidean');
        mySilhouetteMean(iSilhouette) = mean(mySilhouette);
    end
    [~, numClusters] = max(mySilhouetteMean);
end
[ypred,C] = kmeans(evalMatrix_training,numClusters);

end