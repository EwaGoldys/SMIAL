function [ypred_training,C,numClusters] = compFuzzy(evalMatrix_training,numClusters)
% fuzzy logic classification
%
% INPUT: 
%   evalMatrix_training: double matrix to evaluate 
%       (rows: observations, columns: features)
%   numClusters: integer of number of clusters (empty = automatic)
%
% OUTPUT:
%   ypred_training: double of predicted group 1-x
%   C: centroids
%   numClusters: integer of number of clusters
% 
% Authors: Aline Knab
% Date: 18.12.2023

if nargin < 2
    numClusters = [];
end

if isempty(numClusters)
    options = fcmOptions(Verbose=false);
    [C,U,~,info] = fcm(evalMatrix_training,options);
    numClusters = info.OptimalNumClusters;
else
    options = fcmOptions(NumClusters=numClusters,Verbose=false);
    [C,U,~,~] = fcm(evalMatrix_training,options); 
end
maxU = max(U);
ypred_training = nan(size(evalMatrix_training,1),1);
for iCluster=1:numClusters
    myIdx = U(iCluster,:) == maxU;
    ypred_training(myIdx) = iCluster;
end

end