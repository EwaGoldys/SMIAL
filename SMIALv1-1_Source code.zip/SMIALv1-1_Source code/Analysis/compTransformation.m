function [evalMatrix_t, myMdl_c, myData_c] = compTransformation(evalMatrix, myClassesC, IdxPartition, MySettings)
% computes data transformations such as pca/lda/sparse transformation
%
% INPUT: 
%   evalMatrix: double matrix of input data (columns: features, rows: observations)
%   myClassesC: categorial including class labels of evalMatrix
%   IdxPartition: struct with logicals for partitioning
%       (training/test/total)
%   MySettings: struct with settings for analysis
%
% OUTPUT
%   evalMatrix: transformed double matrix of input data (columns: features, 
%       rows: observations) 
%   myMdl_c: struct filled with classification model
%   myData_c: struct filled with data model
% 
% Authors: Aline Knab, Shannon Handley
% Date: 25.03.2024
%
% Last modified: 
%   23.04.2025 (Aline Knab): converted to separate function, removed
%       usage of structures

%% Transformations
myMdl_c = combineAsStruct('IdxPartition',IdxPartition);
myData_c = combineAsStruct('IdxPartition',IdxPartition,...
    'evalMatrix_ch',evalMatrix);

for iTrans = 1:size(MySettings.transformations,2)
    %% Normalize
    [evalMatrix_n.training, normVal] = compNormalize(evalMatrix(IdxPartition.training,:),...
        MySettings.normalizeType);
    if MySettings.supervised
        [evalMatrix_n.test, ~] = compNormalize(evalMatrix(IdxPartition.test,:),...
            MySettings.normalizeType, normVal);
    end
    myMdl_c = combineAsStruct(myMdl_c,'normVal', normVal);

    myTransform = MySettings.transformations{iTrans};
    switch lower(myTransform)
        
        case 'pca'
            [evalMatrix_t.training,coeffTraining, explained, numPCs] = ...
                compPCA(evalMatrix_n.training,MySettings);
            if ~isempty(evalMatrix_n.test)
                evalMatrix_t.test = applyPCA(evalMatrix_n.test,coeffTraining,numPCs);
            else
                evalMatrix_t.test = [];
            end
            evalMatrix_t.total = getTotalData(evalMatrix_t,IdxPartition);
            
            myMdl_c = combineAsStruct(myMdl_c,'coeffTraining', coeffTraining,...
                'explained',explained,'explained',explained,'numPCs',numPCs);
            myData_c = combineAsStruct(myData_c,'evalMatrix_PCA',evalMatrix_t.total);
            
        case 'lda'
            if ~ismember(cellstr(MySettings.transformations),'pca')
                evalMatrix_t = evalMatrix_n;
            end
            if isfield(evalMatrix_t,"total")
                evalMatrix_t = rmfield(evalMatrix_t,"total");
            end
            [evalMatrix_t.training,Mdl,W] = compLDA(evalMatrix_t.training,myClassesC(IdxPartition.training));
            if ~isempty(evalMatrix_t.test)
                evalMatrix_t.test = applyLDA(evalMatrix_t.test,W);
            end
            evalMatrix_t.total = getTotalData(evalMatrix_t,IdxPartition);
            
            myMdl_c = combineAsStruct(myMdl_c,'W',W);
            myData_c = combineAsStruct(myData_c,'evalMatrix_LDA',evalMatrix_t.total);

        case 'sparse'
            obj = sparsefilt(evalMatrix_n.training,MySettings.numChSelect,'IterationLimit',1000);
            evalMatrix_t.training = transform(obj,evalMatrix_n.training);
            if ~isempty(evalMatrix_n.test)
                evalMatrix_t.test = transform(obj,evalMatrix_n.test);
            else
                evalMatrix_t.test = [];
            end
            evalMatrix_t.total = getTotalData(evalMatrix_t,IdxPartition);

            myMdl_c = combineAsStruct(myMdl_c,'obj',obj);
            myData_c = combineAsStruct(myData_c,'evalMatrix_sparse', evalMatrix_t.total); 

        otherwise
            evalMatrix_t.training = evalMatrix_n.training;
            if isfield(evalMatrix_n,'test')
                evalMatrix_t.test = evalMatrix_n.test;
            else
                evalMatrix_t.test = []; % ALINE: might need to be removed? see if it throws errors.
            end
            evalMatrix_t.total = getTotalData(evalMatrix_t,IdxPartition);
    end
end 
evalMatrix_t = evalMatrix_t.total;

myData_c = combineAsStruct(myData_c,'evalMatrix_t', evalMatrix_t); 

end

