function [IOU_percentage] = visual_unsupervised(evalMatrix_t, predLabel, ...
    myGroups, saveLoc, myFolder, saveFormat, drawEllipse, myDim, axLabel, ...
    ax,IOU_2classidx,IOU_allclassidx, myTitle)
% 2D or 3D plots of unsupervised data
%
% INPUT: 
%   evalMatrix_t: rotated data
%   predLabel: (predicted) class label for each observation as integer numbers 
%   myGroups: string array with each row specifying group name;
%   saveLoc: string containing save data location
%   myFolder: string with desired folder name
%   saveFormat: format to save images (e.g., .png, .fig)
%   drawEllipse: boolean for enabling drawing of standard deviational
%       ellipse
%   myDim: string, specifying dimensionality ("dim2" (default), "dim3")
%   axLabel: string array with axis label in each row
%   ax: uiaxis object to draw on 
%   myTitle: (optional) string with e.g. method name for plot title
%       (default: equal to myFolder)
% 
% Authors: Aline Knab, Shannon Handley
% Date: 12.11.2023

%% Default variables
if nargin < 7
    drawEllipse = false;
end
if nargin < 8
    myDim = "dim2";
end
if nargin < 9
    axLabel = ["x";"y";"z"];
end
if nargin < 10
    figure(); ax = gca;
end
if nargin < 13 || isempty(myTitle)  %Sh changed fom 11 to 13
    myTitle = myFolder;
end

%% Dimensions
myDim = str2double(extractAfter(myDim,strlength(myDim)-1));
myView = [-45 45 45];
if size(evalMatrix_t,2) == 2 || myDim == 2
    myDim = 2; myView = [0,90];
end

%% set up save data directory
saveLoc = fullfile(saveLoc,'Classification');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

saveLoc = fullfile(saveLoc,myFolder);
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

load('myColors.mat','myColors');

%% Plot data
cla(ax); cla(ax,'reset'); hold(ax,"on"); 

myLegend = cell([1,size(unique(predLabel),1)*(1+drawEllipse)]); 
countLeg = 1;
pgon = [];

for iClass = 1:size(unique(predLabel),1)
    if drawEllipse
        myPredData = evalMatrix_t(predLabel==iClass,1:2);
        pgon_std = std_ellipse(myPredData, myColors(iClass,:),ax);
        pgon = [pgon pgon_std];
        myLegend{countLeg} = append("Std ellipse ",string(iClass)); 
        countLeg = countLeg+1;
    end
    
    if size(evalMatrix_t,2)>2 && myDim==3
        plot3(ax,evalMatrix_t(predLabel==iClass,1),evalMatrix_t(predLabel==iClass,2),evalMatrix_t(predLabel==iClass,3),'linestyle','none','Marker','o','Color','k','MarkerFaceColor',myColors(iClass,:));
    else
        plot(ax,evalMatrix_t(predLabel==iClass,1),evalMatrix_t(predLabel==iClass,2),'linestyle','none','Marker','o','Color','k','MarkerFaceColor',myColors(iClass,:));
    end
    
    if isempty(myGroups)
        myLegend{countLeg} = append("Group "+iClass);
    else
        myLegend{countLeg} = string(myGroups(iClass));
    end
    countLeg = countLeg+1;
end

%IOU from ellipses
if drawEllipse == true
    [IOU_percentage] = getIOU(pgon,IOU_2classidx,IOU_allclassidx);
else 
    IOU_percentage = [];
end

if size(axLabel,1) > 3
    xlabel(ax,axLabel(1));ylabel(ax,axLabel(2));zlabel(ax,axLabel(3));
else
    xlabel(ax,axLabel(1));ylabel(ax,axLabel(2));
end

legend(ax,myLegend,'Location','best','Interpreter','none');
title(ax, myTitle);

makePretty(ax);
view(ax,myView);
saveGuiFigure(ax,fullfile(saveLoc,append(myTitle,".",saveFormat))); 

end