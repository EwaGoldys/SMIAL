function [IOU_percentage] = visualData(myData,myMdl,myDim,saveLoc,saveFormat,...
    myOptionsComp,myOptionsData,myAx,myPanel,IOU_2classidx,IOU_allclassidx)
% assigning supervised or unsupervised data visualisation
%
% INPUT: 
%   myData: myData object
%   myMdl: myMdl object
%   myDim: string, specifying dimensionality ("dim2" (default), "dim3")
%   saveLoc: string containing save data location
%   saveFormat: format to save images (e.g., .png, .fig)
%   myOptionsComp: computation options (e.g., ellipse)
%   myOptionsData: data options (total, training, test, mislabelled)
%   predLabel: (predicted) class label for each observation as integer numbers 
%   ax: uiaxis object to draw on 
%   myPanel: uipanel object to draw on 
%   IOU_2classidx: array containing two vclass indexes for the IOU of the
%       std ellipse to be calculated 
%   IOU_allclassidx: array of all classes. 
%
% OUTPUT:
%   IOU_percentage: IOU measured of the std ellipse
%
% 
% Authors: Aline Knab, Shannon Handley
% Date: 12.11.2023
%
% Last modified: 
%   15.05.2025 (Aline Knab): added shapley (feature interpretability) &
%       tSNE, updated display of mislabelled datapoints


%% Clear plot area 
cla(myAx); cla(myAx,'reset'); hold(myAx,"on"); 
delete(myPanel.Children);

%% Settings
if isempty(find(ismember(cellstr(myOptionsComp),"ellipse"), 1))
    drawEllipse = false;
else
    drawEllipse = true;
end

if myData.MySettings.supervised && ~myData.MySettings.applyModel
    useLabel = grp2idx(myData.myClassesC);
    myGroups = myData.MySettings.groups;   
else
    useLabel = grp2idx(myData.ypred);
    myGroups = [];
    if ~isfield(myData,"myClassesC") 
        myData.myClassesC = myData.ypred; 
        msgbox("Class labels based on predicted labels.","Info");
    end
    if ~isfield(myData,"mislabeled"); myData.mislabeled.total = []; end
end   

if isstruct(myData.yci) 
    kFold = size(myData.yci,2);
else
    kFold = 1;
end
if kFold > 1
    idxMdl = myMdl.idxMdl;
    myCVP = myData.cvp;
    myData.IdxPartition.training = training(myCVP,idxMdl);
    myData.IdxPartition.test = test(myCVP,idxMdl);
    
else
    idxMdl = 1;
    myCVP = myData.IdxPartition;
end

% Assign classes
% if ismember('total',myOptionsData)
%     myClassesC.total = myData.myClassesC;
% end
% if ismember('training',myOptionsData)
%     myClassesC.training = myData.myClassesC(myMdl.Mdl_classifier.IdxPartition.training);
% end
% if ismember('test',myOptionsData)
%     myClassesC.test = myData.myClassesC(myMdl.Mdl_classifier.IdxPartition.test);
% end

% ROC
myOptionsData_lim = myOptionsData;
myOptionsData_lim(contains(myOptionsData_lim,'mislabeled'))=[];
if (any(find(ismember(cellstr(myOptionsComp),"roc"), 1)) || ...
        any(find(ismember(cellstr(myOptionsComp),"precision_recall"), 1)))...
        &&  ~isempty(myOptionsData_lim)
    if ~isempty(fieldnames(myData.yci))
        if kFold == 1; evalType = 'holdout';
        else; evalType = 'crossval'; end
        
        ci = [any(find(ismember(cellstr(myOptionsComp),"ci_r"), 1)),...
            any(find(ismember(cellstr(myOptionsComp),"ci_pr"), 1))];
        visualROC(myData.yci, myData.myClassesC, myCVP, myMdl.idxMdl, ...
            myMdl.MySettings.groups, evalType, ci, myOptionsComp, myOptionsData_lim, saveLoc, saveFormat, myAx);
    end
end

if strcmp(myOptionsComp{1},"pca") || ...
        strcmp(myOptionsComp{1},"finalTransform") && any(find(ismember(cellstr(myOptionsComp),"plot"), 1))
    for i = 1:size(myData.MySettings.transformations,2)
        myTransform = myData.MySettings.transformations{i};
        switch lower(myTransform)
            case{'pca'}
                if strcmp(myOptionsComp{1},"pca") || ...
                        size(myData.MySettings.transformations,2) == 1     
                    axLabel = getAxLabel("PC ",size(myData.evalMatrix_PCA,2));
                    if strcmp(myOptionsComp{1},"pca")
                        visualPCA(myData.evalMatrix_PCA, myMdl.coeffTraining, ...
                            myMdl.explained, myMdl.numPCs, myData.varnamesCh_lim, ...
                            saveLoc,saveFormat,myOptionsComp,myAx,myPanel);
                    end
                    if ~isempty(find(ismember(cellstr(myOptionsComp),"plot"), 1)) || ...
                            size(myData.MySettings.transformations,2) == 1
                        myPanel.Visible = false;
                        [IOU_percentage] = visual_unsupervised(myData.evalMatrix_PCA, ...
                            useLabel, myGroups, saveLoc,"PCA", saveFormat, ...
                            drawEllipse, myDim, axLabel, myAx,IOU_2classidx,IOU_allclassidx);
                    end
                end
            case{'lda'}
                if strcmp(myOptionsComp{1},"finalTransform")
                    axLabel = getAxLabel("Canonical variable ",size(myData.evalMatrix_LDA,2));
                    [IOU_percentage] = visual_supervised(myData.evalMatrix_LDA,myData.myClassesC,...
                        myData.IdxPartition,myData.mislabeled(idxMdl),saveLoc,"LDA",saveFormat,myOptionsData,...
                        myData.MySettings.groups,myDim,axLabel,drawEllipse,myAx,IOU_2classidx,IOU_allclassidx);
                end               
            case{'sparse'}
                if strcmp(myOptionsComp{1},"finalTransform")
                    axLabel = getAxLabel("Feature ",size(myData.evalMatrix_sparse,2), " (a.u.)"); %SH - removed myData.evalMatrix_sparse.total
                    if myData.MySettings.supervised 
                        [IOU_percentage] = visual_supervised(myData.evalMatrix_sparse,myData.myClassesC,...
                            myData.IdxPartition,myData.mislabeled(idxMdl),saveLoc,"Sparse",saveFormat,myOptionsData,...
                            myData.MySettings.groups,myDim,axLabel,drawEllipse,myAx,IOU_2classidx,IOU_allclassidx);
                    else
                        [IOU_percentage] = visual_unsupervised(myData.evalMatrix_sparse, ...
                                useLabel, myGroups, saveLoc,"Sparse Filtering", ...
                                saveFormat, drawEllipse,  myDim, axLabel,myAx,IOU_2classidx,IOU_allclassidx);
                    end   
                end
            case{'none'}
                if strcmp(myOptionsComp{1},"finalTransform")
                    axLabel = getAxLabel("Feature ",size(myData.evalMatrix_t,2), " (a.u.)");
                    if myData.MySettings.supervised  
                        [IOU_percentage] = visual_supervised(myData.evalMatrix_t,myData.myClassesC,...
                            myData.IdxPartition,myData.mislabeled(idxMdl),saveLoc,"Raw Features",saveFormat,myOptionsData,...
                            myData.MySettings.groups,myDim,axLabel,drawEllipse,myAx,IOU_2classidx,IOU_allclassidx);
                    else
                        [IOU_percentage] = visual_unsupervised(myData.evalMatrix_t, useLabel, ...
                            myGroups, saveLoc,"Raw Features", saveFormat, ...
                            drawEllipse, myDim, axLabel, myAx,IOU_2classidx,IOU_allclassidx);
                    end   
                end
        end
    %     visualData_supervised(evalMatrix_training_t,myClassesC_training,evalMatrix_test_t,myClassesC_test,saveLoc,myFolder,axLabel,mislabeled_training,mislabeled_test,myTitle)
    end
end

if ismember("tsne",cellstr(myOptionsComp))
    
    evalMatrix_t = tsne(myData.evalMatrix_t);
    axLabel = getAxLabel("tSNE ",size(myData.evalMatrix_t,2));
    
    if myData.MySettings.supervised  
        visual_supervised(evalMatrix_t,myData.myClassesC,myData.IdxPartition,...
            myData.mislabeled(idxMdl),saveLoc,"tSNE",saveFormat,myOptionsData,...
            myData.MySettings.groups,myDim,axLabel,drawEllipse,myAx,IOU_2classidx,IOU_allclassidx);
    else
        visual_unsupervised(evalMatrix_t, useLabel, myGroups, saveLoc,"tSNE", saveFormat, ...
            drawEllipse, myDim, axLabel,myAx,IOU_2classidx,IOU_allclassidx);
    end  
end

if any(ismember(cellstr(myOptionsComp),["shapley_swarmchart","shapley_explanation"]))
    visualShapley(myData.evalMatrix_t,myData.evalMatrix_ch,myData.myClassesC,myData.varnamesCh_lim,myData.IdxPartition, myMdl.Mdl_classifier,...
        myMdl.MySettings.groups, myOptionsComp, myOptionsData, saveLoc, saveFormat, myAx)
end

if ~exist("IOU_percentage","var")
    IOU_percentage = [];
end

end