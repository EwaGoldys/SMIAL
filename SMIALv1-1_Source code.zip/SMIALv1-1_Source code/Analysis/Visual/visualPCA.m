function visualPCA(score, coeff, explained, numPCs, varnames, saveLoc, saveFormat, myOptions, ax, myPanel)
% PCA graphs
% 
% INPUT: 
%   score: rotated data including PCAs explaining cutOff information (minimum 3)
%   coeff: rotation matrix including eigenvectors 
%   explained: information content per PC
%   numPCs: number of relevant PCs
%   varnames: cell array containing all channel names
%   saveLoc: string containing save data location
%   saveFormat: string specifying format of saved iamges, e.g. "png"
%   myOptions: computing options for PCA plots
%   ax: ax object for graph display
%   myPanel: panel object for graph display
%
% Authors: Aline Knab
% Date: 07.07.2023

if nargin < 9
    figure(); ax = gca;
end
if nargin < 10
    figure(); myPanel = gca;
end
    
%% set up save data directory
saveLoc = fullfile(saveLoc,'Classification');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

saveLoc = fullfile(saveLoc,'PCA');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

%% General
myView2D = [0,90];
if numPCs>=3 
    dim = 3; 
    myView = [-45 45 45];
else 
    dim = 2; 
    myView = myView2D;
end

%% Three-dimensional biplot of first three PCs
if find(ismember(cellstr(myOptions),"biplot"))
    myPanel.Visible = false;
    cla(ax); cla(ax,'reset'); 
    myLabel = string(varnames).';
    biplot(ax,coeff(1:numPCs,1:dim),'Scores',score(:,1:dim),'VarLabels',myLabel(1:numPCs).'); % limit to 2 in case only 2 available!
    view(ax,myView);
    title(ax,append(num2str(dim),"D biplot"));
    makePretty(ax);
    saveGuiFigure(ax,fullfile(saveLoc,append("PCA_",num2str(dim),"Dbiplot.",saveFormat))); 
    % exportgraphics(ax,fullfile(saveLoc,append("PCA_",num2str(dim),"Dbiplot.",saveFormat))); pause(myPause);
end

%% Feature contribution in general 
if ~isempty(find(ismember(cellstr(myOptions),"cont_abs"), 1)) || ~isempty(find(ismember(cellstr(myOptions),"cont_info"), 1))
    % pc = {}; pcT = {};
    myPanel.Visible = true; delete(myPanel.Children); 
    myPanel.AutoResizeChildren = 'off';
    pc = strings(1,numPCs); pcT = strings(1,numPCs);
    for i = 1:numPCs
        pc(i) = append("PC",num2str(i));
        pcT(i) = append("PC",num2str(i),", ",num2str(round(explained(i),1)), " %");        
        % pc = [pc; append("PC",num2str(i))];
        % pcT = [pcT; append("PC",num2str(i),", ",num2str(round(explained(i),1)), " %")];
    end
    varnames_c = strrep(varnames,"_"," ");
    featContr_n = abs(coeff)./sum(abs(coeff));   

    if find(ismember(cellstr(myOptions),"cont_abs"))
        h = heatmap(myPanel,pc,varnames_c,featContr_n(:,1:numPCs),'Colormap',jet); 
        h.Title = "Feature contribution, absolute";
        saveGuiFigure(myPanel,fullfile(saveLoc,append("FeatureContNormal.",saveFormat))); 
        % exportgraphics(ax,fullfile(saveLoc,append("FeatureContNormal.",saveFormat))); pause(myPause);
    end
    
%% Feature contribution in terms of information
    if find(ismember(cellstr(myOptions),"cont_info"))
        delete(myPanel.Children); 
        featContr_i = explained.'.*featContr_n;
        h=heatmap(myPanel,pcT,varnames_c,featContr_i(:,1:numPCs),'Colormap',jet);
        h.Title = "Feature contribution, information [%]";
        saveGuiFigure(myPanel,fullfile(saveLoc,append("FeatureContInfo.",saveFormat))); 
        % exportgraphics(myPanel,fullfile(saveLoc,append("FeatureContInfo.",saveFormat))); pause(myPause);
    end
    myPanel.AutoResizeChildren = 'on';

end

%% Scree plot of explained information
if ~isempty(find(ismember(cellstr(myOptions),"scree"), 1)) && explained(1) < 95
    cla(ax); cla(ax,'reset'); 
    myPanel.Visible = true; delete(myPanel.Children);
    myPanel.AutoResizeChildren = 'off';
    ax1 = subplot(1,1,1,'Parent',myPanel);
    [charts, ~] = pareto(ax1,explained);
    charts(1).FaceColor = 'b'; charts(2).Color = [0 0.50 0.10];
    xlabel(ax1,"Principal component"); ylabel(ax1,"Variance explained [%]");
    title(ax1,"Scree Plot")
    view(ax1,myView2D);
    makePretty(ax1);
    saveGuiFigure(myPanel,fullfile(saveLoc,append("PCA_explained.",saveFormat))); 
    % exportgraphics(ax,fullfile(saveLoc,append("PCA_explained.",saveFormat))); pause(myPause);
    myPanel.AutoResizeChildren = 'on';
end

end
