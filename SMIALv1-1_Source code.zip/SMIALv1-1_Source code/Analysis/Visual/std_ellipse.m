function A = std_ellipse(data, myColor, ax) 
% draws standard deviational ellipse of data
%
% INPUT:    
%   data: data matrix (rows: observations, columns: axis)
%   myColor: optional color for ellipse
% OUTPUT:
%   A: polyshape object
%
% Author: Vincent Spruyt, Shannon Handley
% Date: 25.03.2024
% 
% OTHER
%   https://nij.ojp.gov/sites/g/files/xyckuh171/files/media/document/CrimeStat%2520IV%2520Chapter%25204.pdf
%   https://link.springer.com/chapter/10.1007/978-3-030-75910-0_6

if nargin<2
    myColor = [rand rand rand];
end
if nargin<3
    ax = gca;
end

% Calculate the eigenvectors and eigenvalues
covariance = cov(data);
[eigenvec, eigenval ] = eig(covariance);

% Get the index of the largest eigenvector
[largest_eigenvec_ind_c, r] = find(eigenval == max(max(eigenval)));
largest_eigenvec = eigenvec(:, largest_eigenvec_ind_c);

% Calculate the angle between the x-axis and the largest eigenvector
angle = atan2(largest_eigenvec(2), largest_eigenvec(1));

% This angle is between -pi and pi.
% Let's shift it such that the angle is between 0 and 2pi
if(angle < 0)
    angle = angle + 2*pi;
end

% Get the coordinates of the data mean
avg = mean(data);

% Get the 95% confidence interval error ellipse
theta_grid = linspace(0,2*pi);
phi = angle;
X0=avg(1);
Y0=avg(2);

% Define a rotation matrix
R = [ cos(phi) sin(phi); -sin(phi) cos(phi) ];

% Compute standard deviation in x and y direction
data_t = data/R;
myStd_t = std(data_t);
a = myStd_t(1);
b = myStd_t(2);

% the ellipse in x and y coordinates 
ellipse_x_r  = a*cos( theta_grid );
ellipse_y_r  = b*sin( theta_grid );

%let's rotate the ellipse to some angle phi
r_ellipse = [ellipse_x_r;ellipse_y_r]' * R * sqrt(size(data,2));

% Draw the error ellipse
plot(ax,r_ellipse(:,1) + X0,r_ellipse(:,2) + Y0,'.-','Color',myColor)

% Area
x = r_ellipse(:,1) + X0;
y = r_ellipse(:,2) + Y0;

A = polyshape(x,y,'Simplify',false); 

end



