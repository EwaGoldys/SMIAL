function [IOU_percentage] = visual_supervised(evalMatrix_t,myClassesC,IdxPartition,mislabeled,saveLoc,...
    myFolder,saveFormat,myOptionsData,myGroups,myDim,axLabel,drawEllipse,ax,IOU_2classidx,IOU_allclassidx,myTitle)
% 2D or 3D plots of data with grouping and optional mislabelled
% 
% INPUT: 
%   evalMatrix_t: struct with rotated data 
%   myClassesC: struct with categorial class labels 
%   IdxPartition: structure including logicals for training/test/total
%   mislabeled: struct with logical (true for mislabeled observations)
%   saveLoc: string with save data location
%   myFolder: string with desired folder name
%   saveFormat: format to save images (e.g., .png, .fig)\
%   myOptionsData: data options (total, training, test, mislabelled)
%   myGroups: cell array containing group names 
%   myDim: string, specifying dimensionality ("dim2" (default), "dim3")
%   axLabel: string array with axis label in each row
%   drawEllipse: logical for drawing standard deviational ellipses (true)
%       or not (false)
%   IOU_2classidx: array containing two vclass indexes for the IOU of the
%       std ellipse to be calculated 
%   IOU_allclassidx: array of all classes. 
%   myTitle: (optional) string with e.g. method name for plot title
%       (default: equal to myFolder)
%
% OUTPUT:
%   IOU_percentage: Result of IoU (for two classes / all classes combined)
% 
% Authors: Aline Knab, Shannon Handley
% Date: 12.11.2023
% 
% Last modified
%   11.03.2025 (Aline Knab): converted structure variables to total 
%       variable only 
%   06.07.2025 (Aline Knab): changed mislabeled from index to logical &
%       corrected error in displaying

%% Default variables
if nargin < 8,   myOptionsData = {"training"; "test"; "total"; "mislabeled"}; end
if nargin < 9,   myGroups = categories(myClassesC); end
if nargin < 10,   myDim = "dim2"; end
if nargin < 11,  axLabel = ["x";"y";"z"]; end
if nargin < 12,  drawEllipse = false; end
if nargin < 13,  figure(); ax = gca; end
if nargin < 16 || isempty(myTitle) 
    myTitle = myFolder;
end  
% if nargin < 9 mislabeled.total = []; mislabeled.training = []; mislabeled.test = []; end

%% Dimensions
myDim = str2double(extractAfter(myDim,strlength(myDim)-1));
myView = [-45 45 45];
if size(evalMatrix_t,2) == 2 || myDim == 2
    myDim = 2; myView = [0,90];
end

%% Sort input
myClassesN = grp2idx(myClassesC);
% if ~isempty(fieldnames(mislabeled)) && ~isempty(mislabeled(1).total)
%     myClassesN.training = grp2idx(myClassesC.training);
%     myClassesN.test = grp2idx(myClassesC.test);
% end
IdxPartition.total = true(size(evalMatrix_t,1),1);

%% set up save data directory
saveLoc = fullfile(saveLoc,'Classification');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

saveLoc = fullfile(saveLoc,myFolder); 
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

load('myColors.mat','myColors');

%% Visualize Data
cla(ax); cla(ax,'reset'); hold(ax,"on"); 
myMarker.mislabeled = 'o';
myMarker.training = 'x';
myMarker.test = '.';
myMarker.total = 'o';

markerSize = 6;
myLegend = {};

% highlight mislabeled data points
countLeg = 1;
idxMislabeled = find(ismember(cellstr(myOptionsData),"mislabeled"), 1);
if ~isempty(idxMislabeled) 
    if~isempty(mislabeled.total) %&& ~ismember(0,mislabeled.total)
        myOptionsData_c = myOptionsData;
        myOptionsData_c(strcmp(myOptionsData_c,'mislabeled')) = [];
        dispData = cell(size(myOptionsData_c,2),1);
        for iData = 1:size(myOptionsData_c,2) 
            dispData{iData} = evalMatrix_t(mislabeled.total & IdxPartition.(myOptionsData{iData}),:);
            % dispData{iData} = evalMatrix_t(mislabeled.(myOptionsData_c{iData}),:);
        end
        dispData =cell2mat(dispData);

        addSize = 2;
        if size(dispData,2)>2 && myDim==3
            plot3(ax,dispData(:,1), dispData(:,2), dispData(:,3), ...
                'linestyle','none','Marker','o','Color','k',...
                'MarkerSize',markerSize+addSize,'LineWidth',2);      
        else
            plot(ax,dispData(:,1), dispData(:,2),...
                'linestyle','none','Marker','o','Color','k','MarkerSize',markerSize+addSize,'LineWidth',2); 
        end
        myLegend = {"Mislabeled"}; 
        
        countLeg = countLeg+1;
    end
    myOptionsData(idxMislabeled) = [];
end

myLegend = [myLegend, cell([1,size(myGroups,1)*(size(myOptionsData,1)+double(drawEllipse))])]; 

% figure();ax = gca; hold on % for easier testing

% plot classification result
drawEllipse_c = false;
pgon = [];
for iClass = 1:size(myGroups,1)  
    for iData = 1:size(myOptionsData,2) 
        if iData == size(myOptionsData,2)
            drawEllipse_c = drawEllipse;
        end

        evalMatrix_t_c = evalMatrix_t(IdxPartition.(myOptionsData{iData}),:);
        if size(evalMatrix_t,2)>2 && myDim==3
            p = plot3(ax,evalMatrix_t_c(myClassesN(IdxPartition.(myOptionsData{iData}))==iClass,1), ...
                evalMatrix_t_c(myClassesN(IdxPartition.(myOptionsData{iData}))==iClass,2), ...
                evalMatrix_t_c(myClassesN(IdxPartition.(myOptionsData{iData}))==iClass,3),...
                'linestyle','none','Marker',myMarker.(myOptionsData{iData}),'Color',myColors(iClass,:));
        else
            p = plot(ax,evalMatrix_t_c(myClassesN(IdxPartition.(myOptionsData{iData}))==iClass,1), ...
                evalMatrix_t_c(myClassesN(IdxPartition.(myOptionsData{iData}))==iClass,2),...
                'linestyle','none','Marker',myMarker.(myOptionsData{iData}),'Color',myColors(iClass,:));
        end
        if strcmp(myOptionsData{iData},"total")
            p.MarkerEdgeColor = [0 0 0];
            p.MarkerFaceColor = myColors(iClass,:);
        end
        myLegend{countLeg} = append(string(myGroups(iClass)),", ",myOptionsData{iData}); 
        countLeg = countLeg+1;
        if drawEllipse_c
            myColors_c = max(myColors(iClass,:)-.4,0); 
            myClassData = evalMatrix_t(myClassesN==iClass,1:2);
            pgon_std = std_ellipse(myClassData,myColors_c,ax);
            pgon = [pgon pgon_std];
            myLegend{countLeg} = append("Std ellipse ",string(myGroups(iClass)),", ",myOptionsData{iData}); 
            countLeg = countLeg+1;
            drawEllipse_c = false;
        end
    end
end


%IOU from ellipses
if drawEllipse == true
    [IOU_percentage] = getIOU(pgon,IOU_2classidx,IOU_allclassidx);
else 
    IOU_percentage = [];
end

if size(evalMatrix_t,2)>2
    xlabel(ax,axLabel(1));ylabel(ax,axLabel(2));zlabel(ax,axLabel(3));
else
    xlabel(ax,axLabel(1));ylabel(ax,axLabel(2));
end
legend(ax,myLegend,'Location','best','Interpreter','none');
title(ax,myTitle);

makePretty(ax);
view(ax,myView);

myTitle = myTitle+"_"+strjoin(cellstr(myOptionsData),"_");
saveGuiFigure(ax,fullfile(saveLoc,append(myTitle,".",saveFormat))); 

end