function visualShapley(evalMatrix_t, evalMatrix_ch, myClasses, varnames, ...
    IdxPartition, myMdl, myGroups, myOptions, myOptionsData, saveLoc, saveFormat, myAx)
% visualising top 30 SHAP values of features; linearly transformed features 
% are approximated 
%
% INPUT: 
%   evalMatrix: double matrix of  data; potentially post transformation
%       (PCA, LDA; columns: features, rows: observations)
%   evalMatrix_ch: double matrix of  original data 
%       (columns: features, rows: observations)
%   myClasses: categorical array with class names
%   varnames: feature names (1xn cell array, n equals width of evalMatrix)
%   IdxPartition: struct with logical arrays for training/test/total
%   myMdl: myMdl object
%   myGroups: cell array containing class labels
%   myOptionsComp: cell array with computation options ("shapley_swarmchart","shapley_explanation")
%   myOptionsData: data options (total, training, test, mislabelled)
%   saveLoc: string containing save data location
%   saveFormat: format to save images (e.g., .png, .fig)
%   myAx: uiaxis object to draw on 
% 
% Authors: Akanksha Bhargava, Aline Knab
% Date: 15.05.2025
%
% Last modified: 
%   24.05.2025 (Aline Knab): Considering transformations (PCA, LDA) ->
%       required 'manually' programming swarmcharts & barcharts; with 
%       barcharts all classes start at zero now
%   27.05.2025 (Aline Knab): Limiting displayed SHAP values to 30
%   25.07.2025 (Shannon Handley): Including values from both classes in
%       SHAP plots

%% set up save data directory
saveLoc = fullfile(saveLoc,'Classification');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

saveLoc = fullfile(saveLoc,'Feature Contribution2');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

if ~isfield(myMdl,"Mdl_classifier")
    myMdl_c = myMdl;
    clear myMdl;
    myMdl.Mdl_classifier = myMdl_c;
    clear myMdl_c;
end

load('myColors.mat','myColors');

myClassesN = grp2idx(myClasses);
for iData = 1:size(myOptionsData,2) 
    % General SHAP computations
    if strcmp(myOptionsData{iData},'total')
        IdxPartition.total = true(size(evalMatrix_t,1),1);
    end
    explainer = shapley(myMdl.Mdl_classifier,evalMatrix_t,QueryPoints=evalMatrix_t(IdxPartition.(myOptionsData{iData}),:),UseParallel=true);
    shap_values = explainer.ShapleyValues;

    numClasses = size(myGroups,1);
    numFeatures = height(shap_values);
    numQueryPoints = size(shap_values.(string(myGroups(1))), 2);

    % Convert to matrix
    shap_array = zeros(numFeatures, numClasses, numQueryPoints);
    for iClass = 1:numClasses
        thisShap = shap_values.(string(myGroups(iClass)));  % 3×N matrix
        shap_array(:, iClass, :) = reshape(thisShap, [numFeatures, 1, numQueryPoints]);
    end
       
    % Project if necessary
    if isfield(myMdl,"coeffTraining") || isfield(myMdl,"W")
        if isfield(myMdl,"coeffTraining") && ~ isfield(myMdl,"W")
            fullTransform = myMdl.coeffTraining;
        elseif isfield(myMdl,"coeffTraining") && isfield(myMdl,"W") 
            fullTransform = myMdl.coeffTraining(:,1:numFeatures) * myMdl.W;
        elseif ~isfield(myMdl,"coeffTraining") && ~ isfield(myMdl,"W")
            fullTransform = myMdl.W;
        end
        shap_orig = zeros(size(myMdl.coeffTraining,1), numClasses, numQueryPoints);
        for iQ = 1:numQueryPoints
            shap_orig(:,:,iQ) = fullTransform  * shap_array(:,:,iQ);  % [origFeat x classes]
        end
    else
        shap_orig = shap_array;
    end

    % Compute mean absolute SHAP per feature per class
    nFeatures = size(shap_orig, 1);
    mean_shap_all = zeros(nFeatures, numClasses);
    for iClass = 1:numClasses
        class_vals = abs(squeeze(shap_orig(:, iClass, :)));  
        mean_shap_all(:, iClass) = mean(class_vals, 2);      
    end
    
    % Sort features by total importance across classes and take top 30
    % (or all, if less than 30)
    [~, sortIdx] = sort(mean(mean_shap_all, 2), 'descend');
    topN = min(30, numel(sortIdx)); % ALINE, change back to 30!!!
    topFeaturesIdx = sortIdx(1:topN);
    mean_shap_all = mean_shap_all(topFeaturesIdx, :);
    varnames_sorted = varnames(topFeaturesIdx);   

    % Swarmchart
    if any(strcmp(myOptions, "shapley_swarmchart"))  
        cla(myAx); cla(myAx,'reset'); hold(myAx,"on"); 
        evalMatrix_ch_c = evalMatrix_ch(IdxPartition.(myOptionsData{iData}),:);
        myClassesN_c = myClassesN(IdxPartition.(myOptionsData{iData}));
        for iClass = 1:numClasses
            cla(myAx); cla(myAx,'reset'); hold(myAx,"on"); 
        
            % Class samples
            % idxClass = find(myClassesN_c == iClass); 
            % nSamples = numel(idxClass);

            % Shap values for class
            % shap_vals = shap_orig(topFeaturesIdx, iClass, idxClass);
            shap_vals = shap_orig(topFeaturesIdx, iClass, :);

            % Vectorize for swarmchart
            shap_vec = reshape(shap_vals, [], 1);
            featval_vec = reshape(evalMatrix_ch_c(:,topFeaturesIdx), [], 1);
            % y_pos = repmat(1:topN, 1, nSamples);
            y_pos = repmat(1:topN, 1, numel(myClassesN_c));

            % Colormap
            cmap = parula(256);  
            nColors = size(cmap,1);
            cIdx = round(rescale(normc(featval_vec), 1, nColors));
            cIdx = min(max(cIdx,1),nColors);  % clamp to [1, 256]
            
            % Swarmchart
            swarmchart(myAx, shap_vec, y_pos, 20, cmap(cIdx,:), 'filled');
            yticks(myAx, 1:numel(varnames));
            yticklabels(myAx,varnames);
            myAx.TickLabelInterpreter = 'none';
            ylabel(myAx, "Predictor");
            title(myAx,"SHAP Swarm - "+myOptionsData{iData},'Interpreter','none');
            subtitle(myAx,string(myGroups(iClass)));
            xlabel(myAx,"SHAP Value");
            xline(myAx,0);

            % Colorbar
            cb = colorbar(myAx);
            cb.Label.String = "Predictor Value";
            cb.Ticks = [cb.Limits(1), cb.Limits(2)];
            cb.TickLabels = {'Low', 'High'};

            % Draw & save
            drawnow;
            makePretty(myAx);
            myTitle = "SHAP_swarmchart_"+string(myGroups(iClass))+"_"+...
                myOptionsData{iData};
            saveGuiFigure(myAx,fullfile(saveLoc,append(myTitle,".",saveFormat))); 
        end
    end
   
    % Explanation
    if any(strcmp(myOptions, "shapley_explanation"))  
        cla(myAx); cla(myAx,'reset'); hold(myAx,"on"); 

        % Plot grouped bar chart
        b = barh(myAx, mean_shap_all, 'grouped');
        for iClass = 1:numClasses
            b(iClass).FaceColor = myColors(iClass,:);
        end
        
        % All the labeling
        yticks(myAx, 1:nFeatures);
        yticklabels(myAx, varnames_sorted);
        xlabel(myAx, 'Mean(|SHAP Value|)');
        myAx.TickLabelInterpreter = 'none';
        legend(myAx, myGroups, 'Interpreter', 'none', 'Location', 'northeastoutside');
        title(myAx, append('SHAP Feature Importance Across Classes - ', myOptionsData{iData}),'Interpreter','none');
        grid(myAx,'on');

        drawnow;
        makePretty(myAx);
        saveGuiFigure(myAx,fullfile(saveLoc,append(myTitle,".",saveFormat))); 
    end

end

end
