function visualROC(yci, myClassesC, cvp, idxMdl, myGroups, evalType, ci, ...
    myOptionsComp,myOptionsData, saveLoc, saveFormat, ax)
% ROC graphs and precision-recall-curve (optional confidence interval)
% 
% INPUT: 
%   yci: struct with confidence intervals for responses (training, test,
%       total)
%   myClassesC: categorical with correct class names
%   cvp: partition object
%   idxMdl: index of selected model
%   evalType: evaluation type ('holdout'=bootstrapping, 'crossval')
%   ci: boolean array to show confidence interval (1: roc, 2: precision-recall)
%   myOptionsComp: computation options (roc, precision_recall)
%   myOptionsData: data options (training, test, total)
%   saveLoc: string with save data location
%   saveFormat: format to save images (e.g., .png, .fig)
%   ax: uiaxis object to draw on 
%
% Author: Aline Knab
% Date: 02.03.2024

%% set up save data directory
saveLoc = fullfile(saveLoc,'Classification');
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

if nargin < 10
    saveFormat = "png";
end

if nargin < 11
    figure(); 
    ax = gca;
end

load('myColors.mat','myColors');

numGroups = size(myGroups,1);
if numGroups == 2
    numGroups = 1;
end

%% ROC,AUC
rocObj = struct;
myAUC = struct;
roundDec = 4;

if any(contains(myOptionsComp,{'diag'}))
    plotDiag = true;
else
    plotDiag = false;
end
    
for iData = 1:size(myOptionsData,2)
    cla(ax); cla(ax,'reset'); hold(ax,'on');
    myLegend = cell(1,numGroups+any(contains(myOptionsComp,{'average_macro','average_micro'})));
    % myLegend = cell(1,size(myGroups,1)*2);

    [myAUC.(myOptionsData{iData}), rocObj.(myOptionsData{iData})] = ...
        compROC(yci,myClassesC,cvp,myGroups,idxMdl,myOptionsData{iData},evalType);
    
    % ROC curves
    if any(contains(myOptionsComp,{'roc'}))
        % Add AUC to table
        for iClass = 1:numGroups
            idx_c = find(strcmp(string(rocObj.(myOptionsData{iData}).ClassNames),...
                string(myGroups(iClass))));
            aucPR = myAUC.(myOptionsData{iData})(1,idx_c);
    
            % if includes confidence interval
            if ci(1) && size(myAUC.(myOptionsData{iData}),1)>1
                aucPR = num2str(round(aucPR,roundDec));
                myInterval = round(mean([...
                    abs(myAUC.(myOptionsData{iData})(1,idx_c)-myAUC.(myOptionsData{iData})(2,idx_c)), ...
                    abs(myAUC.(myOptionsData{iData})(1,idx_c)-myAUC.(myOptionsData{iData})(3,idx_c))]), ...
                    roundDec);
                aucPR = string(append(num2str(aucPR),'±',num2str(myInterval)));
            end
    
            % Visualize ROC
            plot(ax,rocObj.(myOptionsData{iData}),'Color',myColors(iClass,:),...
                ShowConfidenceIntervals=ci(1),...
                ClassNames=myGroups(iClass),ShowModelOperatingPoint=false,...
                ShowDiagonalLine = plotDiag);
            if numGroups <= 2
                myLegend(iClass) = {"AUC = "+aucPR};
                % myLegend(2*iClass-1) = {"AUC = "+aucString};
                % myLegend(2*iClass) = {"Model Operating Point"};
            else
                myLegend(iClass) = {string(myGroups(iClass)) + " (AUC = "+aucPR + ")"};
                % myLegend(2*iClass-1) = {string(myGroups(iClass)) + "(AUC = "+aucString + ")"};
                % myLegend(2*iClass) = {string(myGroups(iClass)) + " Model Operating Point"};
            end
        end
        if any(contains(myOptionsComp,{'average_macro','average_micro'}))
            avgMethod = split(myOptionsComp(contains(myOptionsComp,{'average_macro','average_micro'})),"_");
            avgMethod = avgMethod{2};
            [FPR,TPR,~,auc_avg] = average(rocObj.(myOptionsData{iData}),avgMethod);
            plot(ax,[0;FPR],[0;TPR],'Color',[0 0 0]);
            avgMethod(1) = upper(avgMethod(1));
            myLegend(end) = {avgMethod+"-average (AUC = " + auc_avg + ")"};
        end

        xlabel(ax,'False positive rate'); 
        ylabel(ax,'True positive rate'); 
        title(ax,"ROC "+ myOptionsData{iData}); 
        legend(ax,myLegend,'Location','southeast','Interpreter','none');
        makePretty(ax);
        fileName = fullfile(saveLoc,"ROC_" +myOptionsData{iData} + "."+ saveFormat);
        saveGuiFigure(ax,fileName); pause(.1);
    end       
end

%% Precision-Recall-Curve
if any(contains(myOptionsComp,{'precision_recall'}))

    for iData = 1:size(myOptionsData,2)
        cla(ax); cla(ax,'reset'); hold(ax,'on');
        myLegend = cell(1,numGroups);
    
        rocObj.(myOptionsData{iData}) = addMetrics(rocObj.(myOptionsData{iData}),...
            "PositivePredictiveValue");
        myClassesROC = rocObj.(myOptionsData{iData}).Metrics.ClassName;

        % Get recall and precision
        recall = rocObj.(myOptionsData{iData}).Metrics.TruePositiveRate(:,1);
        precision = rocObj.(myOptionsData{iData}).Metrics.PositivePredictiveValue(:,1);

        % Compute +/-
        aucPR = compAUCPR(myClassesROC,precision,recall);
        if ci(2) && numel(aucPR)>1
            % Lower CI AUC
            recall_lower = rocObj.(myOptionsData{iData}).Metrics.TruePositiveRate(:,2);
            precision_lower = rocObj.(myOptionsData{iData}).Metrics.PositivePredictiveValue(:,2);
            aucPR_lower = compAUCPR(myClassesROC,precision_lower,recall_lower);
            
            % Upper CI AUC
            recall_upper = rocObj.(myOptionsData{iData}).Metrics.TruePositiveRate(:,2);
            precision_upper = rocObj.(myOptionsData{iData}).Metrics.PositivePredictiveValue(:,2);
            aucPR_upper = compAUCPR(myClassesROC,precision_upper,recall_upper);

            myInterval = round(mean([abs(aucPR-aucPR_lower),abs(aucPR-aucPR_upper)],2),roundDec);

            aucPR = string(round(aucPR,roundDec));
            aucPR = append(aucPR,'±',string(myInterval));
        end

        % Visualize ROC
        for iClass = 1:numGroups
            curveObj = plot(ax,rocObj.(myOptionsData{iData}),'Color',myColors(iClass,:),...
                ShowConfidenceIntervals=ci(2), YAxisMetric="PositivePredictiveValue",...
                XAxisMetric="TruePositiveRate", ClassNames=myGroups(iClass),...
                ShowModelOperatingPoint=false);

            if numGroups <= 2
                myLegend(iClass) = {"AUC = "+aucPR(iClass)};
            else
                myLegend(iClass) = {string(myGroups(iClass)) + " (AUC = "+aucPR(iClass) + ")"};
            end
        end
        xlabel(ax,'Recall'); 
        ylabel(ax,'Precision'); 
        title(ax,"Precision-Recall-Curve "+ myOptionsData{iData}); 
        legend(ax,myLegend,'Location','southeast'); 
        makePretty(ax);
        fileName = fullfile(saveLoc,"Precision-Recall-Curve_" +myOptionsData{iData} + "."+ saveFormat);
        saveGuiFigure(ax,fileName); pause(.1);
    end
end

end


function aucPR = compAUCPR(myClassesROC,precision,recall)
% Computes AUC below precision recall curve
% 
% INPUT: 
%   myClassesROC: categorical array with class labels as listed as in ROC
%       object
%   precision: Results  precision (column 1: general precision, 2 & 3 lower
%       and upper CI, respectively
%   recall: Results recall (column 1: general precision, 2 & 3 lower
%       and upper CI, respectively
%
% OUTPUT:
%   aucPR: Area below precision-recall-curve
%   
% Date: 19.07.2025

% Preallocate range indices
groups = unique(myClassesROC,'stable');
numGroups = numel(groups);
classRanges = zeros(numGroups, 2);
aucPR = zeros(numGroups,1);

for iClass = 1:numGroups
    idxRows = find(ismember(string(myClassesROC), string(groups(iClass))));
    classRanges(iClass, :) = [min(idxRows), max(idxRows)];
end

% Compute AUC
for iClass = 1:numGroups
    idx_c = classRanges(iClass, 1):classRanges(iClass, 2);
    precision_c = precision(idx_c);
    recall_c = recall(idx_c);

    if isnan(precision_c(1)) || isnan(recall_c(1))
        precision_c(1) = [];
        recall_c(1) = [];
    end
    
    if numel(precision_c) > 1
        aucPR(iClass) = trapz(recall_c, precision_c);
    else 
        aucPR(iClass) = 0;
    end

    aucPR(iClass) = aucPR(iClass) + (recall_c(1)*precision_c(1));
end

end