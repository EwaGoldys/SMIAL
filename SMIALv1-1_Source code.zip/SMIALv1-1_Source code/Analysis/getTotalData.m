function data_total = getTotalData(data,idx)
% combine input data (training & test) to total data in correct order
%
% INPUT:
%   data: input data
%   idx: structure including logicals for training and test 
%
% OUTPUT:
%   data_total: total data in correct order
%
% Author: Aline Knab
% Date: 11.09.2024

if isfield(data,"total")
    data_total = data.total;
else
    data = [data.training;data.test];
    idx_test = [idx.training;idx.test]; % TODO: delete/comment out before release
    if any(idx_test>1 | idx_test < 0)
        error("Aline, check out where getTotalData called, sth not converted to logical");
    end
    idx = [find(idx.training);find(idx.test)];
    % data_total = nan(size(data));
    data_total(idx,:) = data;
end

end