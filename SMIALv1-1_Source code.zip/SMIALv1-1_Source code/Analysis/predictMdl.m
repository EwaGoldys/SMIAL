function [ypred,yci,mislabeled] = ...
    predictMdl(Mdl_classifier,evalMatrix,myClassesC)
% Classification prediction and errors
% 
% INPUT: 
%   Mdl_classifier: Trained discriminant analysis classification model
%   evalMatrix: double matrix of training data (columns: features, rows: observations)
%   myClassesC: categorial including class labels of evalMatrix
% 
% OUTPUT:
%   ypred: struct with categorial array of predicted class label 
%   yci: predicted class post. probabilities
%   mislabeled: indices of mislabelled data
% 
% Authors: Aline Knab
% Date: 12.01.2024
%
% Last modified: 
%   11.05.2025 (Aline Knab): updated to not be based on structures
%   06.07.2025 (Aline Knab): changed mislabeled from index to logical

if isa(Mdl_classifier,'ClassificationECOC') || ...
    isa(Mdl_classifier,'classreg.learning.classif.CompactClassificationECOC')
    [ypred,~,~,yci] = predict(Mdl_classifier,evalMatrix);
else
    [ypred,yci] = predict(Mdl_classifier,evalMatrix);
end
if ~isempty(myClassesC)
    mislabeled = categorical(ypred)~=myClassesC;
else
    mislabeled = [];
end


end