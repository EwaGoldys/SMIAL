function [evalMatrix_training_t,Mdl,W] = compLDA(evalMatrix_training,myClassesC_training)
% applies LDA transformation to training and testing dataset 
%
% INPUT: 
%   evalMatrix_training: double matrix of training data (columns: features, rows: observations)
%   evalMatrix_test: double matrix of test data (columns: features, rows: observations)
%   myClassesC_training: categorial including class labels of evalMatrix_training
%
% OUTPUT:
%   evalMatrix_training_t: transformed training dataset limited to relevant PCs
%   Mdl: fitted discriminant analysis model
%   W: transformation matrix
%   
% Authors: Aline Knab
% Date: 06.08.2023

% Create fitted discriminant analysis model
Mdl = fitcdiscr(evalMatrix_training,myClassesC_training,'DiscrimType','pseudolinear'); % initial version
                
% Project into subspace
[W, LAMBDA] = eig(Mdl.BetweenSigma, Mdl.Sigma); 
lambda = diag(LAMBDA);
[~, I] = sort(lambda, 'descend');
W = W(:,I);

evalMatrix_training_t = evalMatrix_training*W;

end