function [evalMatrix,normVal] = compNormalize(evalMatrix,normalizeType,normVal)
% The user selects the different methods to normalize the data
%
% INPUT: 
%       evalMatrix: double array containing entire data set 
%           (rows:observations, columns: features)
%       normalizeType: string for normlization method (Min-Max/Z-score/
%           Robust scaling/Unit vector transformation/Log transformation)
%
% OUTPUT: 
%       evalMatrix: double array containing entire data set after normalizing
%           (rows:observations, columns: features)
%       normVal: structure with data to rerun normalization  
%
% Authors: Xiaohu Xu, Aline Knab
% Date: 24.11.2023

recalculate = false;
if nargin < 3
    recalculate = true;
    normVal = struct;
end
    
if strcmpi(normalizeType, "minmax") % Min-Max normalization
    if recalculate
        normVal.minVals = min(evalMatrix);
        normVal.maxVals = max(evalMatrix);
    end
    evalMatrix = (evalMatrix - normVal.minVals) ./ (normVal.maxVals - normVal.minVals);

elseif strcmpi(normalizeType, "zscore") % Z-score normalization
    if recalculate
        normVal.myMean = mean(evalMatrix,'omitnan'); 
        normVal.myStd = std(evalMatrix,'omitnan');
    end
    normVal.myStd(normVal.myStd==0) = 1; % avoid division by 0
    evalMatrix = (evalMatrix-normVal.myMean)./normVal.myStd;

elseif strcmpi(normalizeType, "robust") % Robust scaling normalization
    if recalculate
        normVal.medianVals = median(evalMatrix);
        normVal.iqrVals = iqr(evalMatrix);
    end
    evalMatrix = (evalMatrix - normVal.medianVals) ./ normVal.iqrVals;

elseif strcmpi(normalizeType, "unitvector") % Unit vector transformation normalization XIAOHU: Please double-check
    if recalculate
        normVal.norms = sqrt(sum(evalMatrix.^2, 1));
    end
    evalMatrix = evalMatrix ./ normVal.norms;

elseif strcmpi(normalizeType, "logtrans") % Log transformation normalization
    evalMatrix = log(evalMatrix);
end

end