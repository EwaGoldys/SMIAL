function [idxKeep,idxRest] = downsample(myClassesC)
% performs downsampling to ensure class balance
%
% INPUT: 
%   myClassesC: categorial including class labels of evalMatrix
%
% OUTPUT:
%   idxKeeps: indices to keep
%   idxRest: indices to delete
% 
% Authors: Aline Knab
% Date: 11.09.2024

%% Random undersampling
myGroups = categories(myClassesC);
numObservations = countcats(myClassesC);
minObs = min(numObservations);

idxKeep = [];
idxRest = [];

for iClass = 1:size(myGroups,1)
    idx_Org = (1:length(myClassesC)).';
    idx_Org = idx_Org(myClassesC==myGroups(iClass));

    if numObservations(iClass) == minObs
        idxKeep = [idxKeep;idx_Org];
    else
        keep = false([numObservations(iClass),1]);
        keep(randperm(numObservations(iClass),minObs))=true;
        idxKeep = [idxKeep;idx_Org(keep)];
        idxRest = [idxRest;idx_Org(~keep)];
    end
end

end