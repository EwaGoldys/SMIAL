function [out] = fsGini(X,Y)
% feature reanking based on gini index 
%
% INPUT:
%   X: The features on current trunk, each column is a feature vector on 
%       all instances, and each row is a part of the instance.
%   Y: The label of instances, in single column form: 1 2 3 4 5 ...
%
% OUTPUT:
%   out: A struct containing the following fields:
%       * w: a list containing the information gain of each feature when 
%           matched with fList.
%   fList: the list of features ranked by their ability to classify the 
%       data. fList(1) is the least important feature.
%   prf: will always be -1. This means the greater the feature weight, 
%       the more relevant the feature.
%
% from: https://jundongl.github.io/scikit-feature/OLD/algorithms_old.html

    [~,nFeatures] = size(X);
    labelRange = min(Y):max(Y);
    totalN = numel(Y);

     W = 0.5 * ones(nFeatures, 1);  % Default value like original
    
    for i = 1:nFeatures
        xi = X(:,i);
        splitVals = unique(xi);

        for sv = 1:numel(splitVals)
            threshold = splitVals(sv);
            leftMask = xi <= threshold;
            rightMask = ~leftMask;

            leftY = Y(leftMask);
            rightY = Y(rightMask);

            if isempty(leftY) || isempty(rightY)
                continue;  % skip empty split
            end

            % Gini for left
            gini_left = 0;
            for k = labelRange
                pk = sum(leftY == k) / numel(leftY);
                gini_left = gini_left + pk^2;
            end
            gini_left = 1 - gini_left;

            % Gini for right
            gini_right = 0;
            for k = labelRange
                pk = sum(rightY == k) / numel(rightY);
                gini_right = gini_right + pk^2;
            end
            gini_right = 1 - gini_right;

            % Weighted Gini
            current_gini = (numel(leftY)*gini_left + numel(rightY)*gini_right) / totalN;

            if current_gini < W(i)
                W(i) = current_gini;
            end
        end
    end

    [out.w, out.fList] = sort(W);
    out.prf = -1;
end