function [sure1,sigma,h,xp]=FOSRPDN_SURE(yp,t0,tstep,tend,qmf,options)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code implements the denoising technique illustrated in the following Paper.
%
% B. Rasti, J. R. Sveinsson, M. O. Ulfarsson, and J. A. Benediktsson, �Hyperspectral
% image denoising using first order spectral roughness penalty in wavelet
% domain,� IEEE Journal of Selected Topics in Applied Earth Observations and Remote
% Sensing, vol. 7, no. 6, pp. 2458�2467, Jun 2014.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function can be used as either of the following cases;
% 
%  [sure1,sigma,h,xp]=FORPDN_SURE(yp,t0,tstep,tend,qmf,sigma,options)
%  [sure1,sigma,h,xp]=FORPDN_SURE(yp,t0,tstep,tend,qmf,sigma)
%  [sure1,sigma,h,xp]=FORPDN_SURE(yp,t0,tstep,tend,qmf)    
%  [sure1,sigma,h,xp]=FORPDN_SURE(yp,t0,tstep,tend)
%
% Input
% yp: Hyperspectral image (3D matrix).
% [t0:tstep:tend]: The intervals for SURE function,
%                  t0: Starting points of the intervals, a vector of length
%                  L+1 (for FORPDNT).
%                  tstep: Step size of the intervals, a vector of length
%                  L+1 (for FORPDNT).
%                  tend: Ending points of the intervals, a vector of length
%                  L+1 (for FORPDNT).
%                  L: the level of wavelet decomposition
% qmf: quadrature mirror filter, qmf=0 uses the default filter (D12).
% options: structure array,options=0 uses the default options
%                          options.noisest=1: only noise will be estimated
%                          using madian filter on wavelet coefficients (HH)
%                          (default: options.noisest=0)
%
%                          options.scaling=1: applying scaling on data set
%                          for each band, and rescaling in the end. Note
%                          that in this type of scaling the spectrum is
%                          recoverable. (default: options.scaling=1)
%
%                          options.type: 'FORPDNT' is denoising in the
%                                         wavelet domain
%                                         'FORPDNS' is denoising in the
%                                         signal domain
%                          (default: options.type='FORPDNT')
%
%                          options.WaveletToolbox: The type of the Wavelet
%                          toolbox, 'Rice' or 'WaveLab_Fast' (the fast Wavelet 
%                          toolbox written by the author, Behnood Rasti).
%                          (default is 'WaveLab_Fast')
%
% output
% xp: The denoised Hyperspectral image (3D matrix)
% sigma: Noise standard deviation for each band as a vector
% h: optimal parameters for SURE function
% sure1: SURE function (in cell format for each sub-band)
%
% Examples
% (1) Denoising using default values
% [sure1,sigma,h,xp]=FORPDN_SURE(yp,[0,0,0,0],[.001,.01,.1,1],[.01,.1,1,10]);
% (2) Denoising using default wavelet filter and Rice toolbox
% options.noisest=0;
% options.scaling=1;
% options.type='FORPDNT';
% options.WaveletToolbox='Rice';
% [sure1,sigma,h,xp]=FORPDN_SURE(yp,[0,0,0,0],[.001,.01,.1,1],[.01,.1,1,10],0,options);
%
% see also twoDWTon3Ddata, ItwoDWTon3Ddata, FWT_PO_1D_2D_3D_fast, IWT_PO_1D_2D_3D_fast
%
% (c) 2013 Written by Behnood Rasti
% email: behood.rasti@gmail.com


if isempty(yp)
    xp='Not assigned';
    h=xp;
    sure1=h;
    sigma=sure1;
    warning('No input is assigned')
    return;
end

c_bit=0;
if nargin<6
    options.noisest=0;
    options.scaling=1;
    options.type='FORPDNT';
    options.WaveletToolbox='WaveLab_Fast';
end


switch options.WaveletToolbox
    case 'Rice'
        FWT='mdwt';
        IWT='midwt';
%     case 'WaveLab'
%         FWT='FWT2_PO2';
%         IWT='IWT2_PO2';
    case 'WaveLab_Fast'
        FWT='FWT_PO_1D_2D_3D_fast';
        IWT='IWT_PO_1D_2D_3D_fast';
    otherwise
        error('Please choose a Wavelet toolbox according to the help')
end



[nr1,nc1,p1]=size(yp);
% scaling
if options.scaling
    a=255;
    [yp,Min,Max,v] = scale_wo_shift(yp,a);
end

% Decomposition level
L=length(t0)-1;

% Symetric extension
if mod(nr1,2^L)~=0
    yp=extension('2d','sym',yp,[2^L-mod(nr1,2^L),0],'r',0,'r');
end
if mod(nc1,2^L)~=0
    yp=extension('2d','sym',yp,[0,2^L-mod(nc1,2^L)],'r',0,'r');
end

[nr,nc,p]=size(yp);
yp_m=reshape(yp,nr*nc,p);
xp2=yp_m;

% Noise estimation using HH and median
if 1
%     L1=1;%level of decompositions
%     NFC1=4;%number of filter coefficients
%     qmf1 = daubcqf(NFC1,'min');%wavelet filter
%     [Ax1,s1,s2]=twoDWTon3Ddata(yp,L1,qmf1,FWT);% V=D'*Y, Y=reshape_3D_data_to_2D(H);
%     idx_sigma = 3*(nr/2^(L1-L1+1))*(nc/2^(L1-L1+1))+1:4*(nr/2^(L1-L1+1))*(nc/2^(L1-L1+1));
%     sigma = (median(abs(Ax1(idx_sigma,:)))/0.6745)'+eps;
[w Rw]=estNoise(yp_m');
sigma=sqrt(var(w')');
end

if options.noisest
    xp='Not assigned';
    h=xp;
    sure1=h;
    warning('No output is assigned, only noise is estimated using wavelets')
    return;
end

% quadrature mirror filter
if nargin<5 || isempty(qmf)
    NFC=12;qmf = daubcqf(NFC,'min');
end

C_12=diag(sigma);
[U,S,V] = svd(C_12*Dvt(Dv(C_12)),'econ');
C_1=C_12.^2;
C_12_U=C_12*U;
C_12_V=V'*C_12;

t=t0(1):tstep(1):tend(1);
if tstep(1)==0; t=0; end % debug
%sure=zeros(size(t,2),1);
diagS=diag(S);
i=1;
switch options.type
    case 'FORPDNS'
        x_1=reshape(yp,nr*nc,p);
        x1=repmat(sigma(:)'.^-2,nr*nc,1).*x_1;
        for lambda=t
            %
            SIGMA_lambda_eye=diag(1./(1./(lambda*diagS)+1));
            Majc=C_1-C_12_U*(SIGMA_lambda_eye*C_12_V);
            %
            %         SIGMA_lambda_eye=diag(1./(lambda*diagS))+eye(p);
            %         Majc=C_1-C_12_U*(SIGMA_lambda_eye\C_12_V);
            %
            xp_m=(Majc*x1')';
            norm1=norm(vec(yp_m-xp_m))^2;
            sure(i,1)=norm1/(nr*nc)+2*trace(Majc);
            if i>1 && sure(i,1)>sure(i-1,1)
                c_bit=1;
                break;
            end
            xp=reshape(xp_m,nr,nc,p);
            i=i+1;
        end
        [I1,I2]=min(sure);
        h=t(I2);
        sure1=sure;
    case 'FORPDNT'
        i=1;
        h=zeros(L+1,1);
        if sigma~=0
            [Ax1,s1,s2]=twoDWTon3Ddata(yp,L,qmf,FWT);
        end
        Ax=repmat(sigma'.^-2,nr*nc,1).*Ax1;
        for lambda=t
            idx=1:(nr/2^L)*(nc/2^L);
            SIGMA_lambda_eye_L=diag(1./(1./(lambda*diagS)+1));
            Majc=C_1-C_12_U*(SIGMA_lambda_eye_L*C_12_V);
            xp0=(Majc*Ax(idx,:)')';
            norm1=norm(vec(Ax1(idx,:)-xp0))^2;
            sure(i,1)=norm1/(length(idx))+2*trace(Majc);
            if i>1 && sure(i,1)>sure(i-1,1)
                c_bit=1;
                break;
            end
            xp2(idx,:)=xp0;
            i=i+1;
        end
        if c_bit==0
            warning(['The optimum regularization parameter has not found for the 1st interval.',...
                'you might want to consider to increase the 1st interval.'])
        end
        [I1,I3]=min(sure);
        h(1)=t(I3);
        sure1{1,1}=sure;
        if h(1)==t(1)
            warning(['SURE selects zero for LL: To get better performance decrease tstep for the 1st interval.',...
                ' Probably you can decrease tend as well.']);
        end
        for j=1:L
            c_bit=0;
            i=1;
            t=t0(j+1):tstep(j+1):tend(j+1);
            if tstep(j+1)==0; t=0; end % debug
            clear sure;
            for lambda=t
                idx=(nr/2^(L-j+1))*(nc/2^(L-j+1))+1:4*(nr/2^(L-j+1))*(nc/2^(L-j+1));
                %            I_lambdaDtD=(diag(sigma.^-2)+lambda*(DV1TDV1));
                %            xp1=((diag(sigma.^-2)+lambda*(DV1TDV1))\Ax(idx,:)')';
                SIGMA_lambda_eye_H=diag(1./(1./(lambda*diagS)+1));
                Majc=C_1-C_12_U*(SIGMA_lambda_eye_H*C_12_V);
                xp1=(Majc*Ax(idx,:)')';
                norm1=norm(vec(Ax1(idx,:)-xp1))^2;
                sure(i,1)=norm1/(length(idx))+2*trace(Majc);
                if i>1 && sure(i,1)>sure(i-1,1)
                    c_bit=1;
                    break;
                end
                i=i+1;
                xp2(idx,:)=xp1;
            end
            if c_bit==0
                warning(['The optimum regularization parameter has not found for the ',...
                    num2str(j+1) '-th interval, you might want to consider to increase this interval.'])
            end
            [I1,I2]=min(sure);
            h(j+1)=t(I2);
            sure1{j+1,1}=sure;
            if h(j+1)==t(1)
                warning(['SURE selects zero, please decrease tstep for the ',...
                    num2str(j+1) '-th interval, Probably you can decrease tend as well.']);
            end
            
        end
        xp = ItwoDWTon3Ddata(xp2,s1,s2,L,qmf,IWT);
end
xp=xp(1:nr1,1:nc1,1:p1);
% rescaling
if options.scaling
    xp = rescale_wo_shift(xp,a,Min,Max);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y,m,M,v] = scale_wo_shift(x1,a)

[nx,ny,nz]=size(x1);
x=reshape(x1,nx*ny,nz);

m = min(x);
M = max(x);
v=var(x);
if M-m<eps
    y1 = x;
else
    y1 = x./repmat(M-m,nx*ny,1).*a;
    %y = (x)/(v)*a;
end


y=reshape(y1,nx,ny,nz);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y] = rescale_wo_shift(x1,a,m,M)

[nx,ny,nz]=size(x1);
x=reshape(x1,nx*ny,nz);

if M-m<eps
    y1 = x;
else
    y1 = (x)./a.*repmat(M-m,nx*ny,1);
    %y = (x)/(v)*a;
end


y=reshape(y1,nx,ny,nz);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [y, s1, s2]=twoDWTon3Ddata(x,L,qmf,FWT)

% usage
% [y, s1, s2]=twoDWTon3Ddata(x,L,qmf,FWT)
% Take the 2D-DWT for each band and reshape subbands as [wLL(:);wLH(:);wHL(:);wHH(:)];
% input
% x: 3D data
% L: level of decomposition
% qmf: quadrature mirror filter
% FWT: either 'mdwt' (Rice toolbox), or 'FWT_PO_1D_2D_3D'. mdwt is default which is a mex
% and faster if there is any difficulty choose FWT_PO_1D_2D_3D
%
% output
% y: vactorized 2D ortho-wavelet coefficient for each band as [wLL(:);wLH(:);wHL(:);wHH(:)];
% s1: the number of rows
% s2: the number of columns
% See also ItwoDWTon3Ddata
%
% (c) 2012 Behnood Rasti

[s1,s2,s3]=size(x);

if nargin<4
    FWT='mdwt';
end

if nargin<3
    NFC=4;qmf = daubcqf(NFC,'min');
end

if nargin<2
    L=3;
end

if nargin<1
    error('No input is given');
end

if s3==1
    warning('Input is a 2D matrix')
end


% if nargin==1
%     L=3;%level of decompositions
%     NFC=4;%number of filter coefficients
%     qmf = daubcqf(NFC,'min');%wavelet filter
% end

y=zeros(s1*s2,s3);

% if strcmpi(FWT,'wavedec2')
%     s1=[];
%     for i=1:s3
%         [y1,S_S] = wavedec2(x(:,:,i),L,['db',num2str(length(qmf)+2)]);
%         y(:,i)=vec(y1);
%         s1(:,:,i)=S_S;
%     end
% else

for i=1:s3
    ydum2=[];
    nx=s1;ny=s2;
    %y1 = FWT2_PO_mine(x(:,:,i),L,qmf);%2d forward transform
    %y1 = mdwt(x(:,:,i),qmf,L);%2d forward transform
    y1=eval([FWT '(x(:,:,i),qmf,L)']);
    ydum=y1;
    for j=1:L
        y2 = mat2cell(ydum,[nx/2,nx/2],[ny/2,ny/2]);
        wLH=cell2mat(y2(1,2));
        wHL=cell2mat(y2(2,1));
        wHH=cell2mat(y2(2,2));
        ydum2= [wLH(:);wHL(:);wHH(:);ydum2];
        nx=nx/2;ny=ny/2;
        ydum=cell2mat(y2(1,1));
    end
    y(:,i)=[ydum(:);ydum2];
end
% end
%s1=S(1);s2=S(2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y=ItwoDWTon3Ddata(x,s1,s2,L,qmf,IWT)

% usage y=ItwoDWTon3Ddata(x,s1,s2,L,qmf)
% Take the 2D-IDWT for each band and reshape subbands as 3D data;
% input
% s1 : the number of rows
% s2 : the number of columns
% x : 2D matrix consist of vectorized 2D wavelet coefficients
% L : level of decomposition
% qmf : quadrature mirror filter
% IWT: Either 'midwt', or 'IWT_PO_1D_2D_3D'. mdwt is default which is a mex
% and faster if there is any difficulty choose IWT_PO_1D_2D_3D
% output
% y : 2D inverse wavelet transform for each band if coefficients matrix x
% created by [x, s1, s2]=twoDWTon3Ddata(y)
%
% See also twoDWTon3Ddata
%
% (c) 2012 Behnood Rasti

if nargin<6
    IWT='midwt';
end

if nargin<5
    NFC=4;qmf = daubcqf(NFC,'min');
end

if nargin<4
    L=3;
end

if nargin<3
    error(['At least three input should be given.',...
        'The size of the image for each band is neccessary, please look at the help and use twoDWTon3Ddata']);
end

% if nargin==3
%     L=3;%level of decompositions
%     NFC=4;%number of filter coefficients
%     qmf = daubcqf(NFC,'min');%wavelet filter
% end
S=size(x);
if S(2)==1
    warning('Input is a 2D matrix')
end

y=zeros(s1,s2,S(2));
% if strcmpi(IWT,'waverec2')
%     for i=1:S(2)
%         [y(:,:,i)] = waverec2(x(:,i),s1(:,i),['db',num2str(length(qmf)+2)]);
%     end
% else
for i=1:S(2)
    yLL=reshape(x(1:(s1/2^L)*(s2/2^L),i),(s1/2^L),(s2/2^L));
    y1=yLL;
    for j=1:L
        yLH=reshape(x(1*(s1/2^(L-j+1))*(s2/2^(L-j+1))+1:2*(s1/2^(L-j+1))*(s2/2^(L-j+1)),i),(s1/2^(L-j+1)),(s2/2^(L-j+1)));
        yHL=reshape(x(2*(s1/2^(L-j+1))*(s2/2^(L-j+1))+1:3*(s1/2^(L-j+1))*(s2/2^(L-j+1)),i),(s1/2^(L-j+1)),(s2/2^(L-j+1)));
        yHH=reshape(x(3*(s1/2^(L-j+1))*(s2/2^(L-j+1))+1:4*(s1/2^(L-j+1))*(s2/2^(L-j+1)),i),(s1/2^(L-j+1)),(s2/2^(L-j+1)));
        y1=[y1 yLH;yHL yHH];
    end
    y(:,:,i)=eval([IWT '(y1,qmf,L)']);
    %y(:,:,i) = IWT2_PO_mine(y1,L,qmf);%2d forward transform
    %y(:,:,i) = midwt(y1,qmf,L);%2d forward transform
end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y=Dv(x,n)

% input
% x: vector or matrix
% output
% y: n-th vertical difference, default=1;
%
% see also Dvt, Dh, Dht
% (c) 2012, Behnood Rasti

if nargin<2
    n=1;
end
y=zeros(size(x));
y(1:end-1,:)=diff(x,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y=Dvt(z)

% input
% x: vector or matrix
% output
% y: n-th transpose oprator of Dv, default=1;
%
% see also Dv, Dh, Dht
% (c) 2012, Behnood Rasti

%  if nargin<2
%      n=1;
%  end
%
%  % y=[-z(1,:);-diff(z,n);-z(end,:)];
% y=[-z(1,:);-diff(z,n)];

u0 = -z(1,:);
u1 = -diff(z);
u2 = z(end-1,:);
y = [u0; u1(1:(end-1),:); u2];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Y]=extension(TYPE,MODE,X,L,LOC,s3,LOCz)
%
% s3 : The size of the extension in third direction
% s3=0 : no extension in the z direction
% The type of the extension is symmetric-
% The code is not written for general case yet
% LOC :  'r' or 'd' for down and right extension
%        'l' or 'u' for left and up extension
% LOCz : 'lr' or 'rl' for left and right extension symmetrically
%        'l'  for left extension symmetrically
%        'r'  for right extension symmetrically
% This is a modified version of the wextend for the full help
%
% See also wextend
%
% Written by Behnood Rasti
% (c) 2012


% Note : In the third axis the code extends symmetrically to left or
% right or both


[n1,n2,n3]=size(X);

for i=1:n3
    Y(:,:,i) = wextend(TYPE,MODE,X(:,:,i),L,LOC);
end

if s3>n3
    error('Symmetric extension in the z-direction is impossible, the extension size is larger than data size')
end
if s3~=0 && n3~=0
    switch LOCz
        case {'lr', 'rl'}
            y1=flipdim(Y(:,:,1:floor(s3/2)),3);
            y2=flipdim(Y(:,:,end-ceil(s3/2)+1:end),3);
            y3 = cat(3,y1,Y);
            Y = cat(3,y3,y2);
            if mod(s3,3)~=0
               warning(' The extension is not symmetric, one component more in the right ')
            end
        case {'l'}
            y1=flipdim(Y(:,:,1:s3),3);
            Y = cat(3,y1,Y);
        case {'r'}
            y2=flipdim(Y(:,:,end-s3+1:end),3);
            Y = cat(3,Y,y2);
        otherwise
            warning('The data is not extended in the z diretion')
    end
end