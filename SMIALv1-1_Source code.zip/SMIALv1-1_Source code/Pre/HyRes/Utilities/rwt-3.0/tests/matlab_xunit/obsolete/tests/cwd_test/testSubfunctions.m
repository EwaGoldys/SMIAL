function test_cases = testSubfunctions
%testSubfunctions Contains two passing subfunction tests

%   Steven L. Eddins
%   Copyright 2008 The MathWorks, Inc.

findSubfunctionTests;

function testSub1

function testSub2
