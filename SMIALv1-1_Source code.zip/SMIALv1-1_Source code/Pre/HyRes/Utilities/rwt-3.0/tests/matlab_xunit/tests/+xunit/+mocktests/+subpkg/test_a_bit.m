function test_suite = test_a_bit
initTestSuite

function test_now

function test_later
