function test_suite = testSubfunctions
%testSubfunctions Contains two passing subfunction tests

%   Steven L. Eddins
%   Copyright 2008 The MathWorks, Inc.

initTestSuite;

function testSub1

function testSub2
