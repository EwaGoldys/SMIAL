function [mask, myMedian] = getBackground(im, mask,isHAC)
% gets median value of background regions
%
% INPUT: 
%   im: input image
%   mask: double array with one parameter per channel
%   excludeFinal: boolean, true -> remove final image in image stack
%   isHAC: boolean, deletes final image if true
%
% OUTPUT
%   mask: background mask
%   myMedian: median of background regions
% 
% Authors: Aline Knab
% Date: 17.10.2022

if nargin<4 || ~isHAC
    numHAC = 0;
else
    numHAC = 1;
end

%% Masks provided
mask = imread(mask);
if ~islogical(mask)
    if isfloat(mask)
        mask = rgb2gray(mask) > 0.5;
    else
        mask = rgb2gray(mask) >= 128;
    end
end

myMedian = zeros(size(im,3)-numHAC,1);

for i = 1:size(im,3)-numHAC
    imNow = im(:,:,i);
%     myMean(i) = mean(imNow(mask));
    myMedian(i) = median(imNow(mask));
end

end

