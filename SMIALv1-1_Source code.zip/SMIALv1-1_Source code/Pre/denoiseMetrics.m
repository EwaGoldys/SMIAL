function [myTable] =  denoiseMetrics(myFileInfoIM,fileSmooth,myCh, ...
    myFileInfoMASK,myFileInfoMASK_back,qSetting,sSettings,tableObj)
% Computes denoising metrics; assumes hcube has no noise
%
% INPUT: 
%   fileOrg: string array defining original image (row 1: pathname, row 2: filename)
%   fileSmooth: string array defining original smoothed (row 1: pathname, row 2: filename)
%   myCh: index of channel to analyze
%   maskFront: string array defining mask (row 1: pathname, row 2: filename)
%   maskBack: string array defining background mask (row 1: pathname, row 2: filename)
%   qSetting: struct including booleans on what to compute in quality check
%       (snr, psnr, ssim, mmsim, mse, rmse)
%   sSettings: struct including smoothing settings (see preProcess)
%   tableObj: table object (optional)
% 
% OUTPUT:
%   myTable: table with results assessing improvement via denoising
%
% Author: Aline Knab
% Date: 01.12.2023
%
% Last modified: 
%  21.02.2025 (Aline Knab): switched file info to structure

%% Load files
if size(qSetting,2)>1 || ~strcmp(qSetting{1},"snr")
    hcube_org = loadFile(myFileInfoIM.folder,myFileInfoIM.name); 
    hcube_org = hcube_org(:,:,myCh);
end
hcube_smooth = loadFile(fileSmooth{1},fileSmooth{2});
hcube_smooth = hcube_smooth(:,:,myCh);

%% Initialize variables
nChannel = sSettings.numCh-sSettings.excludeFinal;
mysnr = nan(nChannel,3);
peaksnr = nan(nChannel,1);
similarity = nan(nChannel,1);
multisimilarity = nan(nChannel,1);
mserror = nan(nChannel,1);
rmserror = nan(nChannel,1);

%% Compute quality metrics
for iChannel = 1:nChannel
    for i = 1:size(qSetting,2)
        setting_c = qSetting{i};
        switch setting_c
            case "snr"
                if iChannel == 1
                    % Calibrate original file
                    Im.myFileInfoIM = myFileInfoIM; 
                    if sSettings.shift
                        Im.myFileInfoMASK_back = myFileInfoMASK_back;
                    end
                    sSettings.ImSmooth = false;
                    sSettings.cosmRays = false;
    
                    hcube_orgCal = preProcess(sSettings,Im,false);
                    hcube_orgCal = hcube_orgCal(:,:,myCh);
    
                    % Load masks
                    mask = loadFile(myFileInfoMASK.folder,myFileInfoMASK.name,true);
                    back = loadFile(myFileInfoMASK_back.folder,myFileInfoMASK_back.name,true);
    
                    % Compute SNR
                    mysnr(:,1) = compSNR(hcube_orgCal,mask,back);
                    mysnr(:,2) = compSNR(hcube_smooth,mask,back);
                    mysnr(:,3) = mysnr(:,2)./mysnr(:,1).*100; % percentage of initial
                end

            case "psnr"
                [peaksnr(iChannel),~] = psnr(hcube_org(:,:,iChannel),hcube_smooth(:,:,iChannel));
            case "ssim"
                similarity(iChannel) = ssim(hcube_org(:,:,iChannel),hcube_smooth(:,:,iChannel));
            case "msssim"
                multisimilarity(iChannel) = multissim(hcube_org(:,:,iChannel),hcube_smooth(:,:,iChannel));
            case "mse"
                mserror(iChannel) = immse(hcube_org(:,:,iChannel),hcube_smooth(:,:,iChannel));
            case "rmse"
                cmserror = immse(hcube_org(:,:,iChannel),hcube_smooth(:,:,iChannel));
                rmserror(iChannel) = sqrt(cmserror);
        end
    end
end

%% Generate table
varNames = ["SNR Original (O)","SNR Smoothed (S)","SNR S/O [%]","PSNR","SSIM","MS-SSIM","MSE","RMSE"];
myTable = [mysnr,peaksnr,similarity,multisimilarity,mserror,rmserror];
idxNan = all(isnan(myTable),1);
varNames(idxNan) = [];
myTable = myTable(:,all(~isnan(myTable)));
myTable = [mean(myTable,1);myTable]; % Average
myCh = ["Average",myCh];
myTable = array2table(myTable);
myTable.Properties.VariableNames = varNames;

%% Populate table object if available
if exist("tableObj","var")    
    saveLoc = fullfile(sSettings.saveFolder, "Quality");
    if ~exist(saveLoc, 'dir')
       mkdir(saveLoc);
    end
    [~,myFilename,~] = fileparts(myFileInfoIM.name);
    writetable(myTable,fullfile(saveLoc,...
        append(myFilename,'_',string(datetime('now','TimeZone','local','Format','d-MM-y_HH-mm-ss')),'_preprocessingQuality','.xlsx')), ...
        'WriteMode','overwritesheet');
    tableObj.Visible = true;
    tableObj.Data = myTable;
    tableObj.ColumnName = varNames;
    tableObj.RowName = myCh;
end