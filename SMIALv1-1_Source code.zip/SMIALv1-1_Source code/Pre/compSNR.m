function mySNR = compSNR(im,maskFront,maskBack)
% computes snr of input image
% 
% INPUT:
%   im: double input image
%   maskFront: binary mask of objects
%   maskBack: binary mask of background regions
% 
% OUTPUT:
%   mySNR: double filled with SNR in dB (size number of channelsx1)
% 
% Author: Aline Knab
% Date: 04.02.2024

maskFront = logical(maskFront);
maskBack = logical(maskBack);

mySNR = nan(size(im,3),1);
for iChannel = 1:size(im,3)
    % imFront = im(:,:,iChannel).*logical(maskFront);
    % imBack = im(:,:,iChannel).*logical(maskBack);
    % mySNR(iChannel) = 10 * log10((max(imFront(:))-median(imBack(:)))./std(imBack(:)));

    im_c = im(:,:,iChannel);
    mySNR(iChannel) = 10 * log10((max(im_c(maskFront))-median(im_c(maskBack)))./std(im_c(maskBack)));
end

end

