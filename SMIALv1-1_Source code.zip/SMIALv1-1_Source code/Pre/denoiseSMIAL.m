function hCube = denoiseSMIAL(hCube,myMethod,myParameter,excludeFinal,showComp)
% Calls selected denoising method
%
% INPUT: 
%   hCube: hyperspectral data cube
%   myMethod: string specifying smoothing option (cosmic, FOSRPDN, Gaussian
%       Filter, HyRes, Median Filter, Moving Average, Wavelet bior4.4, 
%       Wavelet CDF9/7,convoluation, Top hat filter, Bottom hat filter)
%   myParameter: double array with one parameter per channel
%   excludeFinal: boolean, true -> remove final image in image stack
%   showComp: false or channel to display
%
% OUTPUT
%   hCube: smoothed data cube
% 
% Authors: Aline Knab, Shannon Handley
% Date: 16.10.2023

if nargin < 4; excludeFinal = true; end
if nargin < 5; showComp = false; end

if exist('myParameter','var')
    if size(myParameter,1)==1
        myParameter = repmat(myParameter,size(hCube,3),1);
    end
end

if strcmp(myMethod,'cosmic') && all(myParameter(:)==0) 
    return;  
end

%% Handle excluding final image
if excludeFinal && size(hCube,3) > 1
    nChannel = size(hCube,3)-1;
else
    nChannel = size(hCube,3);
end

if strcmp(myMethod,'Network')
    net = denoisingNetwork('DnCNN'); 
end

%% Setup extra background
myExtraBack = zeros([size(hCube,1),size(hCube,2),nChannel]);

%% Choose smoothing method
for iChannel = 1:nChannel
    if strcmp(myMethod,'cosmic') || ~isa(myParameter,'double') || myParameter(iChannel) ~= 0 ||...
            ismember(myMethod,["HyRes";"denoiseNGMeet";"FOSRPDN"])
        switch myMethod  
            case 'Wavelet CDF9/7'
                hCube(:,:,iChannel) = waveletHS(hCube(:,:,iChannel),myParameter(iChannel)); % currently only squared images, needs adaptation!
            case 'Wavelet bior4.4'
                hCube(:,:,iChannel) = wdenoise2(hCube(:,:,iChannel));
            case 'Median Filter'
                hCube(:,:,iChannel) = medfilt2(hCube(:,:,iChannel),[round(myParameter(iChannel)),round(myParameter(iChannel))]);
            case 'Gaussian Filter'
                hCube(:,:,iChannel) = imgaussfilt(hCube(:,:,iChannel),myParameter(iChannel));
            case 'Moving Average'
                h = fspecial('average',round(myParameter(iChannel)));
                hCube(:,:,iChannel)= imfilter(hCube(:,:,iChannel),h,'replicate');
            case 'denoiseNGMeet' % does not perform well
                if iChannel == 1
                    hCube(:,:,myParameter>0) = denoiseNGMeet(hCube(:,:,myParameter>0));
                end
            case 'HyRes'
                if iChannel == 1
                    hCube(:,:,myParameter>0)=HyRes(hCube(:,:,myParameter>0));
                end
            case 'FORPDN'
                if iChannel == 1
                    [~,~,~,hCube(:,:,myParameter>0)]=FOSRPDN_SURE( ...
                        hCube(:,:,myParameter>0),[0,0,0,0],[.001,.01,.1,1],[.01,.1,1,10]);
                end
            case 'Network'
                myMax = max(reshape(hCube(:,:,iChannel),[],1));
                myMin = min(reshape(hCube(:,:,iChannel),[],1));
                hCube(:,:,iChannel) = denoiseImage(mat2gray(hCube(:,:,iChannel)),net)...
                    .*(myMax-myMin)+myMin; 
            case 'cosmic' %cosmic ray removal
                hCube(:,:,iChannel) = cosmicrr(hCube(:,:,iChannel), myParameter(1), myParameter(2));
            case 'convolution'
                [hCube(:,:,iChannel), myExtraBack(:,:,iChannel)] = Img_Flattening_convolution(hCube(:,:,iChannel),myParameter(iChannel));
            case 'Top hat filter'
                [hCube(:,:,iChannel), myExtraBack(:,:,iChannel)] = Img_Flattening_erosion_dilation(hCube(:,:,iChannel),myParameter{2}, myParameter{1});  %SH
            case 'Bottom hat filter'
                [hCube(:,:,iChannel), myExtraBack(:,:,iChannel)] = Img_Flattening_dilation_erosion(hCube(:,:,iChannel),myParameter{2}, myParameter{1});  %SH
        end
    end
end

% show Background computation (convolution, top hat filter, bottom hat
% filter
if showComp && any(contains(["convolution","Top hat filter","Bottom hat filter"],myMethod))
    if size(myExtraBack,3) == 1; chTitle = append(" Sample, ", myMethod);
    else; chTitle = []; end
    f = showAll(myExtraBack(:,:,showComp),chTitle,'surface');
    f.Name = append(myMethod,", computed filter");
end

if ~isinteger(hCube)
    hCube = round(hCube,5,'significant');
end

end