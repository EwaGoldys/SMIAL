function tab = compareMasks(myFileInfoMASK,myFileInfoMASK_true,myOptionsComp)
% Compares mask and ground truth mask quantitativly
%
% INPUT: 
%   myFileInfoMASK: struct containing information on files
%       * folder: path name of comparison mask
%       * name: filenames of comparison masks
%   myFileInfoMASK_true: struct containing information on files
%       * folder:  path name of true mask
%       * name: cell filenames of true masks
%   myOptionsComp: cell array with computation options (IoU, F1 Score,
%       Precision, Recall)
%
% OUTPUT
%   tab: table with comparison values
% 
% Author: Max Mackevicius
% Date: 25.01.2024
%
% Last modified: 
%  16.01.2025 (Aline Knab): switched file info to structure

%% Prepare table
tab = table('Size',[size(myFileInfoMASK,1)+1,size(myOptionsComp,2)+1],...
    'VariableTypes',["string",repmat("double",1,size(myOptionsComp,2))]);
tab.Properties.VariableNames = ["Filename",myOptionsComp];
tab(1,1) = {"Average"};
tab(2:end,1) = {myFileInfoMASK.name}.';

%% Compute Comparison
for iFile = 1:size(myFileInfoMASK,1)
    CPMask = loadFile(myFileInfoMASK(iFile).folder,myFileInfoMASK(iFile).name,true);
    GTMask = loadFile(myFileInfoMASK_true(iFile).folder,myFileInfoMASK_true(iFile).name,true);
    
    %% Calculate the Intersection over Union (IoU) for true positives
    if any(ismember(cellstr(myOptionsComp),"IoU"))
        intersect = GTMask & CPMask;
        union = GTMask | CPMask;
        tab(iFile+1,find(ismember(cellstr(myOptionsComp),"IoU"))+1) = num2cell(double(sum(intersect(:)) / sum(union(:))));
    end    
       
    %% Recall, Precision and F score Generation
    if any(contains(cellstr(myOptionsComp),["F1 Score","Precision","Recall"]))

        % True positives
        TrueP = GTMask & CPMask;
        tpPixels = sum(TrueP(:));
        % False Positives
        FalseP = ~GTMask & CPMask;
        fpPixels = sum(FalseP(:));
        % False Negatives
        FalseN = GTMask & ~CPMask;
        fnPixels = sum(FalseN(:));
        
        % Precision
        if any(ismember(cellstr(myOptionsComp),"Precision"))
            tab(iFile+1,find(ismember(cellstr(myOptionsComp),"Precision"))+1) = num2cell(compPrecision(tpPixels,fpPixels));
        end
        
        % Recall
        if any(ismember(cellstr(myOptionsComp),"Recall"))
            tab(iFile+1,find(ismember(cellstr(myOptionsComp),"Recall"))+1) = num2cell(compSensitivity(tpPixels,fnPixels));
        end
    
        % F1 score 2 
        if any(ismember(cellstr(myOptionsComp),"F1 Score"))
            tab(iFile+1,find(ismember(cellstr(myOptionsComp),"F1 Score"))+1) = num2cell(F1score(tpPixels,fpPixels,fnPixels));
        end

    end
end

tab{1,2:end} = mean(tab{2:end,2:end},1);

end