function [myFileInfo_new] = postprocessMask(myFileInfo,savePath,myOptions)
% Writes binary version of the ROI image with separation into folder 
% "Post-processed Mask"
%
% INPUT: 
%   myFileInfo: struct containing information on files
%       folder: path name of comparison mask
%       name: cell array with filenames of comparison masks
%   savePath: path to save to
%   myOptions: struct
%       * separate: boolean, seperate connected items with different label
%       * border: boolean, remove items from border
%       * threshold: border width (in pixels)
%
% OUTPUT
%   saveLoc: location of generated masks (pathnameMask + "Post-processed Mask")
% 
% Authors: Max Mackevicius
% Date: 02.02.2024
%
% Update: 
% 16.02.2025 (Aline Knab): switched file info to structure

%% set up save data directory
saveLoc = fullfile(savePath,"Mask","Post-processed Mask");
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

for iFile = 1:size(myFileInfo,1)
    myMask = loadFile(myFileInfo(iFile).folder,myFileInfo(iFile).name);

    %% separate any touching cell masks 
    if myOptions.separate
        % Get the size of the image
        [rows, cols] = size(myMask);
        % Create an output segmented mask
        segmentedMask = zeros(rows, cols);
        % Iterate through each grayscale value
        myGrays = unique(myMask(:));
        for iClass = 1:size(myGrays,1)
            % Find pixels with the current grayscale value
            [rowIndices, colIndices] = find(myMask == myGrays(iClass));
            
            % For each pixel with the current value, apply the 3x3 kernel
            for k = 1:length(rowIndices)
                row = rowIndices(k);
                col = colIndices(k);
                
                % Define a 3x3 kernel centered at the current pixel
                kernel = myMask(max(1, row-1):min(rows, row+1), ...
                                              max(1, col-1):min(cols, col+1));
                
                % Check if any value in the kernel is not 0 or the current value
                if any(kernel(:) ~= 0 & kernel(:) ~= myGrays(iClass))
                    segmentedMask(row, col) = 1;
                end
            end
        end

        %Change mask from instanced to binary binary mask
        binaryMask = logical(myMask);
        %separate individual cells 
        myMask = binaryMask - logical(segmentedMask);
        myMask(myMask<0)=0;
        myMask = logical(myMask);
    elseif ~islogical(myMask)
        dim = min(size(myMask,3),3);
        if dim>=3
            myMask = rgb2gray(myMask);
        end
        myMask = logical(myMask);
    end

    %% Remove masks within x pixels of border
    if myOptions.border
    
        % Parameters for cropping and border width
        borderWidth = myOptions.threshold; %in pixels
        
        % Crop the image
        croppedImage = myMask(borderWidth+1:end-borderWidth, borderWidth+1:end-borderWidth);
        
        % Apply imclearborder
        BorderClearedImage = imclearborder(croppedImage);
        
        % Create a new image with the border added back
        myMask = zeros(size(myMask));
        myMask(borderWidth+1:end-borderWidth, borderWidth+1:end-borderWidth) = BorderClearedImage;
    end

    %% Save new mask
    newFile = fullfile(saveLoc, myFileInfo(iFile).name);
    imwrite(myMask, newFile);
    
    %% Update myFileInfo
    myFileInfo_new = myFileInfo;   
    saveFolder = cellstr(repmat(saveLoc,size(myFileInfo_new,1),1));
    [myFileInfo_new.folder]=deal(saveFolder{:});
end