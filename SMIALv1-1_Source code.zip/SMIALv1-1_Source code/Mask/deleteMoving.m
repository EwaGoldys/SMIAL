function [tab,myFileInfoMASK] = deleteMoving(myFileInfoMASK,myFileInfoMASK_true,...
                    savePath, threshold_uoi,ax,saveMask)
% Compares mask and ground truth mask quantitativly
%
% INPUT: 
%   myFileInfoMASK: struct containing information on files
%       * folder: path name of comparison mask
%       * name: filenames of comparison masks
%   myFileInfoMASK_true: struct containing information on files
%       * folder:  path name of true mask
%       * name: cell filenames of true masks%   threshold_uoi: threshold UoI (delete ids when less)
%   savePath: path to save to
%   ax: uiaxis object
%   saveMask: boolean to save mask in files
%
% OUTPUT:
%   tab: table with comparison values
% 
% Authors: Aline Knab
% Date: 19.03.2024
%
% Last modified: 
% 16.01.2025 (Aline Knab): switched file info to structure

if nargin < 6
    saveMask = true;
end
if nargin < 5
    figure(); ax = gca;
end

saveLocVis = fullfile(savePath,'Mask_visualIoU');
if ~exist(saveLocVis, 'dir')
   mkdir(saveLocVis);
end

if saveMask
    saveLoc = fullfile(savePath,'Mask_constant');
    if ~exist(saveLoc, 'dir')
       mkdir(saveLoc);
    end
end

%% Set up table
numVariables = 6;
tab = table('Size',[size(myFileInfoMASK,1),numVariables],...
    'VariableTypes',["string",repmat("double",1,numVariables-1)]);
tab.Properties.VariableNames = ["Filename","# Delete","# Keep","# Total","% Deleted","Mean IoU"];
tab(:,1) = {myFileInfoMASK.name}.';

%% Required files
totalDelete = nan(size(myFileInfoMASK,1),1);

for iFile = 1:size(myFileInfoMASK,1) 
    cla(ax);cla(ax,"reset");
    
    %% Match files & load
    CPMask = loadFile(myFileInfoMASK(iFile).folder,myFileInfoMASK(iFile).name,true); % First file
    CPMask_o = CPMask;
    % CPMask_org = CPMask; % test visual
    idxGT = ismember({myFileInfoMASK_true.name}.', myFileInfoMASK(iFile).name);
    if find(idxGT) ~= iFile
        "Aline, check: " + myFileInfoMASK(iFile).name
    end
    GTMask = loadFile(myFileInfoMASK_true(iFile).folder,myFileInfoMASK_true(idxGT).name,true); % End file
    allBlack = zeros(size(CPMask));
    
    %% Pixel index list of both masks
    cp_region = regionprops(CPMask,"PixelIdxList");
    gt_region = regionprops(GTMask,"PixelIdxList");
    gt_val = nan(sum(GTMask(:)>0),2);
    count = 1;

    countIoU = 0;
    meanIoU = 0;

    %% Get list of region/pixel index
    for iRegion = 1:size(gt_region,1)
        gt_val(count:count+length(gt_region(iRegion).PixelIdxList)-1,1) = iRegion;
        gt_val(count:count+length(gt_region(iRegion).PixelIdxList)-1,2) = gt_region(iRegion).PixelIdxList;
        count = count+length(gt_region(iRegion).PixelIdxList)+1;
    end

    %% Find overlap
    numDelete = 0;
    for iRegion = 1:size(cp_region,1)
        gt_ref = gt_val(ismember(gt_val(:,2),cp_region(iRegion).PixelIdxList),1);
        if ~isempty(gt_ref)
            myMode = mode(gt_ref);
            
            imCP = zeros(size(CPMask)); 
            imCP(cp_region(iRegion).PixelIdxList) = 1;

            imGT = zeros(size(GTMask)); 
            if ~isempty(myMode)
                imGT(gt_region(myMode).PixelIdxList) = 1;
            end
    
            % Calculate the Intersection over Union (IoU) for true positives
            intersect = imGT & imCP;
            union = imGT | imCP;
            
            myRes = double(sum(intersect(:)) / sum(union(:)));
            countIoU = countIoU+1;
            meanIoU = meanIoU + myRes;
        else
            myRes = 0;
        end

        % remove areas below threshold
        if myRes > threshold_uoi
            gt_val(gt_val(:,1)==myMode,:)=[];
        else
            CPMask(cp_region(iRegion).PixelIdxList) = 0;
            numDelete = numDelete+1;
        end
    end

    tab{iFile,2} = numDelete;
    tab{iFile,4} = size(cp_region,1);
    tab{iFile,3} = size(cp_region,1)-numDelete;
    tab{iFile,5} = numDelete/size(cp_region,1)*100; % Aline Test original: tab{iFile,5} = numDelete/(size(cp_region,1)-numDelete)*100;
    if tab{iFile,5} == Inf
        tab{iFile,5} = 100;
    end
    tab{iFile,6} = meanIoU/countIoU;

    % disp("File "+num2str(iFile)+": Deleted " + num2str(numDelete) + " out of " + num2str(size(cp_region,1)) +...
    %     " (Remaining: " + num2str(size(cp_region,1)-numDelete) + ")");
    
    %% Test visual
    % Combined = double(GTMask+CPMask.*2);
    Combined = double(GTMask+CPMask_o.*2);
    Combined(logical(CPMask)) = 4;
    myColors = [1 0 0; 0 1 0; 0 0 1; .9 .9 .9];
    B = labeloverlay(allBlack,Combined,'Colormap',myColors,'Transparency',0);    
    % B = labeloverlay(double(CPMask_org),Combined,'Colormap',[1 0 0; 0 1 0; 0 0 1]);
    imshow(B,'Parent', ax); 
    title(ax,num2str(threshold_uoi));
    [~,filename_c,~]=fileparts(myFileInfoMASK(iFile).name);
    
    hold(ax,"on")
    myLegend = struct;
    myLegendItems = [];
    myLegendText = {"True Only","Mask Only","Combined, delete","Combined, keep"};
    for iColor = 1:size(myColors,1)
        myLegend.(append("f",num2str(iColor))) = ...
            plot(ax,nan, nan, 'Marker', 'o', 'MarkerFaceColor', myColors(iColor,:),...
            'MarkerEdgeColor', myColors(iColor,:),'linestyle','none','MarkerSize',8);
        myLegendItems = [myLegendItems, myLegend.(append("f",num2str(iColor)))];
    end
    lgd = legend(ax,myLegendItems,myLegendText);
    
    makePretty(ax);
    saveGuiFigure(ax,fullfile(saveLocVis,append(filename_c,"_Vis_",num2str(threshold_uoi),".png"))); 
    
    totalDelete(iFile) = numDelete;

    %% Save new mask
    if saveMask
        myFileInfoMASK(iFile).folder = saveLoc;
        newFile = fullfile(saveLoc, myFileInfoMASK(iFile).name);
        imwrite(CPMask, newFile);
    end

end

end