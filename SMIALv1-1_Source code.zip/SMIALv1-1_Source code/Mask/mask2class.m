function [myClassesC, classPerIm] = mask2class(pathnameMask,filenameMask,myThreshold)
% Reads mask and converts labels into classes
%
% INPUT: 
%   pathMask: pathname of mask (string)
%   fileMask: filenames of mask (string or cell array)
%   fileName: filenames of images (cell array)
%
% OUTPUT
%   myClassesC: categorical class names
%   classPerIm: class per image
% 
% Authors: Aline Knab, Max Mackevicius
% Date: 12.11.2023

if nargin < 3
    myThreshold = 0;
end

myClasses = {};
classPerIm = strings(size(filenameMask,2),1);

for iFile=1:length(filenameMask)
    myMask = loadFile(pathnameMask,filenameMask{iFile});
    classes_c = unique(double(myMask));
    classes_c(classes_c==0)=[];
    
    classPerIm(iFile) = strjoin(string(classes_c),", ");

    myMask_b = logical(myMask);
    cellRegions = regionprops(myMask_b, 'area', 'PixelIdxList','Centroid');
    cellRegions([cellRegions.Area] <= myThreshold) = [];
    
    for iRegion = 1:size(cellRegions,1)
        myPxl = cellRegions(iRegion).PixelIdxList;
        myClasses = [myClasses;myMask(myPxl(1))];
    end
end
myClassesC = categorical(cell2mat(myClasses));

end