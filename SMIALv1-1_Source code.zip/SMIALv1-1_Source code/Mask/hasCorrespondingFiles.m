function [missingFiles] = hasCorrespondingFiles(compFileList,inputFileList,diff)
% Checks whether correct background masks have been selected
%
% INPUT: 
%   compFileList: filelist of images to compare (cell)
%   inputFileList: filelist of images to compare from (cell)
%   diff: cell array with with diff{1} difference in compFiles and 
%       diff{2} difference in inputFile
        % -> can be string array, ext will convert to file extension
%
% OUTPUT
%   missingFiles: string of missing files (delimiter; ", ")
% 
% Authors: Aline Knab
% Date: 27.01.2024

if isempty(compFileList) || isempty(inputFileList)
    missingFiles = "Files missing for comparison; computation not possible.";
    return
end

noFind = true([size(compFileList,1),1]);

if nargin < 3; diff = cell([1,2]); end

for iFile = 1:size(compFileList,1)
    strComp = compFileList{iFile};
    if ~isempty(diff{1})
        myDiff1 = diff{1};
        if any(contains(myDiff1,"ext"))
            [~,~,extComp] = fileparts(strComp);
            idx = contains(myDiff1,"ext");
            myDiff1(idx) = extComp;
            diff{1} = strjoin(myDiff1,"");
        end
    end
    if ~isempty(diff{2})
        myDiff2 = diff{2};
        if any(contains(myDiff2,"ext"))
            [~,~,extInput] = fileparts(inputFileList{1});
            idx = contains(myDiff2,"ext");
            myDiff2(idx) = extInput;
            diff{2} = strjoin(myDiff2,"");
        end
    end

    strComp = strrep(strComp,diff{1},diff{2});
    
    if any(contains(string(inputFileList),strComp))
        noFind(iFile)= false;
    else
        la = 1;
    end
end

missingFiles = strjoin(string(compFileList(noFind)),", ");

end