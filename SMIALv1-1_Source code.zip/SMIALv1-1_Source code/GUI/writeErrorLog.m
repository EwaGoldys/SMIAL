function writeErrorLog(ME, saveLoc)
saveLoc = fullfile(saveLoc,"ErrorLog_SMIAL");
if ~exist(saveLoc, 'dir')
   mkdir(saveLoc);
end

myFile = fullfile(saveLoc,"ErrorLog_SMIAL.txt"); 

if exist(myFile,"file")
    existingLines = readlines(myFile);
    writelines(existingLines,myFile,WriteMode="overwrite");
    myWriteMode = "append";
else
    myWriteMode = "overwrite";
end

%% Time stamp
myTime = string(datetime('now','Format','yyyy-MM-dd''_''HH-mm-ss'));
writelines(myTime,myFile,WriteMode=myWriteMode);

%% Error
writelines(append("Identifier: ",ME.identifier),myFile,WriteMode="append");
writelines(getReport(ME),myFile,WriteMode="append");
writelines("------",myFile,WriteMode="append");
writelines("",myFile,WriteMode="append");

end