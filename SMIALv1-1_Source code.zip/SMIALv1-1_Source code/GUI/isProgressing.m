function [fig,d] = isProgressing(msg)
% displays window with moving progress bar
%
% INPUT:
%   msg: string array with text (default: Computing.)
%
% OUTPUT: 
%   fig: uifigure
%   d: ProgressDialog object
%
% Authors: Aline Knab
% Date: 06.04.2023

if nargin < 1
    msg = "Computing.";
end

fig = uifigure;
d = uiprogressdlg(fig,'Title',msg,'Indeterminate','on');
drawnow;

end
