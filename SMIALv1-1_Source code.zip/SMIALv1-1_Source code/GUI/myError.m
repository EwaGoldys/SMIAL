function myError(ME,saveLoc,flagKnown)
% error message output
%
% INPUT: 
%   ME:  MException object
%   flagKnown: uses defined error message only
%
% Authors: Aline Knab
% Date: 06.04.2024

if nargin < 2
    saveLoc = [];
end

if nargin < 3
    flagKnown = false;
end

if ~isempty(saveLoc), writeErrorLog(ME, saveLoc); end

if flagKnown
    errordlg([ME.message,newline,newline,newline,...
        getReport(ME,'extended','hyperlinks','off')],'Error');
else
    errordlg(['Oops, something went wrong.',newline,newline,...
        getReport(ME,'extended','hyperlinks','off')],'Error');
end


rethrow(ME);

end