function trueButtonSelection(app,thisField,mySelection)   
% sets defined selection to true (checkboxes & radiobuttons)
%
% INPUT 
%   app: object, e.g., panel
%   thisField: tag to read out (default: Text) 
%       -> used to identify mySelection
%   mySelection: string to thisField which is supposed to be true
% 
% Author: Aline Knab
% Date: 25.03.2024

if nargin < 2
    thisField = "Text";
end

% Get all children
listSelect = {};
myChildren = allchild(app); 

% Search for checked checkboxes
for i = 1:numel(myChildren) 
    myClass = class(myChildren(end-i+1));
    myClass = split(myClass,'.');
    myClass = myClass{end};
    if (strcmp(myClass,'CheckBox') || strcmp(myClass,'RadioButton'))...
            && (~isempty(myChildren(end-i+1).(thisField)) ...
                && contains(mySelection,myChildren(end-i+1).(thisField)))
        myChildren(end-i+1).Value = true;
    end
end


end