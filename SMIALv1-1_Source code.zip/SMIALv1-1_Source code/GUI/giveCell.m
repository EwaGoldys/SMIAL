function myCell = giveCell(input)
% converts entry to cell if other type
%
% INPUT:
%   input: input variable
%
% OUTPUT:
%   myCell: cell containing input
%
% Authors: Aline Knab
% Date: 02.11.2023

if ~iscell(input)
    myCell = {input};
else
    myCell = input;
end

end