function selectallButtonPushed(app)     
% ticks all checkboxes of input object
%
% INPUT 
%   app: object, e.g., panel
% 
% Authors: Aline Knab, 
% Date: 06.12.2023

myChildren = allchild(app); 

for i = 1:numel(myChildren) 
    myClass = class(myChildren(end-i+1));
    myClass = split(myClass,'.');
    myClass = myClass{end};
    if strcmp(myClass,'CheckBox')
        myChildren(end-i+1).Value = true;
    end
end

end