function listSelect =  checkallButtonPushed(app,thisField)   
% returns checked items of input object
%
% INPUT 
%   app: object, e.g., panel
%   thisField: tag to read out (default: Text)
%
% OUTPUT: 
%   listSelect: cell array with all checked items in app (size 1,x)
% 
% Authors: Aline Knab
% Date: 06.12.2023

if nargin < 2
    thisField = "Text";
end

% Get all children
listSelect = {};
myChildren = allchild(app); 

% Search for checked checkboxes
for i = 1:numel(myChildren) 
    myClass = class(myChildren(end-i+1));
    myClass = split(myClass,'.');
    myClass = myClass{end};
    if strcmp(myClass,'CheckBox') && myChildren(end-i+1).Value
        listSelect{end+1} = myChildren(end-i+1).(thisField);
    end
end


end