function searchPathSMIAL = loadSearchPath()
% loading last selected search path if available
%
% OUTPUT:
%   searchPathSMIAL: string specifying search path
%
% Authors: Aline Knab
% Date: 14.02.2025    

if exist('searchPathSMIAL.mat','file')
    searchPathSMIAL = load('searchPathSMIAL.mat');
    myFields = fieldnames(searchPathSMIAL);
    if size(myFields,1)>1
        searchPathSMIAL = prefdir;
    else
        searchPathSMIAL = searchPathSMIAL.(myFields{1});
    end
else
    searchPathSMIAL = prefdir;

    %% Version 1
    % if ismac % Mac platform
    %     mySearchPath = fullfile(getenv('home'),'Documents');
    % elseif isunix % Linux platform
    %     mySearchPath = fullfile(getenv('home'),'Documents');
    % elseif ispc % Windows platform
    %     mySearchPath = fullfile(getenv('userprofile'),'Documents');
    % else
    %     disp('Platform not supported')
    % end 

end

end