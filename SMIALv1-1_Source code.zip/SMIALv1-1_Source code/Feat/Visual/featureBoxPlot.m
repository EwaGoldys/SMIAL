function featureBoxPlot(evalMatrix,myClassesC,varnames,idx,ax) 
% Generate boxplots for features
%
% INPUT:
%   evalMatrix: double array containing feature data 
%       (rows: observations, columns features)
%   myClassesC: categorical, class labels
%   varnames: string containing feature names
%   idx: indices of features to display
%   ax: axis object
%
% Authors: Shannon Handley
% Date: 01.02.2024
%
% Last modified: 
%   13.07.2025 (Aline Knab): alphabetically displaying groups with regards
%       to time features

%% Prepare axis
cla(ax); cla(ax,'reset'); 

%% Basics
myClassesN = grp2idx(myClassesC);
numClasses = size(unique(myClassesC),1);
myGroups = unique(myClassesC);

%% Compile feature data
plotData = nan([max(countcats(myClassesC)),size(idx,1)*(numClasses+1)]);
for jClass = 1:numClasses
    myMatrix = evalMatrix(myClassesN==jClass,idx);
    plotData(1:size(myMatrix,1),jClass:(numClasses+1):end) = myMatrix;
end

%% Plot
load('myColors.mat','myColors');

% Arrange alphabetically for timed features/numbers as classes
asNumbers = str2double(string(myGroups)); % try converting to numbers
if all(~isnan(asNumbers))  % all numberic -> sort numerically
    [~, I] = sort(asNumbers);           
    myGroups_sorted = myGroups(I);      
else % no changes!
    myGroups_sorted = myGroups;
    I = 1:numClasses;
end

nFeatures = numel(idx);
plotData_sorted = [];
for f = 1:nFeatures
    startIdx = (f-1)*(numClasses+1)+1;
    classBlock = plotData(:, startIdx:startIdx+numClasses-1);
    spacerCol = plotData(:, startIdx+numClasses); % NaN spacer
    plotData_sorted = [plotData_sorted, classBlock(:, I), spacerCol];
end
myColors_sorted = [myColors(I,:); myColors(max(I)+1:end,:)];

% Boxplots
myLabels = repmat([string(myGroups_sorted);""],size(idx,1),1);
boxplot(ax,plotData_sorted,'Labels',myLabels,'Notch','off', Colors='k');
h = findobj(ax,'Tag','Box');
for j=1:length(h)
   % numClasses+ 1 - mod(j-1,numClasses+1)
   patch(ax,get(h(j),'XData'),get(h(j),'YData'),...
       myColors_sorted(numClasses+ 1 - mod(j-1,numClasses+1),:),'FaceAlpha',.5);
end 
ylabel(ax,"Feature [a.u.]");

% Feature description
count = 1;
for jClass=(numClasses+1):(numClasses+1):size(plotData_sorted,2)+1
   xline(ax,jClass,'-.k',varnames(idx(count)),'LabelHorizontalAlignment', 'left','Interpreter','none');
   count = count+1;
end
xtickangle(ax,90);

% Visual
ax.XAxisLocation = 'bottom';
ax.YLimMode = 'auto'; ax.XLimMode = 'auto';
ax.YTickMode = 'auto';
makePretty(ax);

end

