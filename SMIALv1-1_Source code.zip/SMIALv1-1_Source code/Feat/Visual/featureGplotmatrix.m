function featureGplotmatrix(evalMatrix,myClassesC,varnames,idx,myPanel) % tested by SH 20240305
% Generate scatterplot for features
%
% INPUT:
%   evalMatrix: double array containing feature data 
%       (rows: observations, columns features)
%   myClassesC: categorical, class labels
%   varnames: string containing feature names
%   idx: indices of features to display
%   myPanel: panel object
%
% Authors: Akanksha Bhargava
% Date 06.02.2024

load('myColors.mat','myColors');

delete(myPanel.Children); 
myPanel.Visible = true; 
varnames_Int = strrep(varnames,'_','');

myMarkerSize = ones(1,(size(unique(myClassesC),1))).*5; 

% Produce gplotmatrix in an external, hidden figure
tempfig = figure('visible','off'); 
cleanupFig = onCleanup(@()delete(tempfig));
tempUIPanel = copyobj(myPanel, tempfig); 
gplotmatrix(tempUIPanel,evalMatrix(:,idx),[],myClassesC,myColors(1:size(unique(myClassesC),1),:),[],myMarkerSize,[],'variable',string(varnames_Int(idx)));
drawnow
l = findobj('Tag','legend');
set(l, 'Location', 'best')

% Move invisible 
h = copyobj(tempUIPanel.Children, myPanel);
delete(tempfig) % Delete hidden figure

end



