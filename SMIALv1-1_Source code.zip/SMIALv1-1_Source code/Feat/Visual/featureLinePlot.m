function featureLinePlot(evalMatrix,myClassesC,varnames,idx,myPanel) 
% Generate boxplots for features
%
% INPUT:
%   evalMatrix: double array containing feature data 
%       (rows: observations, columns features)
%   myClassesC: categorical, class labels
%   varnames: string containing feature names
%   idx: indices of features to display
%   myPanel: uipanel
%
% Authors: Shannon Handley, Aline Knab
% Date 16.03.2024
%
% Last modified: 
%   13.07.2025 (Aline Knab): alphabetically displaying groups with regards
%       to time features

delete(myPanel.Children); 
t = tiledlayout(myPanel, "flow");

%% Basics
myClassesN = grp2idx(myClassesC);
numClasses = size(unique(myClassesC),1);
myGroups = unique(myClassesC);

%% Compile feature data
% rows: features
% columns: classes
plotData = nan([size(idx,1),numClasses]); 
for jClass = 1:numClasses   
    myMean = mean(evalMatrix(myClassesN==jClass,idx));
    plotData(:,jClass) = myMean.';
end

% Arrange alphabetically
asNumbers = str2double(string(myGroups)); % try converting to numbers
if all(~isnan(asNumbers))  % all numberic -> sort numerically
    [~, I] = sort(asNumbers);           
    myGroups_sorted = myGroups(I);      
else % no changes!
    myGroups_sorted = myGroups;
    I = 1:numClasses;
end

plotData_sorted = plotData(:,I);

% Visualize
x = 1:numClasses;
for iFeature = 1:length(idx)
    ax = nexttile(t);
    plot(ax,x,plotData_sorted(iFeature,:),'b-o','MarkerSize',3)
    ylabel(ax,varnames(idx(iFeature)),'Interpreter','none')
    xticks(ax,x)
    xticklabels(ax,myGroups_sorted);
    makePretty(ax);
end

end

