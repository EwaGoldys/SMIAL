function featureBarPlot(evalMatrix,myClassesC,varnames,idx,ax) % not tested yet
% Generate bar plots for features
%
% INPUT:
%   evalMatrix: double array containing feature data 
%       (rows: observations, columns features)
%   myClassesC: categorical, class labels
%   varnames: string containing feature names
%   idx: indices of features to display
%   ax: axis object
%
% Authors: Shannon Handley
% Date: 01.02.2024

%% clear up plot
cla(ax); cla(ax,'reset'); 

%% Basics
myClassesN = grp2idx(myClassesC);
numClasses = size(unique(myClassesC),1);
myGroups = unique(myClassesC);

%% Compile feature data
% rows: features
% columns: classes
plotData = nan([size(idx,1),numClasses]);
for jClass = 1:numClasses   
    myMean = mean(evalMatrix(myClassesN==jClass,idx));
    plotData(:,jClass) = myMean.';
end

%% Plot
load('myColors.mat','myColors');

% Arrange alphabetically
asNumbers = str2double(string(myGroups)); % try converting to numbers
if all(~isnan(asNumbers))  % all numberic -> sort numerically
    [~, I] = sort(asNumbers);           
    myGroups_sorted = myGroups(I);      
else % no changes!
    myGroups_sorted = myGroups;
    I = 1:numClasses;
end
plotData_sorted = plotData(:,I);
myColors_sorted = [myColors(I,:); myColors(max(I)+1:end,:)];

bar(ax,1:size(plotData_sorted,1),plotData_sorted);
colororder(ax,myColors_sorted(1:numClasses,:));
hold(ax,'on'); 

xticklabels(ax,varnames(idx));
ax.TickLabelInterpreter = 'none';

ylabel(ax,"Feature [a.u.]",'Interpreter','none')
legend(ax,myGroups_sorted,'Interpreter','none','Location','best');

makePretty(ax);

end

