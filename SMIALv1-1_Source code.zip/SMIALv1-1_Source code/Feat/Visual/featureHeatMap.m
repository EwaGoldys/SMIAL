function featureHeatMap(evalMatrix,myFileInfoIM,myCh,...
    myFileInfoMASK,varname,areaThreshold,mycmap,myLim,ax,dispOpt) 
% produces heatmaps of input feature values
%
% INPUT:
%   evalMatrix: double array containing feature data 
%       (rows: observations of selected file, columns features)
%   myFileInfoIM: struct containing informatiion on image files
%       folder: pathname
%       name: filename
%   filenameMask: cell array containing image filename
%   myCh: double/string/char with channel number to display
%   myFileInfoMASK: struct containing informatiion on mask files
%       folder: pathname
%       name: filename%   areaThreshold: minimum area for masked regions
%   varname: string containing feature name
%   mycmap: colormap, e.g. 'jet'
%   myLim: visualisation limits for heatmap masks only
%       (default: [min(evalMatrix),max(evalMatrix)]) 
%   ax: uiaxis
%   dispOpt: string with display option 
%       * heat_over: heatmap over grayscale image
%       % heat_mask: heatmap on masks
%
% Authors: Shannon Handley, Aline Knab
% Date: 25.08.2024
%
% Last modified: 
% 23.02.2025 (Aline Knab): switched file info to structure; save folder
%   now defined in MySetting

if nargin < 10; dispOpt = "heat_mask"; end
if nargin < 9; figure(); ax = gca; end 
if nargin < 8 || isempty(myLim); myLim = [min(evalMatrix),max(evalMatrix)]; end

if isstring(myCh) || ischar(myCh)
    myCh = str2double(myCh); 
end

%% Clean up axis
delete(ax.Children);
ax.Visible = true;

%% Compute Heatmap
myMask = loadFile(myFileInfoMASK.folder,myFileInfoMASK.name,true);

myMaskFeature = double(myMask);   %calling it this for now
cellRegions = regionprops(myMask, 'PixelIdxList','Area');
cellRegions([cellRegions.Area] <= areaThreshold) = [];

for k = 1:numel(cellRegions)
    idxtest = cellRegions(k).PixelIdxList;  % this is from the matrix which contains the features
    if strcmp(dispOpt,"heat_mask")          % Adjusted according to what feature you want shown, version no overlay
        myMaskFeature(idxtest) = evalMatrix(k);   
    elseif strcmp(dispOpt,"heat_over")      % Assign index, version overlay
        myMaskFeature(idxtest) = k;
    end
end

%% Visualize
% version no overlay
if strcmp(dispOpt,"heat_mask")
    myIm = mat2gray(myMaskFeature,myLim);

% version overlay
elseif strcmp(dispOpt,"heat_over")
    myIm = loadFile(myFileInfoIM.folder,myFileInfoIM.name);
    myIm = mat2gray(myIm(:,:,myCh));

    cmap = feval(mycmap);
    numcol = size(cmap,1);
    if isempty(myLim)
        cps = floor(rescale(evalMatrix, 1, numcol));
    else
        cps = floor((evalMatrix-myLim(1)) ./ (myLim(2)-myLim(1)) * (numcol-1) + 1);
    end
    colorized_cp = squeeze(permute(cmap(cps,:), [1 3 2]));
    if size(colorized_cp,2) ~= 3
        colorized_cp = colorized_cp.';
    end

    myIm = labeloverlay(myIm,myMaskFeature,'Colormap',colorized_cp);
end

% show image
imshow(myIm,'Parent',ax);

% set colorbar
% mycmap = str2num(mycmap); % why?
% set(ax,'Colormap',mycmap); % why?
colormap(ax,mycmap);
cBar = colorbar(ax);
set(ax,'LooseInset',get(ax,'TightInset'));
set(cBar,'FontSize',12);
ylabel(cBar,varname)
cBar.Label.Interpreter = 'none';

end