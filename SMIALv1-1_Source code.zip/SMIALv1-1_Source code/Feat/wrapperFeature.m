function [tableCells,fileNameColumn] = wrapperFeature(myFileInfoIM, myFileInfoMASK, ...
    saveLoc, selection,genListSelectMorph,myThreshold,myClasses,scale,...
    myCh,varnames,offsetMatrix,NumGray,GrayLimit, ...
    percentageValue,percentageValueChInitial,percentageValueChNext)
% Wrapper function for feature generation 
%
% INPUT:
%   myFileInfoIM: struct containing information on image files
%       * folder: path name of image
%       * name: filenames of image
%       * date: date last changed
%   myFileInfoMASK: struct containing information on files
%       * folder: path name of  mask
%       * name: filenames of comparison masks
%       * date: date last changed
%   saveLoc: string containing save data location
%   selection: cell array containing selected computation options
%   genListSelectMorph: cell array containing computation options for
%       morphology
%   myThreshold: double, area threshold to exclude mask regions with low
%       pixel counts
%   myClasses: categorical, class labels
%   scale: struct, parameter providing scale 
%       (px: 1 pixel = x units, .unit = unit/um/...)
%   myCh: double array, channels to consider
%   varnames: cell array including variable names
%   offsetMatrix: double offset matrix
%   NumGray: number of gray levels
%   GrayLimit: gray limits   
%   percentageValue: numeric value identifying highest percentage of pixels
%       to be considered for mean top %
%   percentageValueChInitial: numeric value identifying highest percentage of pixels
%       for channel ratio - mean top % first channel
%   percentageValueChNext: numeric value identifying highest percentage of pixels
%       for channel ratio - mean top % second channel
%
% OUTPUT:
%   tableCells: Generates excel files containing data for feature tables
%   fileNameColumn: cell array containing image name/image folder/image 
%       date of each observation
%
% Author: Shannon Handley
% Date 13.11.2024
%
% Last modified: 
%   09.05.2025 (Aline Knab): efficiency improvement (e.g. parfor); updated
%       file structure
%   28.05.2025 (Aline Knab): added time logging and saving feature list as
%       .txt

tStart_total = tic;

% Save folder features
saveFolder_feat = fullfile(saveLoc,"General");
if ~exist(saveFolder_feat,"dir"), mkdir(saveFolder_feat); end

% Subfolder nubmered mask
saveFolder_mask = fullfile(saveFolder_feat,"Mask_numbered");
if ~exist(saveFolder_mask,"dir"), mkdir(saveFolder_mask); end

% Check varnames are valid strings & avoid repetitions
varnameMat = matlab.lang.makeUniqueStrings(matlab.lang.makeValidName(varnames));

% image filenames
myFilenames_list = {myFileInfoIM(:).name}.';
[~, ia] = unique(myFilenames_list, 'stable');
myFileInfoIM = myFileInfoIM(ia);

% mask filenames
filelistMASK = {myFileInfoMASK.name}.';
[~,~,extMask] = fileparts(myFileInfoMASK(1).name);
maskMap = containers.Map(string(filelistMASK), 1:numel(filelistMASK));

% Preallocate space
numFiles = size(myFileInfoIM,1);
tableCells_raw = cell(numFiles, 1);
fileNameColumn_raw = cell(numFiles, 1);
varnames_f_all = cell(numFiles, 1);

% Loop through files
parfor iFile=1:numFiles % PARFOR!!!
    % idx = 1; % related to multiple classes per image
    
    %% Current image
    myFile_c = myFileInfoIM(iFile);
    [~, myFile_base, extIm] = fileparts(myFile_c.name);

    %% looking for related mask
    idxMask = maskMap(append(myFile_base, extMask));

    %% check if preprocessed file is available    
    if isfile(fullfile(saveLoc,"Preprocessing",... % preprocessed available
            append(myFile_base,'_preprocessed',extIm)))
        myFilename_select = append(myFile_base,'_preprocessed',extIm);
        folder_select = fullfile(saveLoc,"Preprocessing");
    else 
        myFilename_select = myFile_c.name;
        folder_select = myFile_c.folder;
    end

    %% loading image file and mask
    tempData = loadFile(folder_select,myFilename_select);
    tempData = tempData(:,:,myCh);
    tempMask = loadFile(myFileInfoMASK(idxMask).folder,myFileInfoMASK(idxMask).name,true);
    
    %% evaluate masks
    maskRegions = regionprops(tempMask, 'area','PixelIdxList','Centroid');
    % thresholdAreas = [maskRegions.Area] <= myThreshold;

    valid = [maskRegions.Area] > myThreshold;
    for iRegion = find(~valid)
        tempMask(maskRegions(iRegion).PixelIdxList) = 0;
    end
    maskRegions = maskRegions(valid);
    tempMaskSignal = tempData.*tempMask;

    %% compute features 
    [myOutput, varnames_f] = myFeatures(selection,genListSelectMorph,tempMask,...
        tempMaskSignal,size(maskRegions,1),varnameMat.',scale,offsetMatrix,...
        NumGray,GrayLimit,percentageValue,percentageValueChInitial,percentageValueChNext); 

    if ~isempty(myOutput)
        %% Get variable names
        varnames_f_all{iFile} = varnames_f;
        
        % compute feature ID
        nRegions = size(myOutput,1);
        IDs = "ID_" + string(1:nRegions)';
        
        % Differentiate between multiple classes per image vs. 1 class per image
        % if size(myClasses,1)>size(myFileInfoMASK,1) % currently not enabled
        %     myClasses_ID = myClasses(idx:idx+size(myOutput,1)-1);
            % idx = idx+size(myOutput,1);
        % else
            myClasses_ID = repmat(string(myClasses(iFile)),nRegions,1);
        % end
    
        %% Combine all values in table
        myRow = [char(myClasses_ID), repmat(myFile_c.name,nRegions,1), IDs, myOutput];
        tableCells_raw{iFile} = num2cell(myRow);

        %% Filename information
        folderStr = string(myFile_c.folder);
        dateStr = string(myFile_c.date);
        fileNameColumn_raw{iFile} = cellstr([myRow(:,2), repmat(folderStr,nRegions,1), repmat(dateStr,nRegions,1)]);

        %% Save labeled masks (numbering each region with associated number from stats.xls)
        for iRegion=1:size(maskRegions,1)       
            c = round(maskRegions(iRegion).Centroid);
            tempMask = insertText(double(tempMask), c, num2str(iRegion), 'FontSize',18,...
                'BoxColor','red','BoxOpacity',0.4,'TextColor','white'); % adding text
            tempMask = insertShape(tempMask, ...
                'FilledCircle', [c 5], 'Color','red'); % adding circle
        end
        imwrite(tempMask,fullfile(saveFolder_mask,strrep(myFileInfoMASK(idxMask).name,'.','_numbered.')));        
    end

    % clearing memory
    % clear tempData tempMask maskRegions
end

%% Assemble full table
tableCells = cell2table(vertcat(tableCells_raw{:}));
varnames_f_all = varnames_f_all(~cellfun('isempty',varnames_f_all));
tableCells.Properties.VariableNames = [{'Class','File','ID'}, cellstr(varnames_f_all{1})];
fileNameColumn = vertcat(fileNameColumn_raw{:});

%% Add row index
Idx = (1:size(tableCells,1))';
tableCells = addvars(tableCells, Idx, 'Before', 'Class',...
    'NewVariableNames',append("Idx, Area > ", string(myThreshold)));

%% Save feature table
saveFeatures(tableCells,saveFolder_feat,"featureTable");

%% Split features of each class into separate files
uniqueClasses = unique(myClasses,'stable');
myClasses_n = grp2idx(tableCells.Class);

for iClass = 1:size(uniqueClasses,1)
    classTable = tableCells(myClasses_n == iClass, :);
    saveFeatures(classTable,saveFolder_feat,...
        append("featureTable_class", matlab.lang.makeValidName(string(uniqueClasses(iClass)))));
end

%% Save feature list & runtime
featureList = [selection,genListSelectMorph].';
T = cell2table(featureList);

tEnd_total = toc(tStart_total);
disp("Run time general features: "+string(tEnd_total));
T(size(T,1)+2,1) = cellstr(append("Runtime: ",string(duration(0, 0, tEnd_total, 'Format', 'hh:mm:ss')),' h:m:s'));
writetable(T,fullfile(saveFolder_feat,append("featureList.txt")),'WriteMode','overwrite');  

end