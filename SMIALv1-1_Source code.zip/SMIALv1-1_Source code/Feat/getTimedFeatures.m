function [tableCells] = getTimedFeatures(tableCellsMean,timeListSelect,timeUnit,saveLoc)
% Generates fold-change for time-based features
% Reading files generated from featuresMeanperTimePoint
%
% INPUT:
%   tableCellsMean: mean features for each time point i.e. table generated from featuresMeanperTimePoint
%   timeListSelect: cell array containing computation options for
%       timed features
%   saveLoc: string containing save data location
%
% OUTPUT:
%   myFeaturesTimeFoldDifference: Generates time based feature table
%
% Author: Shannon Handley
% Date 10.02.2024
%
% Last modified: 
%   09.05.2025 (Aline Knab): improved readability and execution

saveLoc = fullfile(saveLoc,"Time");
if ~exist(saveLoc,"dir")
    mkdir(saveLoc);
end

tableCells = [];
evalMatrix = double(table2array(tableCellsMean(:,5:end)));
compMatrix = nan(size(evalMatrix));
timePoints = str2double(string(convertCharsToStrings(table2array(tableCellsMean(:,2)))));
compTime = nan(size(timePoints));

for iOption = 1:size(timeListSelect,2)
    timeListSelect_c = timeListSelect{iOption};

    if contains(timeListSelect_c,"consecutive") 
        compMatrix(2:end,:) = evalMatrix(1:end-1,:);
        compMatrix(1,:) = evalMatrix(1,:);
        compTime(2:end) = timePoints(1:end-1);
        compTime(1) = timePoints(1);
        mySuffix = "_per_"+timeUnit+"_consecutive";
    else
        compMatrix = repmat(evalMatrix(1,:),size(evalMatrix,1),1);
        compTime = repmat(timePoints(1),size(timePoints,1),1);
        mySuffix = "_initial";
    end
    
    %% Generate time features
    % In case labeling is changed: also change appearance of display plot
    % in SMIAL function comp_analysis!
    switch timeListSelect_c
        case {'difference_initial','difference_consecutive'}
            myFeatures = evalMatrix-compMatrix;
            mySuffix = append("_difference",mySuffix);
        case {'fold_change_initial','fold_change_consecutive'}
            myFeatures = evalMatrix./compMatrix;
            mySuffix = append("_foldChange",mySuffix);
        case {'percentage_change_initial','percentage_change_consecutive'}
            myFeatures = (evalMatrix-compMatrix)./compMatrix.*100;
            mySuffix = append("_percentageChange",mySuffix);
        case {'percentage_difference_initial','percentage_difference_consecutive'}
            myFeatures = abs(compMatrix-evalMatrix)./((compMatrix+evalMatrix)/2).*100;
            mySuffix = append("_percentageDifference",mySuffix);
        case {'rate_of_change_initial','rate_of_change_consecutive'}
            myFeatures = (evalMatrix-compMatrix)./(timePoints-compTime);
            myFeatures(1,:) = 0;
            mySuffix = append("_rateOfChange",mySuffix);
        case 'fourier'
            myFeatures = abs(fft(evalMatrix));
            mySuffix = "_fourier";
    end
    myFeatures = array2table(myFeatures);
    myVarnames_suffix = strcat(tableCellsMean(:,5:end).Properties.VariableNames,mySuffix);
    myFeatures.Properties.VariableNames = myVarnames_suffix;

    tableCells = [tableCells, myFeatures];
end

%% Generate feature table
tableCells = [tableCellsMean(:,1:4),tableCells];
saveFeatures(tableCells,saveLoc,"featureTable_time");

end