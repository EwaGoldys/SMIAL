function saveFeatures(tableCells,saveFolder,myFileName)
% saves feature tables as excel or matlab file based on size
% 
% INPUT: 
%   tableCells: feature table
%   saveFolder: string with folder to save to
%   myFilename: string with filename
% 
% Authors: ALine Knab
% Date: 08.05.2025

if ~exist(saveFolder,"dir")
    mkdir(saveFolder);
end

numColExcel = 16384;

if size(tableCells,1) < 1048576 && size(tableCells,2) < numColExcel
    myFileName = fullfile(saveFolder,append(myFileName,".xlsx"));
    writetable(tableCells,myFileName,'WriteMode','overwritesheet');  
else
    myFileName = fullfile(saveFolder,append(myFileName,".mat"));
    save(myFileName, "tableCells");
    msgbox("Feature table only saved as .mat file.","Info");
end