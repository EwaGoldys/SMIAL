function [features_perTimepoint] = ...
    featuresMeanperTimePoint(tableCells,saveLoc)
% Generates mean of each feature for each time point 
%
% INPUT:
%   tableCells: feature table
%   saveLoc: string containing save data location
%
% OUTPUT:
% features_perTimepoint: mean of each feature for each time point 
%
% Author: Shannon Handley
% Date 13.11.2023
%
% Last modified: 
%   08.05.2025 (Aline Knab): removed std features, updated file structure

saveLoc = fullfile(saveLoc,"Time");
if ~exist(saveLoc,"dir")
    mkdir(saveLoc);
end

myClasses = table2array(tableCells(:,2));
numTimes = size(unique(myClasses),1);

timePointsArray = double(unique(myClasses));
timePointsArray = sort(timePointsArray,'ascend');

features = nan([numTimes,size(tableCells,2)-4]);
% features_std = nan([numClasses,size(tableCells,2)-4]);
myFilenames = cell([numTimes,1]);

%% Separating features of each class into a separate file
for iClass = 1:numTimes
    for iTime = 1:numTimes
        rows = (double(myClasses) == timePointsArray(iTime));
        class_index = tableCells{:,1}(rows);
        feature_class_single = table2array(tableCells(class_index,5:end));
    
        myFilenames{iTime} = table2array(tableCells(class_index(1),3));
        feature_class_single_mean = mean(str2double(feature_class_single));
        features(iTime,:) = feature_class_single_mean;   %final matrix has rows for each time point, columns are features

        % feature_class_single_std = std(str2double(feature_class_single));
        % features_std = feature_class_single_std;   %final matrix has rows for each time point, columns are features std
    end
end

% Add feature table layout (Idx, Area > ?; Class; File; ID)
featureLayout = cell(size(features,1),4);
featureLayout(:,1) = num2cell(1:size(featureLayout,1)).';
featureLayout(:,2) = cellstr(categorical(timePointsArray));
featureLayout(:,3) = myFilenames; %cellstr(strcat("File_",string((1:size(featureLayout,1)).')));
featureLayout(:,4) = cellstr(strcat("ID",string((1:size(featureLayout,1)).')));

features_perTimepoint = [array2table(featureLayout), array2table(features)];
features_perTimepoint.Properties.VariableNames = tableCells.Properties.VariableNames;


saveFeatures(features_perTimepoint,saveLoc,"features_perTimepoint");

%% Standard deviation
% features_perTimepoint_std = array2table([featureLayout, features_std]);
% features_perTimepoint_std.Properties.VariableNames = tableCells.Properties.VariableNames;
% 
% name = fullfile(saveFolder,append("featureTableperClassStd",".xlsx"));
% writetable(features_perTimepoint_std,name,'WriteMode','overwritesheet');

end
