function [myOutput, varnames_f] = myFeatures(selection,genListSelectMorph,tempMask,...
    tempMaskSignal,numRegions,varnames,scale,offsetMatrix,NumGray,GrayLimit,...
    percentageValue,percentageValueChInitial,percentageValueChNext)
% Generates general features
%
% INPUT:
%   selection: cell array containing selected computation options
%   genListSelectMorphL: cell array containing computation options for
%       morphology
%   tempMask: binary mask 
%   tempMaskSignal: double array of image .* mask
%   numRegions: integer, number of regions
%   varnames: cell array including variable names
%   scale: struct, parameter providing scale 
%       (px: 1 pixel = x units, .unit = unit/um/...)
%   offsetMatrix: double offset matrix
%   NumGray: number of gray levels
%   GrayLimit: gray limits   
%   percentageValue: numerical with percentage value to include top intensity
%       pixels
%   percentageValueChInitial: numerical with percentage value to include top intensity
%       pixels (Channel 1)
%   percentageValueChNext: numerical with percentage value to include top intensity
%       pixels (Channel 2)
%                                                                                                                                                   
% OUTPUT:
%   myOutput: double matrix (rows: observations, columns: features) 
%   varnames_f: string array with feature variable names
%
% Authors: Shannon Handley, Aline Knab
% Date 08.11.2023

% tic
numChannels = size(tempMaskSignal,3);
varnames = string(varnames);

% Ensure unique variable names
if size(varnames,2) ~= size(unique(varnames),2)
    [~, w] = unique( varnames, 'stable' );
    dbl_idx = setdiff( 1:numel(varnames), w);
    for i = 1:size(dbl_idx,2)
        varnames(dbl_idx(i)) = varnames(dbl_idx(i))+'_'+char(i + 64);
    end
end

% Prep GLCM
NumGray = str2double(NumGray);
GrayLimit = str2num(GrayLimit);
offsetMatrix = str2num(offsetMatrix);

% Determine number of features
numRatioPairs = sum(ismember(selection, "meanRatio")) * numChannels * (numChannels - 1);
if numChannels > 1
    numProductPairs = sum(ismember(selection, "meanMultiply")) * nchoosek(numChannels, 2);
else
    numProductPairs = 0;
end
numRatioPercentage = sum(ismember(selection, "meanRatioPercentage")) * numChannels * (numChannels - 1);

% Count non-pairwise features
numStandard = sum(~ismember(selection, ["meanRatio", "meanMultiply", "meanRatioPercentage"]));
numFeatures = numChannels * numStandard + numRatioPairs + numProductPairs + numRatioPercentage;

% if any(ismember(selection,["meanRatio";"meanMultiply";"meanRatioPercentage"])) 
%     if any(ismember(selection,"meanRatio"))
%         numProducts = ???;
%     end
%     numRatios = nChannels * (nChannels-1) * sum(ismember(selection,["meanRatio";"meanMultiply";"meanRatioPercentage"]));
%     numSelect = size(selection,2)-sum(ismember(selection,["meanRatio";"meanMultiply";"meanRatioPercentage"]));
% else
%     numRatios = 0;
%     numSelect = size(selection,2);
% end
% numFeatures = numChannels*numSelect+numRatios; 

% Initialise output
myOutput = nan(numRegions,numFeatures); 
varnames_f = strings([1,numFeatures]);
myFeature = 1;

for iChannel = 1:numChannels

    cellRegions = regionprops(tempMask,tempMaskSignal(:,:,iChannel),'all');  
    im_c = tempMaskSignal(:,:,iChannel);

    for iSelection = 1:size(selection,2)
        mySelection = selection{iSelection};
        fillIn = true;
        for iRegion = 1:size(cellRegions,1)            
            [row,col] = ind2sub([size(im_c,1),size(im_c,2)],cellRegions(iRegion).PixelIdxList);
            cell_m = nan([max(row)-min(row)+1,max(col)-min(col)+1]);
            myIdx = sub2ind(size(cell_m),row-min(row)+1,col-min(col)+1);
            cell_m(myIdx) = im_c(cellRegions(iRegion).PixelIdxList);
        
            switch mySelection
                case {'Angular_Second_Moment', 'Contrast', 'Correlation','VarianceTexture','Inverse_Difference_Moment','Sum_Average','Sum_Variance','Sum_Entropy','Entropy','Difference_Variance','Difference_Entropy','Information_Measure_of_Correlation_I','Information_Measure_of_Correlation_II','Maximum_Correlation_Coefficient'}
                    warning('off','images:graycomatrix:scaledImageContainsNan');
                    cell_m_norm = (cell_m-min(cell_m(:)))./(max(cell_m(:)-min(cell_m(:))));
                    cell_m_norm(cell_m_norm==0) = NaN;
                    GLCMs = graycomatrix(mat2gray(cell_m_norm),'NumLevels',NumGray,'offset',offsetMatrix,'Symmetric',true,'GrayLimits',GrayLimit);
                    num_GLCM = size(GLCMs,3);

                    switch mySelection   

                        %% TEXTURE FEATURES
                        case 'Angular_Second_Moment'
                            angularsecondmoment = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                angularsecondmoment(:,p) = haralickTextureFeatures(GLCMs(:,:,p),1);
                            end
                            J = mean(angularsecondmoment(1,:));
        
                        case 'Contrast'
                              contrast = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                contrast(:,p) = haralickTextureFeatures(GLCMs(:,:,p),2);
                            end
                            J = mean(contrast(2,:));
        
                        case 'Correlation'
                            Correlation = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Correlation(:,p) = haralickTextureFeatures(GLCMs(:,:,p),3);
                            end
                            J = mean(Correlation(3,:));
        
                            case 'VarianceTexture'
                              Variance = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Variance(:,p) = haralickTextureFeatures(GLCMs(:,:,p),4);
                            end
                            J = mean(Variance(4,:));
        
                            case 'Inverse_Difference_Moment'
                          Inversedifferencemoment = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Inversedifferencemoment(:,p) = haralickTextureFeatures(GLCMs(:,:,p),5);
                            end
                            J = mean(Inversedifferencemoment(5,:));
        
                        case 'Sum_Average'
                            Sumaverage = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Sumaverage(:,p) = haralickTextureFeatures(GLCMs(:,:,p),6);
                            end
                            J = mean(Sumaverage(6,:));
        
                        case 'Sum_Variance'
                            Sumvariance = zeros(14,num_GLCM);                
                            for p=1:num_GLCM
                                Sumvariance(:,p) = haralickTextureFeatures(GLCMs(:,:,p),7);
                            end
                            J = mean(Sumvariance(7,:));
        
                        case 'Sum_Entropy'
                              Sumentropy = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Sumentropy(:,p) = haralickTextureFeatures(GLCMs(:,:,p),8);
                            end
                            J = mean(Sumentropy(8,:));
        
                        case 'Entropy'
                             Entropy = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Entropy(:,p) = haralickTextureFeatures(GLCMs(:,:,p),9);
                            end
                            J = mean(Entropy(9,:));
        
                            case 'Difference_Variance'
                             Differencevariance = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Differencevariance(:,p) = haralickTextureFeatures(GLCMs(:,:,p),10);
                            end
                            J = mean(Differencevariance(10,:));
        
                            case 'Difference_Entropy'
                           Differenceentropy = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Differenceentropy(:,p) = haralickTextureFeatures(GLCMs(:,:,p),11);
                            end
                            J = mean(Differenceentropy(11,:));
        
                        case 'Information_Measure_of_Correlation_I'
                             InfomeasI = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                InfomeasI(:,p) = haralickTextureFeatures(GLCMs(:,:,p),12);
                            end
                            J = mean(InfomeasI(12,:));
        
                        case 'Information_Measure_of_Correlation_II'
                             InfomeasII = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                InfomeasII(:,p) = haralickTextureFeatures(GLCMs(:,:,p),13);
                            end
                            J = mean(InfomeasII(13,:));
        
                        case 'Maximum_Correlation_Coefficient'
                             Maxcorrcoeff = zeros(14,num_GLCM);
                            for p=1:num_GLCM
                                Maxcorrcoeff(:,p) = haralickTextureFeatures(GLCMs(:,:,p),14);
                            end
                            J = mean(Maxcorrcoeff(14,:));
                    end

                %% INTENSITY FEATURES
                case 'Mean_Intensity'
                     J = mean(double(cellRegions(iRegion).PixelValues));
     
                case 'Median_Intensity'
                    J = median(double(cellRegions(iRegion).PixelValues));
    
    
                case 'Std_Intensity'
                    J = std(double(cellRegions(iRegion).PixelValues));
    
    
                case 'Minimum_Intensity'
                    J = min(double(cellRegions(iRegion).PixelValues));
    
                case 'Maximum_Intensity'
                    J = max(double(cellRegions(iRegion).PixelValues));
    
                case 'Mode'
                    J = mode(double(cellRegions(iRegion).PixelValues));
    
                case 'Kurtosis'
                        J = kurtosis(cell_m(:));
            
                case 'Variance'
                    J = var(cell_m(:),'omitnan');
        
                case 'Skewness'
                    J = skewness(cell_m(:),1);
               
                case 'Brightest10'
                    J = sort(cell_m(~isnan(cell_m(:))),'descend');
                    J = J(1:floor(cellRegions(iRegion).Area*.1));
    
                case '25th_Percentile'
                    J = prctile(cell_m,25).';
    
                case '75th_Percentile'
                    J = prctile(cell_m,75).';
                
                case '50th Percentile'
                    J = prctile(cell_m,50).';

                case 'Total Intensity'
                    J = sum(double(cellRegions(iRegion).PixelValues));

                case 'Intensity percentage'
                    B = sort(double(cellRegions(iRegion).PixelValues),'descend');
                    numPixels = round((percentageValue/100) * length(B));
                    J = B(1:numPixels,1);
                    J = mean(J);
    
                case 'meanRatio'
                    if iChannel<=numChannels
                        J = nan([cellRegions(iRegion).Area numChannels-1]);
                        outVarnames = string(1:numChannels-1);
                        count = 1;
                        for iRatio = 1:numChannels
                            if iRatio ~= iChannel
                                im_ch = tempMaskSignal(:,:,iRatio);
                                J(:,count) = mean(im_c(cellRegions(iRegion).PixelIdxList))./mean(im_ch(cellRegions(iRegion).PixelIdxList));
                                outVarnames(count) = append(varnames(iChannel), "/", varnames(iRatio));
                                count = count+1;
                            end
                        end
                    else
                        fillIn = false;
                    end
    
                case 'meanMultiply'
                    if iChannel<=numChannels
                        J = nan([cellRegions(iRegion).Area numChannels-iChannel]);
                        outVarnames = string(iChannel+1:numChannels);
                        count = 1;

                        for iProd = iChannel+1:numChannels
                            im_ch = tempMaskSignal(:,:,iProd);
                            J(:,count) = mean(im_c(cellRegions(iRegion).PixelIdxList)).*mean(im_ch(cellRegions(iRegion).PixelIdxList));
                            outVarnames(count) = append(varnames(iChannel), "*", varnames(iProd));
                            count = count+1;
                        end
                    else
                        fillIn = false;
                    end

                case 'meanRatioPercentage'
                    if iChannel<=numChannels

                        % numerator
                        J = nan([cellRegions(iRegion).Area numChannels-1]);
                        outVarnames = string(1:numChannels-1);

                        cHinitial = sort(double(cellRegions(iRegion).PixelValues),'descend');
                        cHinitial_numPixels = round((percentageValueChInitial/100) * length(cHinitial));
                        cHinitial = cHinitial(1:cHinitial_numPixels,1);
                        cHinitial = mean(cHinitial);
                        
                        % denominator
                        count = 1;
                        for iRatioPercentage = 1:numChannels
                            if iRatioPercentage ~= iChannel

                                im_ch = tempMaskSignal(:,:,iRatioPercentage);
                                cHNext = sort(im_ch(cellRegions(iRegion).PixelIdxList),'descend');
                                cHNext_numPixels = round((percentageValueChNext/100) * length(cHNext));
                                cHNext = cHNext(1:cHNext_numPixels,1);
                                cHNext = mean(cHNext);

                                J(:,count) = cHinitial./cHNext;
                                outVarnames(count) = append(num2str(percentageValueChInitial), "%", ...
                                    varnames(iChannel), "/", num2str(percentageValueChNext), "%",varnames(iRatioPercentage));
                                count = count+1;
                            end
                        end
                    else
                        fillIn = false;
                    end
    
            end
            if fillIn
                % if size(J,2)>1
                %     la = 1;
                % end
                myOutput(iRegion,myFeature:myFeature+size(J,2)-1) = mean(J,'omitnan');
            end
        end
        
        if ~exist('J','var') || isempty(J)
            fillIn = false;
        end
        
        if fillIn
            if size(J,2) == 1 && ~strcmp(mySelection,'meanRatio') && ~strcmp(mySelection,'meanMultiply')
                outVarnames = varnames(iChannel)+"_"+mySelection;
            end
            if isempty(outVarnames) 
                error("No variable names in function myFeatures.");
            end
    
            if ~isempty(find(strcmp(varnames_f, outVarnames(1)), 1))
                la =1;
    %             error("Duplicated variable names in function myFeatures.");
            end
            
            la = myFeature:myFeature+size(J,2)-1;
            if size(la,2) ~= size(outVarnames,2)
                la = 1;
            end

            varnames_f(1,myFeature:myFeature+size(J,2)-1) = outVarnames;
            myFeature = myFeature(end)+size(J,2);
        else
            la = 1;
        end
        
    end
    
end


%% MORPHOLOGICAL 
% (just need to be measured once using the mask)
numFeaturesMorph = size(genListSelectMorph,2); 
myOutputMorph = nan(numRegions,numFeaturesMorph); 
outVarnamesMorph = strings(1,size(genListSelectMorph,2));

for iSelectionMorph = 1:size(genListSelectMorph,2)
    mySelectionMorph = genListSelectMorph{iSelectionMorph};
    switch mySelectionMorph
        case {'Area', 'Perimeter', 'Major_Axis_Length', 'Convex_Area', ...
                'Filled_Area', 'Equivalent_Diameter', 'Maximum_Feret_Diameter', ...
                'Minimum feret diameter', 'Fragmentation'}
            addUnit = "_"+scale.unit;
        otherwise
            addUnit = "";
    end

    for iRegion = 1:size(cellRegions,1)

        switch mySelectionMorph
            case 'Area'
                J = cellRegions(iRegion).Area;
                J = J.*((scale.px)^2);   % Get area.

            case 'Perimeter'
                J = cellRegions(iRegion).Perimeter;
                J = J.*(scale.px);

            case 'Major_Axis_Length'
                J = cellRegions(iRegion).MajorAxisLength;
                J = J*(scale.px);

            case 'Minor_Axis_Length'
                J = cellRegions(iRegion).MinorAxisLength;
                J = J*(scale.px);

            case 'Eccentricity'
                J = cellRegions(iRegion).Eccentricity;

            case 'Orientation'
                J = cellRegions(iRegion).Orientation;

            case 'Convex_Area'
                J = cellRegions(iRegion).ConvexArea;
                J = J.*((scale.px)^2);

            case 'Circularity'
                J = cellRegions(iRegion).Circularity;
                J = J(isfinite(J));

            case 'Filled_Area'
                J = cellRegions(iRegion).FilledArea;
                J = J.*((scale.px)^2);

            case 'Euler_Number'
                J = cellRegions(iRegion).EulerNumber;

            case 'Equivalent_Diameter'
                J = cellRegions(iRegion).EquivDiameter;
                J = J*(scale.px);

            case 'Solidity'
                J = cellRegions(iRegion).Solidity;

            case 'Extent'
                J = cellRegions(iRegion).Extent;

            case 'Maximum_Feret_Diameter'
                J = cellRegions(iRegion).MaxFeretDiameter;
                J = J*(scale.px);

            case 'Maximum_Feret_Angle'
                J = cellRegions(iRegion).MaxFeretAngle;

            case 'Minimum feret diameter'
                J = cellRegions(iRegion).MinFeretDiameter;
                J = J*(scale.px);

            case 'Minimum_Feret_Angle'
                J = cellRegions(iRegion).MinFeretAngle;

            case 'Interconnectivity'
                J = cellRegions(iRegion).Area/(cellRegions(iRegion).Perimeter);

            case 'Fragmentation'
                J= 1/((cellRegions(iRegion).Area*cellRegions(iRegion).Perimeter)*(scale.px)^3);
        end
        myOutputMorph(iRegion,iSelectionMorph) = mean(J,'omitnan');

    end
    outVarnamesMorph(iSelectionMorph) = append(string(genListSelectMorph(iSelectionMorph)),addUnit);
end

% outVarnamesMorph = string(genListSelectMorph);
       
%% Merge the two outputs
myOutput = [myOutput myOutputMorph];
varnames_f = [varnames_f outVarnamesMorph];

% toc
end
