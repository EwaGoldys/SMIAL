function filelist = getFileInfo(myPath,myExtFormats)
% looks for files of specified format in given directory and returns a
% list of file structure of the majority format
%
% INPUT: 
%   myPath: string specifying directory
%   myExtFormats: cell array with formats to look for
%
% OUTPUT
%   myMdl: struct filled with classification model
%   myData: struct filled with data model
% 
% Authors: Aline Knab
% Date: 16.02.2025
% 
% Last modified: 
%   07.07.2025: Raising errors for duplicated file names

% Get all files from specified folder
filelist = dir(fullfile(myPath, '**\*.*'));  % get list of files and folders in any subfolder
filelist = filelist(~[filelist.isdir]);  % remove folders from list

% Remove unneccessary information 
myFields = fieldnames(filelist);
toRemove = myFields(~ismember(myFields,{'name','folder','date'}));
filelist = rmfield(filelist,toRemove);

% Get file extension
filelist_cell = {filelist.name}.';
[~,~,myExt] = fileparts(filelist_cell);

% Include specified formats only
correctFormat = ismember(myExt,myExtFormats);
filelist = filelist(correctFormat);
myExt = myExt(correctFormat);

% Evaluate extensions
[myExt_unique,~,i] = unique(myExt);
if size(myExt_unique,1)>1 % specified file format occuring
    count = accumarray(i(:),1,[numel(myExt_unique),1]);
    [~,indexMaxExt] = max(count);
    isMajorityExt = ismember(myExt,myExt_unique{indexMaxExt});
    filelist = filelist(isMajorityExt);
    filenames = {filelist.name}.';
    filenames_unique  = unique(filenames,'first');
    if size(filenames,1) ~= size(filenames_unique,1)
        error('MyComponent:duplicatedFiles', 'Error. \nSame filename in multiple folders. Please rename files to avoid name duplications.')
    end
elseif isempty(myExt_unique) % specified file format not occuring
    filelist=[];
    myImFormats_char = [myExtFormats',[repmat({', '},numel(myExtFormats)-1,1);{[]}]]';
    myImFormats_char = [myImFormats_char{:}];
    % error('MyComponent:incorrectType',...
    %    append(['Error. \nNo files matching the supported formats ' ...
    %    'were found in the selected folder ('],myImFormats_char,")"))   
 

    error('MyComponent:incorrectType', ...
        append(['Error. \nNo files matching the supported formats were found in the selected folder.'...
        '\nSupported formats: .tif, .mat, .png, .jpg' ...
        '\nWhat to do:'  ...
        '\n- Ensure the file extensions are correct and not hidden or misspelled.' ...
        '\n- If your images are in another format, please convert them to one of the supported formats using an image processing tool (e.g. FIJI, ImageJ or Python).' ...
        '\nNeed help? Refer to Manual Section 3.1 (Uploading Images) or post your question on the Github forum.']));

end % else: filelist stays the same

% assess duplicates
filenames = {filelist.name}.';
if numel(filenames) > numel(unique(filenames))
    error('MyComponent:duplicateFiles',...
        "Some files in the selected folder(s) have identical names. This will cause conflicts in the program. "+...
        "Please rename the duplicated files to ensure each filename is unique. "+...
        "You can use tools like Microsoft PowerToys (PowerRename) to assist with batch renaming.");
end

end