function saveLoc = createSaveLoc(saveLoc)
% Checks existence if saveLoc directory and creates if not located
%
% INPUT: 
%       saveLoc: cell array containing path & additional folders 
%           saveLoc = {"pathname","subfolder1", "subfolder2"
%
% OUTPUT: 
%       saveLoc: string including pathname of defined saveLoc
% 
% Authors: Aline Knab
% Date: 23.02.2025

if ~isempty(saveLoc)
    saveLoc = cellstr(saveLoc);
    saveLoc = fullfile(saveLoc{:});
    if ~exist(saveLoc, 'dir')
       mkdir(saveLoc);
    end
end