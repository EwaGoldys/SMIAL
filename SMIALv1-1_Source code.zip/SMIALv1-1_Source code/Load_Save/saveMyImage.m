function saveMyImage(specImage, myPathname, myFilename)
% saves images in required format (.mat, .png, .tif, .tiff, .hdr)
%
% INPUT: 
%   specImage: image to be saved
%   pathnameIm: string with pathname of image
%   myFilename: filename of image (string or cell)
%
% OUTPUT
%   myFile: transformed test dataset limited to relevant PCs
% 
% Authors: Aline Knab
% Date: 16.04.2025

[~,~,ext] = fileparts(myFilename);

if strcmp(ext,".mat")
    save(fullfile(myPathname,myFilename),'specImage');
elseif strcmp(ext,".hdr")
    myFilenameOrg = strrep(myFilename,"_preprocessed","");
    
    info = enviinfo(fullfile(myPathname,myFilenameOrg));
    myFile = hypercube(specImage,info.Wavelength);

    enviwrite(myFile,fullfile(myPathname,myFilename));
elseif strcmp(ext,".png") 
    [specImage,numBits] = testUint16(specImage);
    specImage = convertImage(specImage,numBits);
    imwrite(specImage,fullfile(myPathname,myFilename));
elseif strcmp(ext,".tif") || strcmp(ext,".tiff")
    [specImage,numBits] = testUint16(specImage);
    specImage = convertImage(specImage,numBits);

    % Add ImageJ header to the first slice
    imwrite(specImage(:,:,1), fullfile(myPathname,myFilename), ...
        'Compression', 'none', ...
        'Description', sprintf('ImageJ=1.52p\nchannels=%d\nslices=1\nframes=1', size(specImage,3)));
    
    % Append remaining channels as pages
    for iCh = 2:size(specImage,3)
        imwrite(specImage(:,:,iCh), fullfile(myPathname,myFilename), ...
            'WriteMode', 'append', 'Compression', 'none');
    end
else
    msgbox("Format for saving images not defined (function saveMyImage). " + ...
        "Please write a message to the authors")
end

end

function [specImage,numBits] = testUint16(specImage)
    if max(specImage(:))>255
        specImage = uint16(specImage);
        numBits = 16;
    else
        numBits = 8;
    end
end

function [specImage] = convertImage(specImage,numBits)
    if numBits == 8
        specImage = uint8(specImage);
    else
        specImage = uint16(specImage);
    end
end
