function [myFile] = loadFile(pathnameIm, filenameIm,isBinary)
% reads in data (accepted formats mat, tiff, png, jpg)
%
% INPUT: 
%   pathnameIm: pathname of image
%   filenameIm: filename of image (string or cell)
%   isBinary: (optional) boolean for returning binary files
%
% OUTPUT
%   myFile: transformed test dataset limited to relevant PCs
% 
% Authors: Aline Knab, Shannon Handley
% Date: 14.03.2024
%
% Last modified: 
%   20.02.2025 (Aline Knab): added .hdr format

if nargin < 3
    isBinary = false;
end

if ~iscell(filenameIm)
    filenameIm = giveCell(filenameIm);
end

%% Check file existence
if ~isfile(fullfile(pathnameIm,filenameIm{1}))
    error("Load:noFileAvailable","Could not find file in function loadFile");
end

%% Read file
filenameIm = giveCell(filenameIm);
[~,~,ext] = fileparts(filenameIm{1});

if strcmp(ext,'.mat') 
    myFile = load(fullfile(pathnameIm,filenameIm{1}));
    myFields = fieldnames(myFile);
    myFile = myFile.(myFields{1});
    if strcmp(myFields{1},'HAC_Image')
        myFile = myFile.imageStruct.data;
        % myFile = myFile.imageStruct.data(:,:,1:end-1);
    else
        myFile = squeeze(myFile);
    end
elseif strcmp(ext,'.tif') || strcmp(ext,'.tiff')
    myFile = double(squeeze(tiffreadVolume(fullfile(pathnameIm,filenameIm{1}))));  
elseif any(strcmp(ext,{'.png','.jpg'}))
    myFile = double(imread(fullfile(pathnameIm,filenameIm{1})));
    if isBinary && ~islogical(myFile) % ALINE: revisit
        if size(myFile,3)>1
            myFile = rgb2gray(myFile);
        end
        if isfloat(myFile)
            myFile = myFile > 0.5;
        else
            myFile = myFile >= 128;
        end
    end
elseif strcmp(ext,'.hdr') 
    info = enviinfo(fullfile(pathnameIm,filenameIm{1}));
    myFile = hypercube(info.Filename);
    myFile = myFile.DataCube;
else
    error("Load:noFileAvailable","File format not specified in function loadFile");
end

%% Return binary file
if isBinary %&& ~islogical(myFile) % error in deleteMoving ALINE
    dim = min(size(myFile,3),3);
    if dim>=3
        myFile = rgb2gray(myFile);
    end
    myFile = logical(myFile);
else 
    myFile = double(myFile); 
end
